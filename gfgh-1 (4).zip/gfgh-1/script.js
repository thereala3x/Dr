// ========== LOADING SCREEN MANAGER ==========
class LoadingScreen {
    static show() {
        const screen = document.getElementById('loadingScreen');
        if (screen) {
            screen.classList.remove('hidden');
        }
    }

    static hide() {
        const screen = document.getElementById('loadingScreen');
        if (screen) {
            screen.classList.add('hidden');
        }
    }

    static auto() {
        // Hide loading screen when DOM is fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => this.hide(), 800);
            });
        } else {
            setTimeout(() => this.hide(), 800);
        }
    }
}

// Auto-hide loading screen on page load
LoadingScreen.auto();

// ========== TOAST NOTIFICATION SYSTEM ==========
class Toast {
    static show(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        const container = document.getElementById('toastContainer');
        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    static success(message) { this.show(message, 'success'); }
    static error(message) { this.show(message, 'error'); }
    static info(message) { this.show(message, 'info'); }
}

// ========== DATABASE CLASS ==========
class Database {
    constructor() {
        // Ensure we have the correct API URL for backend calls
        const protocol = window.location.protocol;
        const host = window.location.host;
        this.apiUrl = `${protocol}//${host}`;
        this.init();
    }

    async init() {
        try {
            const accountsResponse = await fetch(`${this.apiUrl}/api/accounts`);
            if (accountsResponse.ok) {
                const accounts = await accountsResponse.json();
                if (accounts.length > 0) {
                    localStorage.setItem('accounts', JSON.stringify(accounts));
                }
            }
        } catch (error) {
            console.log('Loading accounts from localStorage');
        }

        try {
            const postsResponse = await fetch(`${this.apiUrl}/api/posts`);
            if (postsResponse.ok) {
                const posts = await postsResponse.json();
                if (posts.length > 0) {
                    localStorage.setItem('xvo_posts', JSON.stringify(posts));
                }
            }
        } catch (error) {
            console.log('Loading posts from localStorage');
        }

        if (!localStorage.getItem('xvo_notifications')) {
            localStorage.setItem('xvo_notifications', JSON.stringify([]));
        }
        if (!localStorage.getItem('xvo_bookmarks')) {
            localStorage.setItem('xvo_bookmarks', JSON.stringify([]));
        }
    }

    async reloadPosts() {
        try {
            const postsResponse = await fetch(`${this.apiUrl}/api/posts`);
            if (postsResponse.ok) {
                const posts = await postsResponse.json();
                localStorage.setItem('xvo_posts', JSON.stringify(posts));
                return posts;
            }
        } catch (error) {
            console.log('Failed to reload posts:', error);
        }
        return this.getPosts();
    }

    async reloadAccounts() {
        if (this.lastAccountReload && Date.now() - this.lastAccountReload < 5000) {
            return this.getAccounts();
        }
        this.lastAccountReload = Date.now();
        try {
            const accountsResponse = await fetch(`${this.apiUrl}/api/accounts`);
            if (accountsResponse.ok) {
                const accounts = await accountsResponse.json();
                localStorage.setItem('accounts', JSON.stringify(accounts));
                return accounts;
            }
        } catch (error) {
            console.log('Failed to reload accounts:', error);
        }
        return this.getAccounts();
    }

    getAccounts() {
        return JSON.parse(localStorage.getItem('accounts') || '[]');
    }

    getAccount(id) {
        return this.getAccounts().find(a => a.id === parseInt(id));
    }

    getAccountByUsername(username) {
        return this.getAccounts().find(a => a.username.toLowerCase() === username.toLowerCase());
    }

    async createAccount(name, email, dob, username, password) {
        const newAccount = {
            name, email, dob, username, password,
            displayName: name,
            bio: '',
            avatar: 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png',
            banner: '',
            followers: [],
            following: [],
            location: '',
            website: '',
            joinDate: Date.now(),
            verifiedID: false,
            badge: null,
            isAdmin: false,
            isSuspended: false,
            isDeleted: false,
            deletionRequested: false,
            deletionRequestTime: null,
            isPrivate: false
        };

        try {
            const response = await fetch(`${this.apiUrl}/api/accounts`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newAccount)
            });
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to create account');
            }
            const account = await response.json();
            const accounts = this.getAccounts();
            accounts.push(account);
            localStorage.setItem('accounts', JSON.stringify(accounts));
            return account;
        } catch (err) {
            throw err;
        }
    }

    async updateAccount(account) {
        const accounts = this.getAccounts();
        const index = accounts.findIndex(a => a.id === account.id);
        if (index !== -1) {
            accounts[index] = account;
            localStorage.setItem('accounts', JSON.stringify(accounts));
            try {
                await fetch(`${this.apiUrl}/api/accounts/${account.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(account)
                });
            } catch (err) {
                console.error('Sync error:', err);
            }
        }
    }

    async authenticate(username, password) {
        try {
            const response = await fetch(`${this.apiUrl}/api/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Login failed');
            }
            const account = await response.json();
            localStorage.setItem('xvo_current_user', String(account.id));
            const accounts = this.getAccounts();
            const index = accounts.findIndex(a => a.id === account.id);
            if (index !== -1) {
                accounts[index] = account;
                localStorage.setItem('accounts', JSON.stringify(accounts));
            }
            return account;
        } catch (error) {
            console.error('Authentication error:', error.message);
            throw error;
        }
    }

    saveCurrentUser(account) {
        if (!account || !account.id) return false;
        localStorage.setItem('xvo_current_user', String(account.id));
        const accounts = this.getAccounts();
        const index = accounts.findIndex(a => a.id === account.id);
        if (index !== -1) {
            accounts[index] = account;
        } else {
            accounts.push(account);
        }
        localStorage.setItem('accounts', JSON.stringify(accounts));
        return true;
    }

    getCurrentUser() {
        const id = localStorage.getItem('xvo_current_user');
        return id ? this.getAccount(id) : null;
    }

    isAuthenticated() {
        return localStorage.getItem('xvo_current_user') !== null;
    }

    logout() {
        localStorage.removeItem('xvo_current_user');
    }

    getPosts() {
        return JSON.parse(localStorage.getItem('xvo_posts') || '[]');
    }

    getPost(id) {
        return this.getPosts().find(p => p.id === parseInt(id));
    }

    getUserPosts(userId) {
        return this.getPosts().filter(p => p.userId === userId);
    }

    getUserRetweets(userId) {
        return this.getPosts().filter(p => p.retweets && p.retweets.includes(userId));
    }

    addPost(post) {
        const posts = this.getPosts();
        post.id = posts.length > 0 ? Math.max(...posts.map(p => p.id)) + 1 : 1;
        posts.unshift(post);
        localStorage.setItem('xvo_posts', JSON.stringify(posts));
        fetch(`${this.apiUrl}/api/posts`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(post)
        }).catch(err => console.log('Sync error:', err));
        return post;
    }

    async uploadImage(file) {
        const formData = new FormData();
        formData.append('image', file);
        try {
            const response = await fetch(`${this.apiUrl}/api/upload`, {
                method: 'POST',
                body: formData
            });
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Upload failed');
            }
            return await response.json();
        } catch (error) {
            throw error;
        }
    }

    updatePost(post) {
        const posts = this.getPosts();
        const index = posts.findIndex(p => p.id === post.id);
        if (index !== -1) {
            posts[index] = post;
            localStorage.setItem('xvo_posts', JSON.stringify(posts));
            fetch(`${this.apiUrl}/api/posts/${post.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(post)
            }).catch(err => console.log('Sync error:', err));
        }
    }

    deletePost(postId) {
        const posts = this.getPosts().filter(p => p.id !== postId);
        localStorage.setItem('xvo_posts', JSON.stringify(posts));
        fetch(`${this.apiUrl}/api/posts/${postId}`, {
            method: 'DELETE'
        }).catch(err => console.log('Sync error:', err));
    }

    async addComment(postId, userId, text) {
        try {
            const turnstileToken = null;
            const response = await fetch(`${this.apiUrl}/api/posts/${postId}/comments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId, text, turnstileToken })
            });
            if (!response.ok) throw new Error('Failed to add comment');
            const comment = await response.json();
            const posts = this.getPosts();
            const post = posts.find(p => p.id === postId);
            if (post) {
                if (!post.comments) post.comments = [];
                post.comments.push(comment);
                localStorage.setItem('xvo_posts', JSON.stringify(posts));
            }
            return comment;
        } catch (error) {
            throw error;
        }
    }

    async deleteComment(postId, commentId) {
        try {
            const response = await fetch(`${this.apiUrl}/api/posts/${postId}/comments/${commentId}`, {
                method: 'DELETE'
            });
            if (!response.ok) throw new Error('Failed to delete comment');
            const posts = this.getPosts();
            const post = posts.find(p => p.id === postId);
            if (post) {
                post.comments = post.comments.filter(c => c.id !== commentId);
                localStorage.setItem('xvo_posts', JSON.stringify(posts));
            }
        } catch (error) {
            throw error;
        }
    }

    getNotifications() {
        return JSON.parse(localStorage.getItem('xvo_notifications') || '[]');
    }

    addNotification(notification) {
        const notifications = this.getNotifications();
        notification.id = notifications.length > 0 ? Math.max(...notifications.map(n => n.id)) + 1 : 1;
        notification.timestamp = Date.now();
        notification.read = false;
        notifications.unshift(notification);
        localStorage.setItem('xvo_notifications', JSON.stringify(notifications));
    }

    markAllNotificationsAsRead(userId) {
        const notifications = this.getNotifications();
        notifications.forEach(n => {
            if (n.userId === userId) n.read = true;
        });
        localStorage.setItem('xvo_notifications', JSON.stringify(notifications));
    }

    getBookmarks() {
        const currentUser = this.getCurrentUser();
        if (!currentUser) return [];
        const bookmarks = JSON.parse(localStorage.getItem('xvo_bookmarks') || '[]');
        return bookmarks.filter(b => b.userId === currentUser.id).map(b => this.getPost(b.postId)).filter(Boolean);
    }

    addBookmark(postId) {
        const currentUser = this.getCurrentUser();
        if (!currentUser) return;
        const bookmarks = JSON.parse(localStorage.getItem('xvo_bookmarks') || '[]');
        if (!bookmarks.find(b => b.userId === currentUser.id && b.postId === postId)) {
            bookmarks.push({ userId: currentUser.id, postId, timestamp: Date.now() });
            localStorage.setItem('xvo_bookmarks', JSON.stringify(bookmarks));
        }
    }

    removeBookmark(postId) {
        const currentUser = this.getCurrentUser();
        if (!currentUser) return;
        const bookmarks = JSON.parse(localStorage.getItem('xvo_bookmarks') || '[]');
        const filtered = bookmarks.filter(b => !(b.userId === currentUser.id && b.postId === postId));
        localStorage.setItem('xvo_bookmarks', JSON.stringify(filtered));
    }

    isBookmarked(postId) {
        const currentUser = this.getCurrentUser();
        if (!currentUser) return false;
        const bookmarks = JSON.parse(localStorage.getItem('xvo_bookmarks') || '[]');
        return bookmarks.some(b => b.userId === currentUser.id && b.postId === postId);
    }

    async getConversations(userId) {
        try {
            const response = await fetch(`${this.apiUrl}/api/messages/${userId}`, {
                headers: { 'x-user-id': userId.toString() }
            });
            if (response.ok) return await response.json();
            return [];
        } catch (error) {
            return [];
        }
    }

    async getMessages(userId, otherUserId) {
        try {
            const response = await fetch(`${this.apiUrl}/api/messages/${userId}/${otherUserId}`, {
                headers: { 'x-user-id': userId.toString() }
            });
            if (response.ok) return await response.json();
            return [];
        } catch (error) {
            return [];
        }
    }

    async sendMessage(senderId, receiverId, text) {
        try {
            const response = await fetch(`${this.apiUrl}/api/messages`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'x-user-id': senderId.toString()
                },
                body: JSON.stringify({ senderId, receiverId, text })
            });
            if (response.ok) return await response.json();
            throw new Error('Failed to send message');
        } catch (error) {
            throw error;
        }
    }

    async getIPLogs(adminId) {
        try {
            const response = await fetch(`${this.apiUrl}/api/admin/all-ip-logs?adminId=${adminId}`);
            if (response.ok) return await response.json();
            return [];
        } catch (error) {
            return [];
        }
    }
}

// ========== APP CLASS ==========
class App {
    constructor() {
        this.db = new Database();
        this.currentView = 'home';
        this.viewingUserId = null;
        this.currentConversationUserId = null;
        this.pendingMedia = null;
        this.pendingMediaType = null;
        this.notificationTab = 'all';
        this.profileTab = 'posts';
        this.messageRefreshInterval = null;
        this.init();
    }

    async init() {
        await this.db.init();
        this.loadTheme();
        this.attachAuthEventListeners();
        
        const path = window.location.pathname;
        const isSharedLink = /^\/users\/@\w+|^\/posts\/\d+/.test(path);
        
        if (!this.db.isAuthenticated()) {
            if (isSharedLink) {
                await this.startGuestMode();
            } else {
                this.showAuthModal();
            }
        } else {
            // Auto-redirect authenticated users to /feed if on root or auth pages
            if (path === '/' || path === '/login' || path === '/signup') {
                window.history.replaceState({}, '', '/feed');
            }
            await this.startApp();
        }
    }
    
    async startGuestMode() {
        this.guestMode = true;
        this.hideAuthModal();
        this.setupUIContainers();
        
        // Show join modal
        const guestModal = document.getElementById('guestJoinModal');
        if (guestModal) {
            guestModal.classList.add('active');
        }
        
        // Load accounts FIRST
        try {
            const accountsResponse = await fetch(`${this.db.apiUrl}/api/accounts`);
            if (accountsResponse.ok) {
                const accounts = await accountsResponse.json();
                if (accounts.length > 0) {
                    localStorage.setItem('accounts', JSON.stringify(accounts));
                }
            }
        } catch (e) {
            console.log('Failed to load accounts');
        }
        
        // Then load posts
        try {
            const postsResponse = await fetch(`${this.db.apiUrl}/api/posts`);
            if (postsResponse.ok) {
                const posts = await postsResponse.json();
                localStorage.setItem('xvo_posts', JSON.stringify(posts));
            }
        } catch (e) {
            console.log('Failed to load posts');
        }
        
        // Attach global click handler for guest mode
        document.body.addEventListener('click', (e) => this.handleGlobalClick(e));
        
        // Now setup routing with data available
        this.setupRouting();
    }
    
    setupUIContainers() {
        const mainContent = document.getElementById('mainContent');
        if (!mainContent) {
            const container = document.createElement('div');
            container.id = 'mainContent';
            container.innerHTML = '<div style="padding: 32px 16px; text-align: center; color: var(--text-secondary);"><p>Loading...</p></div>';
            document.body.appendChild(container);
        }
        
        const header = document.getElementById('header');
        if (!header) {
            const headerDiv = document.createElement('div');
            headerDiv.id = 'header';
            headerDiv.className = 'header';
            document.body.insertBefore(headerDiv, document.body.firstChild);
        }
    }

    attachAuthEventListeners() {
        document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('signupForm').addEventListener('submit', (e) => this.handleSignup(e));
        
        document.querySelectorAll('.auth-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
                tab.classList.add('active');
                const form = tab.dataset.tab === 'login' ? 'loginForm' : 'signupForm';
                document.getElementById(form).classList.add('active');
            });
        });
    }

    loadTheme() {
        const theme = localStorage.getItem('xvo_theme') || 'light';
        document.documentElement.setAttribute('data-theme', theme);
    }

    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('xvo_theme', next);
    }

    showAuthModal() {
        document.getElementById('authModal').classList.add('active');
    }

    hideAuthModal() {
        document.getElementById('authModal').classList.remove('active');
    }

    async startApp() {
        this.hideAuthModal();
        
        const user = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/site-status`);
            const status = await res.json();
            if (status.maintenanceMode && user && !user.isAdmin) {
                document.getElementById('mainContent').innerHTML = `
                    <div class="maintenance-banner">
                        <i class="fas fa-tools" style="font-size: 48px; margin-bottom: 16px;"></i>
                        <h2>Site Under Maintenance</h2>
                        <p>We're currently performing maintenance. Please check back later.</p>
                    </div>
                `;
                document.getElementById('fabBtn').style.display = 'none';
                return;
            }
        } catch (e) {}
        
        // Reload posts after login
        await this.db.reloadPosts();
        
        this.updateUserUI();
        this.attachEventListeners();
        this.setupRouting();
        this.updateNotificationBadge();
        this.checkAdminNav();
        
        // Start real-time post polling
        this.startPostPolling();
    }

    startPostPolling() {
        // Poll for new posts every 5 seconds
        if (this.postPollingInterval) clearInterval(this.postPollingInterval);
        this.postPollingInterval = setInterval(async () => {
            try {
                await this.db.reloadPosts();
                // Only re-render if on home feed
                if (this.currentView === 'home' && document.getElementById('homeFeed')) {
                    this.renderFeed('homeFeed');
                }
            } catch (err) {
                console.log('Post polling error:', err);
            }
        }, 5000);
    }

    setupRouting() {
        window.addEventListener('popstate', () => this.handleRouteChange());
        this.handleRouteChange().catch(console.error);
    }

    async handleRouteChange() {
        const path = window.location.pathname;
        
        // Route mapping
        const routeMap = {
            '/': 'home',
            '/feed': 'home',
            '/login': 'home',
            '/signup': 'home',
            '/search': 'search',
            '/settings': 'settings',
            '/notifications': 'notifications',
            '/messages': 'messages',
            '/mentions': 'mentions',
            '/profile': 'profile',
            '/bookmarks': 'bookmarks',
            '/lists': 'lists',
            '/topics': 'topics',
            '/moments': 'moments',
            '/help': 'help',
            '/admin-panel': 'admin',
            '/adminpanel': 'admin',
            '/admin': 'admin',
            '/tos': 'tos',
            '/privacy': 'privacy',
            '/support': 'support'
        };
        
        // Check for search with query
        const searchMatch = path.match(/\/search\/(.+)/);
        if (searchMatch) {
            const query = decodeURIComponent(searchMatch[1]);
            this.switchView('search');
            this.performSearch(query);
            setTimeout(() => this.attachGuestEventListeners(), 100);
            return;
        }
        
        // Check for direct message with username
        const dmMatch = path.match(/\/messages\/([a-zA-Z0-9_]+)/);
        if (dmMatch) {
            const username = dmMatch[1];
            const accounts = this.db.getAccounts();
            const targetUser = accounts.find(acc => acc.username.toLowerCase() === username.toLowerCase());
            if (targetUser) {
                await this.openConversation(targetUser.id);
            }
            setTimeout(() => this.attachGuestEventListeners(), 100);
            return;
        }
        
        // Check for user profiles
        const userMatch = path.match(/\/users\/@(\w+)/);
        if (userMatch) {
            const username = userMatch[1];
            this.viewProfileByUsername(username);
            setTimeout(() => this.attachGuestEventListeners(), 100);
            return;
        }
        
        // Check for post details (works for both logged-in and guest users)
        const postMatch = path.match(/\/posts\/(\d+)/);
        if (postMatch) {
            const postId = parseInt(postMatch[1]);
            await this.viewPostDetail(postId);
            this.attachGuestEventListeners();
            return;
        }
        
        // Check for standard routes
        const normalizedPath = path.toLowerCase();
        const view = routeMap[normalizedPath] || (this.guestMode ? null : 'home');
        
        if (view && !this.guestMode) {
            this.switchView(view);
        }
        
        setTimeout(() => this.attachGuestEventListeners(), 100);
    }

    navigate(view) {
        // Map view names to URL paths
        const pathMap = {
            'home': '/feed',
            'search': '/search',
            'notifications': '/notifications',
            'messages': '/messages',
            'mentions': '/mentions',
            'profile': '/profile',
            'settings': '/settings',
            'bookmarks': '/bookmarks',
            'lists': '/lists',
            'topics': '/topics',
            'moments': '/moments',
            'help': '/help',
            'admin': '/admin-panel',
            'tos': '/tos',
            'privacy': '/privacy',
            'support': '/support'
        };
        
        const path = pathMap[view] || '/feed';
        this.pushRoute(path);
        this.switchView(view);
    }

    attachGuestEventListeners() {
        document.querySelectorAll('[data-action="back"]').forEach(btn => {
            if (!btn.hasAttribute('data-listener-attached')) {
                btn.addEventListener('click', () => window.history.back());
                btn.setAttribute('data-listener-attached', 'true');
            }
        });
        document.querySelectorAll('[data-action="view-user"]').forEach(el => {
            if (!el.hasAttribute('data-listener-attached')) {
                el.addEventListener('click', () => {
                    const userId = parseInt(el.dataset.userId);
                    this.viewProfile(userId);
                });
                el.setAttribute('data-listener-attached', 'true');
            }
        });
    }

    pushRoute(path) {
        window.history.pushState({}, '', path);
    }
    
    async viewPostDetail(postId) {
        let mainContent = document.getElementById('mainContent');
        let header = document.getElementById('header');
        
        // Create containers if they don't exist
        if (!mainContent) {
            mainContent = document.createElement('div');
            mainContent.id = 'mainContent';
            document.body.appendChild(mainContent);
        }
        if (!header) {
            header = document.createElement('div');
            header.id = 'header';
            document.body.insertBefore(header, document.body.firstChild);
        }
        
        // Push route first
        this.pushRoute(`/posts/${postId}`);
        
        // Set header immediately
        header.innerHTML = '<div class="header-left"><button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button><div><div class="header-title">Post</div></div></div>';
        
        // Ensure data is loaded
        let posts = this.db.getPosts();
        if (posts.length === 0) {
            try {
                await this.db.reloadPosts();
                posts = this.db.getPosts();
            } catch (e) {
                console.log('Post load error:', e);
            }
        }
        
        const post = this.db.getPost(postId);
        if (!post) {
            mainContent.innerHTML = '<div style="padding:32px 16px;text-align:center;color:var(--text-secondary);">Post #' + postId + ' not found</div>';
            this.attachGuestEventListeners();
            return;
        }
        
        const author = this.db.getAccount(post.userId);
        if (!author) {
            mainContent.innerHTML = '<div style="padding:32px 16px;text-align:center;color:var(--text-secondary);">Author not found</div>';
            this.attachGuestEventListeners();
            return;
        }
        
        const currentUser = this.db.getCurrentUser();
        let html = '<div style="display:flex;flex-direction:column;">';
        
        // Author
        html += '<div style="padding:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;"><div style="display:flex;gap:8px;"><img src="' + author.avatar + '" style="width:40px;height:40px;border-radius:50%;" data-action="view-user" data-user-id="' + author.id + '"><div><div style="font-weight:600;cursor:pointer;" data-action="view-user" data-user-id="' + author.id + '">' + (author.displayName || author.name) + '</div><div style="color:var(--text-secondary);font-size:12px;" data-action="view-user" data-user-id="' + author.id + '">@' + author.username + '</div></div></div>';
        if (currentUser && currentUser.id !== author.id) {
            html += '<button style="background:#000;color:#fff;border:none;border-radius:20px;padding:6px 16px;font-weight:600;cursor:pointer;font-size:12px;" data-action="follow-user" data-user-id="' + author.id + '">' + (author.followers?.includes(currentUser.id) ? 'Following' : 'Follow') + '</button>';
        }
        html += '</div>';
        
        // Content
        html += '<div style="padding:16px;"><div style="font-size:20px;line-height:1.5;margin-bottom:12px;">' + (post.text || '') + '</div>';
        if (post.image) html += '<img src="' + post.image + '" style="width:100%;border-radius:8px;margin-bottom:12px;max-height:400px;object-fit:cover;">';
        html += '</div>';
        
        // Stats & Time
        const time = new Date(post.timestamp);
        html += '<div style="padding:12px 16px;border-top:1px solid var(--border-color);border-bottom:1px solid var(--border-color);color:var(--text-secondary);font-size:12px;">' + time.toLocaleTimeString() + ' · ' + time.toLocaleDateString() + ' · ' + (post.views?.length||0) + ' views</div>';
        
        // Buttons
        html += '<div style="display:flex;justify-content:space-around;padding:12px 0;border-bottom:1px solid var(--border-color);color:var(--text-secondary);font-size:12px;"><div data-action="toggle-comments" data-post-id="' + post.id + '" style="cursor:pointer;text-align:center;flex:1;"><i class="far fa-comment"></i><div>' + (post.comments?.length||0) + '</div></div><div data-action="toggle-retweet" data-post-id="' + post.id + '" style="cursor:pointer;text-align:center;flex:1;"><i class="fas fa-retweet"></i><div>' + (post.retweets?.length||0) + '</div></div><div data-action="toggle-like" data-post-id="' + post.id + '" style="cursor:pointer;text-align:center;flex:1;color:' + (currentUser && post.likes?.includes(currentUser.id)?'#ef4444':'inherit') + ';"><i class="' + (currentUser && post.likes?.includes(currentUser.id)?'fas':'far') + ' fa-heart"></i><div>' + (post.likes?.length||0) + '</div></div><div data-action="toggle-bookmark" data-post-id="' + post.id + '" style="cursor:pointer;text-align:center;flex:1;"><i class="far fa-bookmark"></i></div></div>';
        
        // Replies
        const replies = post.comments || [];
        if (replies.length > 0) {
            html += '<div style="padding:12px 16px;color:var(--text-secondary);font-size:12px;font-weight:600;border-bottom:1px solid var(--border-color);">Replies</div>';
            replies.slice(0, 5).forEach(r => {
                const ra = this.db.getAccount(r.userId);
                if (ra) html += '<div style="padding:12px 16px;border-bottom:1px solid var(--border-color);"><div style="font-weight:600;font-size:13px;" data-action="view-user" data-user-id="' + ra.id + '">' + (ra.displayName || ra.name) + '</div><div style="color:var(--text-secondary);font-size:11px;" data-action="view-user" data-user-id="' + ra.id + '">@' + ra.username + '</div><div style="margin-top:4px;font-size:13px;">' + r.text + '</div></div>';
            });
        }
        
        html += '</div>';
        mainContent.innerHTML = html;
        this.attachGuestEventListeners();
    }

    updateUserUI() {
        const user = this.db.getCurrentUser();
        if (!user) return;

        document.getElementById('headerAvatar').src = user.avatar;
        document.getElementById('drawerAvatar').src = user.avatar;
        document.getElementById('drawerName').textContent = user.displayName || user.name;
        document.getElementById('drawerUsername').textContent = '@' + user.username;
        document.getElementById('drawerFollowing').textContent = user.following?.length || 0;
        document.getElementById('drawerFollowers').textContent = user.followers?.length || 0;
        
        const composeAvatar = document.getElementById('composeModalAvatar');
        if (composeAvatar) composeAvatar.src = user.avatar;
    }

    checkAdminNav() {
        const user = this.db.getCurrentUser();
        const adminNav = document.getElementById('adminNavItem');
        if (user && user.isAdmin) {
            adminNav.style.display = 'block';
        } else {
            adminNav.style.display = 'none';
        }
    }

    updateNotificationBadge() {
        const user = this.db.getCurrentUser();
        if (!user) return;
        const notifications = this.db.getNotifications().filter(n => n.userId === user.id && !n.read);
        const badge = document.getElementById('notifBadge');
        if (notifications.length > 0) {
            badge.textContent = notifications.length > 99 ? '99+' : notifications.length;
            badge.classList.remove('hidden');
        } else {
            badge.classList.add('hidden');
        }
    }

    attachEventListeners() {
        // Sidebar toggle
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());
        document.getElementById('sidebarOverlay').addEventListener('click', () => this.closeSidebar());

        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            this.toggleTheme();
            Toast.success('Theme changed!');
        });

        // Bottom nav
        document.querySelectorAll('.bottom-nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const view = item.dataset.view;
                this.navigate(view);
            });
        });

        // Sidebar nav
        document.querySelectorAll('.sidebar-nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const view = item.dataset.view;
                this.closeSidebar();
                this.navigate(view);
            });
        });

        // FAB
        document.getElementById('fabBtn').addEventListener('click', () => this.showComposeModal());

        // Header settings

        // Global click handler
        document.body.addEventListener('click', (e) => this.handleGlobalClick(e));

        // Media upload
        document.getElementById('mediaUpload').addEventListener('change', (e) => this.handleMediaUpload(e));
        document.getElementById('avatarUpload').addEventListener('change', (e) => this.handleAvatarUpload(e));
        document.getElementById('bannerUpload').addEventListener('change', (e) => this.handleBannerUpload(e));

        // Poll button
        const pollBtn = document.getElementById('pollBtn');
        if (pollBtn) {
            pollBtn.addEventListener('click', () => {
                const pollComposer = document.getElementById('pollComposer');
                if (pollComposer) {
                    pollComposer.classList.toggle('hidden');
                }
            });
        }
    }

    handleGlobalClick(e) {
        const action = e.target.closest('[data-action]')?.dataset.action;
        if (!action) return;

        const target = e.target.closest('[data-action]');

        switch (action) {
            case 'close-compose':
                this.hideComposeModal();
                break;
            case 'close-comments':
                this.hideCommentsModal();
                break;
            case 'post-modal':
                this.createPostFromModal();
                break;
            case 'upload-media-modal':
                document.getElementById('mediaUpload').click();
                break;
            case 'upload-gif-modal':
                document.getElementById('mediaUpload').click();
                break;
            case 'toggle-like':
                this.toggleLike(parseInt(target.dataset.postId));
                break;
            case 'toggle-retweet':
                this.toggleRetweet(parseInt(target.dataset.postId));
                break;
            case 'toggle-comments':
                this.showCommentsModal(parseInt(target.dataset.postId));
                break;
            case 'toggle-bookmark':
                this.toggleBookmark(parseInt(target.dataset.postId));
                break;
            case 'view-profile':
                this.viewProfile(parseInt(target.dataset.userId));
                break;
            case 'follow-user':
                this.toggleFollow(parseInt(target.dataset.userId));
                break;
            case 'edit-profile':
                this.showEditProfileModal();
                break;
            case 'delete-post':
                this.deletePost(parseInt(target.dataset.postId));
                break;
            case 'logout':
                this.logout();
                break;
            case 'request-account-deletion':
                this.requestAccountDeletion();
                break;
            case 'approve-deletion':
                this.approveAccountDeletion(parseInt(target.dataset.userId));
                break;
            case 'deny-deletion':
                this.denyAccountDeletion(parseInt(target.dataset.userId));
                break;
            case 'toggle-private':
                this.togglePrivateAccount();
                break;
            case 'show-following':
                this.showFollowingModal(parseInt(target.dataset.userId) || this.db.getCurrentUser().id);
                break;
            case 'show-followers':
                this.showFollowersModal(parseInt(target.dataset.userId) || this.db.getCurrentUser().id);
                break;
            case 'back':
                this.goBack();
                break;
            case 'view-user':
                this.viewProfile(parseInt(target.dataset.userId));
                break;
            case 'search-trend':
                this.searchTrend(target.dataset.term);
                break;
            case 'upload-avatar':
                document.getElementById('avatarUpload').click();
                break;
            case 'upload-banner':
                document.getElementById('bannerUpload').click();
                break;
            case 'open-conversation':
                this.openConversation(parseInt(target.dataset.userId));
                break;
            case 'send-dm':
                this.sendDM();
                break;
            case 'start-new-dm':
                this.showNewDMModal();
                break;
            case 'add-comment':
                this.addComment(parseInt(target.dataset.postId));
                break;
            case 'delete-comment':
                this.deleteComment(parseInt(target.dataset.postId), parseInt(target.dataset.commentId));
                break;
            case 'like-comment':
                this.toggleCommentLike(parseInt(target.dataset.postId), parseInt(target.dataset.commentId));
                break;
            case 'repost-comment':
                this.toggleCommentRepost(parseInt(target.dataset.postId), parseInt(target.dataset.commentId));
                break;
            case 'reply-comment':
                this.replyToComment(parseInt(target.dataset.postId), parseInt(target.dataset.commentId));
                break;
            case 'report-user':
                this.showReportModal(parseInt(target.dataset.userId), 'user');
                break;
            case 'report-post':
                this.showReportModal(parseInt(target.dataset.postId), 'post');
                break;
            case 'report-comment':
                this.showReportModal(parseInt(target.dataset.commentId), 'comment', { postId: parseInt(target.dataset.postId) });
                break;
            case 'resolve-report':
                this.showReportActionModal(parseInt(target.dataset.reportId));
                break;
            case 'take-action':
                // Action buttons are handled by event listeners in showReportActionModal
                break;
            case 'execute-suspend':
                // Suspend buttons are handled by event listeners in showSuspendModal
                break;
            case 'submit-report':
                // Report submission is handled by event listeners in showReportModal
                break;
            case 'verify-user':
                this.verifyUser(parseInt(target.dataset.userId));
                break;
            case 'suspend-user':
                this.suspendUser(parseInt(target.dataset.userId));
                break;
            case 'unsuspend-user':
                this.unsuspendUser(parseInt(target.dataset.userId));
                break;
            case 'make-admin':
                this.makeAdmin(parseInt(target.dataset.userId));
                break;
            case 'remove-admin':
                this.removeAdmin(parseInt(target.dataset.userId));
                break;
            case 'toggle-maintenance':
                this.toggleMaintenance();
                break;
            case 'admin-send-message':
                this.openConversation(parseInt(target.dataset.userId));
                break;
            case 'view-ip-logs':
                this.showIPLogsModal(parseInt(target.dataset.userId));
                break;
            case 'toggle-rainbow':
                this.toggleRainbow(parseInt(target.dataset.userId));
                break;
            case 'reset-user-password':
                this.showResetPasswordModal(parseInt(target.dataset.userId));
                break;
            case 'reset-user-username':
                this.showResetUsernameModal(parseInt(target.dataset.userId));
                break;
            case 'change-password':
                this.showChangePasswordModal();
                break;
            case 'set-announcement':
                this.setAnnouncement();
                break;
            case 'clear-announcement':
                this.clearAnnouncement();
                break;
            case 'send-ias':
                this.sendIAS();
                break;
            case 'clear-ias':
                this.clearIAS();
                break;
            case 'delete-account':
                this.deleteAccount(parseInt(target.dataset.userId));
                break;
            case 'blacklist-user-btn':
                this.handleBlacklistUser(parseInt(target.dataset.userId));
                break;
            case 'reset-user-avatar':
                this.resetUserAvatar(parseInt(target.dataset.userId));
                break;
            case 'clear-user-posts':
                this.clearUserPosts(parseInt(target.dataset.userId));
                break;
            case 'issue-badge':
                this.showIssueBadgeModal(parseInt(target.dataset.userId));
                break;
            case 'remove-badge':
                this.removeBadge(parseInt(target.dataset.userId));
                break;
            case 'block-user':
                this.blockUser(parseInt(target.dataset.userId));
                break;
            case 'unblock-user':
                this.unblockUser(parseInt(target.dataset.userId));
                break;
            case 'vote-poll':
                const postId = parseInt(target.dataset.postId);
                const optionIndex = parseInt(target.dataset.optionIndex);
                if (!isNaN(postId) && !isNaN(optionIndex)) {
                    this.votePoll(postId, optionIndex);
                }
                break;
        }
    }

    toggleSidebar() {
        document.getElementById('sidebarDrawer').classList.add('active');
        document.getElementById('sidebarOverlay').classList.add('active');
    }

    closeSidebar() {
        document.getElementById('sidebarDrawer').classList.remove('active');
        document.getElementById('sidebarOverlay').classList.remove('active');
    }

    switchView(view) {
        this.currentView = view;
        this.closeSidebar();

        // Update bottom nav
        document.querySelectorAll('.bottom-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.view === view);
        });

        const header = document.getElementById('header');
        const mainContent = document.getElementById('mainContent');
        const fab = document.getElementById('fabBtn');

        // Show/hide FAB
        fab.style.display = ['home', 'search', 'notifications', 'mentions'].includes(view) ? 'flex' : 'none';
        if (view === 'conversation') {
            fab.style.display = 'none';
        }

        switch (view) {
            case 'home':
                this.renderHome(header, mainContent);
                break;
            case 'search':
                this.renderSearch(header, mainContent);
                break;
            case 'notifications':
                this.renderNotifications(header, mainContent);
                break;
            case 'messages':
                this.renderMessages(header, mainContent);
                break;
            case 'mentions':
                this.renderMentions(header, mainContent);
                break;
            case 'profile':
                this.viewProfile(this.db.getCurrentUser().id);
                break;
            case 'settings':
                this.renderSettings(header, mainContent);
                break;
            case 'bookmarks':
                this.renderBookmarks(header, mainContent);
                break;
            case 'lists':
                this.renderLists(header, mainContent);
                break;
            case 'topics':
                this.renderTopics(header, mainContent);
                break;
            case 'moments':
                this.renderMoments(header, mainContent);
                break;
            case 'help':
                this.renderHelp(header, mainContent);
                break;
            case 'admin':
                this.renderAdmin(header, mainContent);
                break;
            case 'tos':
                this.renderTOS(header, mainContent);
                break;
            case 'privacy':
                this.renderPrivacyPolicy(header, mainContent);
                break;
            case 'support':
                this.renderSupport(header, mainContent);
                break;
        }
    }

    async votePoll(postId, optionIndex) {
        const user = this.db.getCurrentUser();
        if (!user) {
            Toast.error('Please login to vote');
            return;
        }

        console.log(`Voting for post ${postId}, option ${optionIndex}`);

        try {
            const response = await fetch(`${this.db.apiUrl}/api/posts/${postId}/vote`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: user.id, optionIndex })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to vote');
            }

            const updatedPost = await response.json();
            console.log('Vote successful, updated post:', updatedPost);
            this.db.updatePost(updatedPost);
            this.refreshCurrentView();
            Toast.success('Vote recorded!');
        } catch (error) {
            console.error('Vote error:', error);
            Toast.error(error.message);
        }
    }

    async renderHome(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <img src="${user.avatar}" alt="Profile" class="header-avatar" id="headerAvatar">
            </div>
            <div class="header-center">
                <span class="header-title">XVO</span>
            </div>
            <div class="header-right">
                <div class="header-icon" onclick="app.toggleTheme()">
                    <i class="fas fa-moon" id="themeIcon"></i>
                </div>
            </div>
        `;
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());

        let announcementHTML = '';
        try {
            const res = await fetch(`${this.db.apiUrl}/api/announcements`);
            const announcements = await res.json();
            if (announcements.ias) {
                announcementHTML += `<div class="announcement-banner ias"><i class="fas fa-exclamation-triangle"></i> ${announcements.ias.text}</div>`;
            }
            if (announcements.announcement) {
                announcementHTML += `<div class="announcement-banner"><i class="fas fa-bullhorn"></i> ${announcements.announcement.text}</div>`;
            }
        } catch (e) {}

        mainContent.innerHTML = `
            ${announcementHTML}
            <div class="feed" id="homeFeed"></div>
        `;

        this.renderFeed('homeFeed');
    }

    getMentionedUsers(text) {
        const mentionRegex = /@(\w+)/g;
        const mentions = [];
        let match;
        while ((match = mentionRegex.exec(text)) !== null) {
            const username = match[1];
            const user = this.db.getAccounts().find(u => u.username.toLowerCase() === username.toLowerCase());
            if (user && !mentions.find(m => m.id === user.id)) {
                mentions.push(user);
            }
        }
        return mentions;
    }

    formatTextWithMentions(text) {
        return text.replace(/@(\w+)/g, (match, username) => {
            const user = this.db.getAccounts().find(u => u.username.toLowerCase() === username.toLowerCase());
            if (user) {
                return `<span class="mention-tag" data-action="view-profile" data-user-id="${user.id}" style="color: var(--xvo-blue); cursor: pointer; font-weight: 600;">@${username}</span>`;
            }
            return match;
        });
    }

    renderFeed(containerId, posts = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const postsToRender = posts || this.db.getPosts();
        const currentUser = this.db.getCurrentUser();
        const blockedUsers = JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]');
        
        // Filter out posts from blocked users and private accounts (only mutual followers)
        const filteredPosts = postsToRender.filter(post => {
            if (blockedUsers.includes(post.userId)) return false;
            const author = this.db.getAccount(post.userId);
            if (!author) return false;
            if (author.isPrivate && post.userId !== currentUser.id) {
                // Check if mutual followers (both follow each other)
                const userFollowsAuthor = currentUser.following?.includes(post.userId);
                const authorFollowsUser = author.followers?.includes(currentUser.id);
                if (!userFollowsAuthor || !authorFollowsUser) {
                    return false;
                }
            }
            return true;
        });
        
            // Track views
            filteredPosts.forEach(post => {
                if (!post.views) post.views = [];
                if (currentUser && !post.views.includes(currentUser.id)) {
                    post.views.push(currentUser.id);
                    this.db.updatePost(post);
                }
            });

        if (filteredPosts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="far fa-newspaper"></i>
                    <h3>No posts yet</h3>
                    <p>When people post, you'll see them here.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filteredPosts.map(post => {
            const author = this.db.getAccount(post.userId);
            if (!author) return '';
            const isLiked = post.likes?.includes(currentUser.id);
            const isRetweeted = post.retweets?.includes(currentUser.id);
            const isBookmarked = this.db.isBookmarked(post.id);
            const isOwnPost = post.userId === currentUser.id;

            let pollHTML = '';
            if (post.poll) {
                const totalVotes = post.poll.options.reduce((acc, opt) => acc + ((opt.votes && Array.isArray(opt.votes)) ? opt.votes.length : 0), 0);
                const hasVoted = post.poll.options.some(opt => opt.votes && Array.isArray(opt.votes) && opt.votes.includes(currentUser.id));
                const isPollOwner = post.userId === currentUser.id;
                
                pollHTML = `
                    <div class="poll-display" data-post-id="${post.id}">
                        ${post.poll.options.map((opt, index) => {
                            const voteCount = (opt.votes && Array.isArray(opt.votes)) ? opt.votes.length : 0;
                            const percent = totalVotes === 0 ? 0 : Math.round((voteCount / totalVotes) * 100);
                            const voters = (opt.votes && Array.isArray(opt.votes)) ? opt.votes.filter(v => typeof v === 'number') : [];
                            const voterNames = isPollOwner && voters.length > 0 ? voters.map(vid => {
                                const voter = this.db.getAccount(vid);
                                return voter ? (voter.displayName || voter.name) : 'Unknown';
                            }).join(', ') : '';
                            
                            return `
                                <div class="poll-option" data-action="vote-poll" data-post-id="${post.id}" data-option-index="${index}" style="cursor: ${hasVoted ? 'default' : 'pointer'};">
                                    <div class="poll-bar" style="width: ${percent}%"></div>
                                    <div class="poll-option-text">
                                        <span>${opt.text}</span>
                                        <span>${percent}%</span>
                                        ${isPollOwner && voterNames ? `<div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">Voters: ${voterNames}</div>` : ''}
                                    </div>
                                </div>
                            `;
                        }).join('')}
                        <div class="poll-votes-count">${totalVotes} ${totalVotes === 1 ? 'vote' : 'votes'}</div>
                    </div>
                `;
            }

            return `
                <div class="post" data-post-id="${post.id}">
                    <img src="${author.avatar}" class="post-avatar" data-action="view-profile" data-user-id="${author.id}">
                    <div class="post-content">
                        <div class="post-header">
                            <span class="post-name" data-action="view-profile" data-user-id="${author.id}">${this.getNameHTML(author)}${this.getBadgeHTML(author)}</span>
                            <span class="post-username">@${author.username}</span>
                            <span class="post-dot">·</span>
                            <span class="post-time">${this.formatTime(post.timestamp)}</span>
                            ${isOwnPost ? `<span class="post-more" data-action="delete-post" data-post-id="${post.id}"><i class="fas fa-trash"></i></span>` : ''}
                        </div>
                        <div class="post-text">${this.formatTextWithMentions(this.linkify(post.text))}</div>
                        ${pollHTML}
                        ${post.linkPreview ? `
                            <a href="${post.linkPreview.url}" target="_blank" style="text-decoration: none; color: inherit;">
                                <div style="border: 1px solid var(--border-color); border-radius: 12px; overflow: hidden; margin-top: 12px; display: flex; background: var(--bg-secondary);">
                                    ${post.linkPreview.image ? `<img src="${post.linkPreview.image}" alt="Preview" style="width: 120px; height: 120px; object-fit: cover; flex-shrink: 0;">` : ''}
                                    <div style="flex: 1; padding: 12px; display: flex; flex-direction: column; justify-content: center; min-width: 0;">
                                        <div style="font-weight: 600; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 14px;">${post.linkPreview.title}</div>
                                        ${post.linkPreview.description ? `<div style="font-size: 13px; color: var(--text-secondary); margin-top: 4px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">${post.linkPreview.description}</div>` : ''}
                                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 6px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${new URL(post.linkPreview.url).hostname}</div>
                                    </div>
                                </div>
                            </a>
                        ` : ''}
                        ${post.image ? `<div class="post-media"><img src="${post.image}" alt="Post media"></div>` : ''}
                        ${post.video ? `<div class="post-media"><video src="${post.video}" controls></video></div>` : ''}
                        <div class="post-actions">
                            <button class="post-action" data-action="toggle-comments" data-post-id="${post.id}">
                                <span class="post-action-icon"><i class="far fa-comment"></i></span>
                                <span>${post.comments?.length || 0}</span>
                            </button>
                            <button class="post-action ${isRetweeted ? 'retweeted' : ''}" data-action="toggle-retweet" data-post-id="${post.id}">
                                <span class="post-action-icon"><i class="fas fa-retweet"></i></span>
                                <span>${post.retweets?.length || 0}</span>
                            </button>
                            <button class="post-action ${isLiked ? 'liked' : ''}" data-action="toggle-like" data-post-id="${post.id}">
                                <span class="post-action-icon"><i class="${isLiked ? 'fas' : 'far'} fa-heart"></i></span>
                                <span>${post.likes?.length || 0}</span>
                            </button>
                            <button class="post-action ${isBookmarked ? 'liked' : ''}" data-action="toggle-bookmark" data-post-id="${post.id}">
                                <span class="post-action-icon"><i class="${isBookmarked ? 'fas' : 'far'} fa-bookmark"></i></span>
                            </button>
                            <button class="post-action" style="pointer-events: none; color: var(--text-secondary);">
                                <span class="post-action-icon"><i class="fas fa-eye"></i></span>
                                <span>Views: ${post.views?.length || 0}</span>
                            </button>
                            <button class="post-action" onclick="app.toggleBookmark(${post.id})">
                                <span class="post-action-icon"><i class="far fa-bookmark"></i></span>
                            </button>
                            <button class="post-action danger" data-action="report-post" data-post-id="${post.id}" style="color: var(--danger);">
                                <span class="post-action-icon"><i class="fas fa-flag"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    renderSearch(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <img src="${user.avatar}" alt="Profile" class="header-avatar" id="headerAvatar">
            </div>
            <div class="header-center">
                <div class="search-input-wrapper" style="width: 250px;">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search XVO" id="searchInput">
                </div>
            </div>
            <div class="header-right">
                <div class="header-icon" onclick="app.toggleTheme()">
                    <i class="fas fa-moon" id="themeIcon"></i>
                </div>
            </div>
        `;
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());
        document.getElementById('searchInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.performSearch(e.target.value);
        });

        const trends = this.getTrends();
        
        mainContent.innerHTML = `
            <div class="trends-header">Trends for you</div>
            ${trends.length > 0 ? trends.map(trend => `
                <div class="trend-item" data-action="search-trend" data-term="${trend.name}">
                    <div class="trend-category">Trending</div>
                    <div class="trend-name">${trend.name}</div>
                    <div class="trend-count">${trend.count} posts</div>
                </div>
            `).join('') : `
                <div class="no-trends">
                    <h3>No new trends for you</h3>
                    <p>It seems like there's not a lot to show you right now, but you can see trends for other areas</p>
                    <button class="change-location-btn">Change location</button>
                </div>
            `}
        `;
    }

    getTrends() {
        const posts = this.db.getPosts();
        const wordCounts = {};
        const stopWords = ['the', 'a', 'an', 'is', 'are', 'was', 'were', 'in', 'on', 'at', 'to', 'for', 'of', 'and', 'or', 'but', 'it', 'this', 'that', 'i', 'you', 'he', 'she', 'we', 'they', 'my', 'your'];

        posts.forEach(post => {
            const words = post.text.toLowerCase().match(/\b[\w#]+\b/g) || [];
            words.forEach(word => {
                if (word.length > 3 && !stopWords.includes(word)) {
                    wordCounts[word] = (wordCounts[word] || 0) + 1;
                }
            });
        });

        return Object.entries(wordCounts)
            .filter(([_, count]) => count >= 2)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([name, count]) => ({ name, count }));
    }

    performSearch(query) {
        if (!query.trim()) return;
        // Push URL update
        const encodedQuery = encodeURIComponent(query);
        this.pushRoute(`/search/${encodedQuery}`);
        
        const mainContent = document.getElementById('mainContent');
        const posts = this.db.getPosts().filter(p => 
            p.text.toLowerCase().includes(query.toLowerCase())
        );
        const users = this.db.getAccounts().filter(u => 
            !u.isDeleted && (
                u.username.toLowerCase().includes(query.toLowerCase()) ||
                u.name.toLowerCase().includes(query.toLowerCase())
            )
        );

        mainContent.innerHTML = `
            <div class="trends-header">Search results for "${query}"</div>
            ${users.length > 0 ? `
                <div style="padding: 16px; border-bottom: 1px solid var(--border-color);">
                    <div style="font-weight: 700; margin-bottom: 12px;">People</div>
                    ${users.slice(0, 3).map(u => `
                        <div class="message-item" data-action="view-profile" data-user-id="${u.id}">
                            <img src="${u.avatar}" class="message-avatar">
                            <div class="message-content">
                                <div class="message-name">${u.displayName || u.name}${this.getBadgeHTML(u)}</div>
                                <div class="message-username">@${u.username}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            ` : ''}
            <div id="searchResults"></div>
        `;

        this.renderFeed('searchResults', posts);
    }

    searchTrend(term) {
        document.getElementById('searchInput').value = term;
        this.performSearch(term);
    }

    renderNotifications(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <img src="${user.avatar}" alt="Profile" class="header-avatar" id="headerAvatar">
            </div>
            <div class="header-center">
                <span class="header-title">Notifications</span>
            </div>
            <div class="header-right">
                <div class="header-icon" onclick="app.toggleTheme()">
                    <i class="fas fa-moon" id="themeIcon"></i>
                </div>
            </div>
        `;
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());

        this.db.markAllNotificationsAsRead(user.id);
        this.updateNotificationBadge();

        const notifications = this.db.getNotifications().filter(n => n.userId === user.id);

        mainContent.innerHTML = `
            <div class="notification-tabs">
                <div class="notification-tab ${this.notificationTab === 'all' ? 'active' : ''}" data-tab="all">All</div>
                <div class="notification-tab ${this.notificationTab === 'mentions' ? 'active' : ''}" data-tab="mentions">Mentions</div>
            </div>
            <div id="notificationsList">
                ${notifications.length === 0 ? `
                    <div class="empty-state">
                        <i class="far fa-bell"></i>
                        <h3>Nothing to see here</h3>
                        <p>Likes, mentions, and reposts will show up here.</p>
                    </div>
                ` : notifications.map(n => this.renderNotificationItem(n)).join('')}
            </div>
        `;

        document.querySelectorAll('.notification-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                this.notificationTab = tab.dataset.tab;
                this.renderNotifications(header, mainContent);
            });
        });
    }

    renderNotificationItem(notification) {
        const actor = this.db.getAccount(notification.actorId);
        if (!actor) return '';

        let icon = '', iconClass = '', text = '';
        switch (notification.type) {
            case 'like':
                icon = 'fas fa-heart';
                iconClass = 'like';
                text = `<strong>${actor.displayName || actor.name}</strong> liked your post`;
                break;
            case 'retweet':
                icon = 'fas fa-retweet';
                iconClass = 'retweet';
                text = `<strong>${actor.displayName || actor.name}</strong> retweeted your post`;
                break;
            case 'follow':
                icon = 'fas fa-user-plus';
                iconClass = 'follow';
                text = `<strong>${actor.displayName || actor.name}</strong> followed you`;
                break;
            case 'mention':
                icon = 'fas fa-at';
                iconClass = 'mention';
                text = `<strong>${actor.displayName || actor.name}</strong> mentioned you`;
                break;
            default:
                icon = 'fas fa-star';
                iconClass = 'star';
                text = `<strong>${actor.displayName || actor.name}</strong> interacted with you`;
        }

        return `
            <div class="notification-item" data-action="view-profile" data-user-id="${actor.id}">
                <div class="notification-icon ${iconClass}">
                    <i class="${icon}"></i>
                </div>
                <div class="notification-content">
                    <div class="notification-avatars">
                        <img src="${actor.avatar}" class="notification-avatar">
                    </div>
                    <div class="notification-text">${text}</div>
                    ${notification.postText ? `<div class="notification-post">${notification.postText}</div>` : ''}
                    <div class="admin-section">
                        <div class="admin-section-title">Blacklist Management</div>
                        <div class="form-group">
                            <input type="text" class="form-input" id="blacklistIpInput" placeholder="IP Address to block">
                            <input type="number" class="form-input" id="blacklistUserIdInput" placeholder="User ID to block (optional)" style="margin-top: 8px;">
                            <button class="submit-btn" style="margin-top: 12px; background: var(--danger);" onclick="app.blacklistIP()">Blacklist IP/User</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    async handleBlacklistUser(userId) {
        if (!confirm('Are you sure you want to blacklist this user and their last known IP?')) return;
        
        try {
            // Get last IP from logs
            const resLogs = await fetch(`${this.db.apiUrl}/api/admin/ip-logs/${userId}`);
            const logs = await resLogs.json();
            const lastIp = logs.length > 0 ? logs[logs.length - 1].ip : null;
            
            const res = await fetch(`${this.db.apiUrl}/api/admin/blacklist-ip`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: this.db.getCurrentUser().id, ip: lastIp, userId })
            });
            
            if (res.ok) {
                Toast.success('User and IP blacklisted successfully');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                const err = await res.json();
                Toast.error(err.error || 'Failed to blacklist');
            }
        } catch (e) {
            Toast.error('Error blacklisting user');
        }
    }

    async blacklistIP() {
        const ip = document.getElementById('blacklistIpInput').value.trim();
        const userId = parseInt(document.getElementById('blacklistUserIdInput').value);
        if (!ip && !userId) return Toast.error('Provide an IP or User ID');

        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/blacklist-ip`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: this.db.getCurrentUser().id, ip, userId })
            });
            if (res.ok) {
                Toast.success('Blacklisted successfully');
                document.getElementById('blacklistIpInput').value = '';
                document.getElementById('blacklistUserIdInput').value = '';
            } else {
                const err = await res.json();
                Toast.error(err.error || 'Failed to blacklist');
            }
        } catch (e) {
            Toast.error('Network error');
        }
    }

    renderMessages(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <img src="${user.avatar}" alt="Profile" class="header-avatar" id="headerAvatar">
                <span class="header-title">Messages</span>
            </div>
        `;
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());

        this.loadConversations(mainContent);
    }

    async loadConversations(mainContent) {
        const user = this.db.getCurrentUser();
        const apiConversations = await this.db.getConversations(user.id);

        if (apiConversations.length === 0) {
            mainContent.innerHTML = `
                <div class="empty-state">
                    <i class="far fa-envelope"></i>
                    <h3>Welcome to your inbox!</h3>
                    <p>Drop a line, share posts and more with private conversations.</p>
                    <button class="submit-btn" style="max-width: 200px; margin-top: 16px;" data-action="start-new-dm">Write a message</button>
                </div>
            `;
            return;
        }

        // Transform API response to have the properties we need
        const conversations = apiConversations.map(msg => ({
            ...msg,
            lastMessage: msg.text,
            lastMessageTime: msg.timestamp,
            otherUserId: msg.senderId === user.id ? msg.receiverId : msg.senderId
        }));

        mainContent.innerHTML = `
            <div class="messages-list">
                ${conversations.map(conv => {
                    const otherUser = this.db.getAccount(conv.otherUserId);
                    if (!otherUser) return '';
                    return `
                        <div style="display: flex; gap: 8px; width: 100%;">
                            <div class="message-item" data-action="open-conversation" data-user-id="${otherUser.id}" style="flex: 1;">
                                <img src="${otherUser.avatar}" class="message-avatar">
                                <div class="message-content">
                                    <div class="message-header">
                                        <span class="message-name">${otherUser.displayName || otherUser.name}${this.getBadgeHTML(otherUser)}</span>
                                        <span class="message-username">@${otherUser.username}</span>
                                        <span class="message-time">${this.formatTime(conv.lastMessageTime)}</span>
                                    </div>
                                    <div class="message-preview">${conv.lastMessage}</div>
                                </div>
                            </div>
                            <button class="header-icon" data-action="report-user" data-user-id="${otherUser.id}" style="background: none; color: var(--danger); font-size: 14px; padding: 0 8px; min-width: auto; width: auto;" title="Report User"><i class="fas fa-flag"></i></button>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    }

    async openConversation(userId) {
        this.currentConversationUserId = userId;
        const user = this.db.getCurrentUser();
        const otherUser = this.db.getAccount(userId);
        
        // Push URL update with username
        this.pushRoute(`/messages/${otherUser.username}`);
        
        // Hide FAB in conversation
        const fab = document.getElementById('fabBtn');
        if (fab) fab.style.display = 'none';

        const header = document.getElementById('header');
        const mainContent = document.getElementById('mainContent');

        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <img src="${otherUser.avatar}" class="header-avatar" style="cursor: pointer;" data-action="view-profile" data-user-id="${userId}">
                <span class="header-title">${otherUser.displayName || otherUser.name}</span>
            </div>
        `;

        const messages = await this.db.getMessages(user.id, userId);

        mainContent.innerHTML = `
            <div class="conversation-container">
                <div class="conversation-messages" id="conversationMessages">
                    ${this.renderDMList(messages, user)}
                </div>
            </div>
            <div class="dm-compose">
                <input type="text" class="dm-input" placeholder="Start a new message" id="dmInput">
                <button class="dm-send" data-action="send-dm"><i class="fas fa-paper-plane"></i></button>
            </div>
        `;

        document.getElementById('dmInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendDM();
        });

        const messagesContainer = document.getElementById('conversationMessages');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        this.startMessagePolling();
    }

    renderDMList(messages, user) {
        let lastDate = null;
        return messages.map(msg => {
            const date = new Date(msg.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
            let dateDivider = '';
            if (date !== lastDate) {
                dateDivider = `<div class="message-date-divider">${date}</div>`;
                lastDate = date;
            }
            const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            return `
                ${dateDivider}
                <div class="dm-message ${msg.senderId === user.id ? 'sent' : 'received'}">
                    <div class="dm-message-content">
                        <div class="dm-message-text">${msg.text}</div>
                        <div class="dm-message-time">${time}</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    async sendDM() {
        const input = document.getElementById('dmInput');
        const text = input.value.trim();
        if (!text || !this.currentConversationUserId) return;

        const user = this.db.getCurrentUser();
        try {
            const msg = await this.db.sendMessage(user.id, this.currentConversationUserId, text);
            input.value = '';
            
            const messagesContainer = document.getElementById('conversationMessages');
            const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            messagesContainer.innerHTML += `
                <div class="dm-message sent">
                    <div class="dm-message-content">
                        <div class="dm-message-text">${text}</div>
                        <div class="dm-message-time">${time}</div>
                    </div>
                </div>
            `;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } catch (error) {
            Toast.error('Failed to send message');
        }
    }

    startMessagePolling() {
        if (this.messageRefreshInterval) clearInterval(this.messageRefreshInterval);
        this.messageRefreshInterval = setInterval(async () => {
            if (!this.currentConversationUserId) return;
            const user = this.db.getCurrentUser();
            const messages = await this.db.getMessages(user.id, this.currentConversationUserId);
            const container = document.getElementById('conversationMessages');
            if (container) {
                container.innerHTML = this.renderDMList(messages, user);
                container.scrollTop = container.scrollHeight;
            }
        }, 3000);
    }

    stopMessagePolling() {
        if (this.messageRefreshInterval) {
            clearInterval(this.messageRefreshInterval);
            this.messageRefreshInterval = null;
        }
    }

    showNewDMModal() {
        const users = this.db.getAccounts().filter(u => u.id !== this.db.getCurrentUser().id);
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'newDMModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('newDMModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">New message</span>
                </div>
                <div class="modal-body">
                    <input type="text" class="form-input" placeholder="Search people" id="dmSearchInput" style="margin-bottom: 16px;">
                    <div id="dmUserList">
                        ${users.map(u => `
                            <div class="message-item" style="cursor: pointer;" onclick="app.startDMWith(${u.id})">
                                <img src="${u.avatar}" class="message-avatar">
                                <div class="message-content">
                                    <div class="message-name">${u.displayName || u.name}${this.getBadgeHTML(u)}</div>
                                    <div class="message-username">@${u.username}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    startDMWith(userId) {
        document.getElementById('newDMModal')?.remove();
        this.openConversation(userId);
    }

    viewProfileByUsername(username) {
        const user = this.db.getAccounts().find(u => u.username === username);
        if (user) {
            this.viewProfile(user.id);
        } else {
            Toast.error('User not found');
            this.switchView('home');
        }
    }

    async viewProfile(userId) {
        if (!this.guestMode) this.stopMessagePolling();
        
        await this.db.reloadAccounts();
        
        const user = this.db.getAccount(userId);
        if (!user) {
            Toast.error('User not found');
            if (!this.guestMode) this.switchView('home');
            return;
        }
        this.pushRoute(`/users/@${user.username}`);
        this.viewingUserId = userId;
        const currentUser = this.db.getCurrentUser();
        const isOwnProfile = currentUser && user.id === currentUser.id;
        const isFollowing = currentUser && currentUser.following?.includes(user.id);
        const viewerName = currentUser ? (currentUser.displayName || currentUser.name) : '*Unknown Viewer*';
        const userPosts = this.db.getUserPosts(userId);
        const userRetweets = this.db.getUserRetweets(userId);

        const header = document.getElementById('header');
        const mainContent = document.getElementById('mainContent');

        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <div>
                    <div class="header-title">${user.displayName || user.name}</div>
                    <div style="font-size: 13px; color: var(--text-secondary);">${userPosts.length} posts</div>
                </div>
            </div>
        `;

        // Check if account is suspended
        if (user.isSuspended) {
            mainContent.innerHTML = `
                <div class="profile-banner" style="${user.banner ? `background-image: url(${user.banner});` : 'background-color: #1a1a1a;'}"></div>
                <div class="profile-info">
                    <div class="profile-avatar-wrapper">
                        <img src="${user.avatar}" class="profile-avatar-large">
                    </div>
                    <div class="profile-name-section">
                        <div class="profile-name">${user.displayName || user.name}${this.getBadgeHTML(user)}</div>
                        <div class="profile-username">@${user.username}</div>
                    </div>
                    <div class="profile-stats">
                        <span class="profile-stat">
                            <span class="profile-stat-value">${user.following?.length || 0}</span>
                            <span class="profile-stat-label">Following</span>
                        </span>
                        <span class="profile-stat">
                            <span class="profile-stat-value">${user.followers?.length || 0}</span>
                            <span class="profile-stat-label">Followers</span>
                        </span>
                    </div>
                </div>
                <div style="text-align: center; padding: 40px 20px; border-top: 1px solid var(--border-color);">
                    <div style="font-size: 28px; font-weight: 700; margin-bottom: 16px; color: var(--text-primary);">Account suspended</div>
                    <div style="font-size: 15px; color: var(--text-secondary); line-height: 1.5;">
                        XVO suspends accounts that has violated our <span style="color: var(--xvo-blue); cursor: pointer; text-decoration: underline;" onclick="app.navigate('tos')">Terms of Service</span>.
                    </div>
                </div>
            `;
            return;
        }

        const joinDate = user.joinDate ? new Date(user.joinDate).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : (user.username === 'Alz' ? 'October 2025' : 'December 2025');

        mainContent.innerHTML = `
            <div class="profile-banner" style="${user.banner ? `background-image: url(${user.banner});` : ''}"></div>
            ${this.guestMode ? `<div style="padding: 12px 16px; background: var(--bg-secondary); border-bottom: 1px solid var(--border-color); text-align: center; font-size: 14px; color: var(--text-secondary);"><strong>Viewing as:</strong> ${viewerName}</div>` : ''}
            <div class="profile-info">
                <div class="profile-avatar-wrapper">
                    <img src="${user.avatar}" class="profile-avatar-large" ${isOwnProfile ? 'style="cursor: pointer;" data-action="upload-avatar"' : ''}>
                </div>
                <div class="profile-actions">
                    ${!isOwnProfile ? `
                        <button class="profile-action-btn" data-action="open-conversation" data-user-id="${user.id}">
                            <i class="far fa-envelope"></i>
                        </button>
                        ${JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]').includes(user.id) ? 
                            `<button class="profile-action-btn" data-action="unblock-user" data-user-id="${user.id}" style="background: var(--warning-color); color: white; padding: 8px 12px; font-size: 13px; display: flex; align-items: center; gap: 6px; white-space: nowrap;">
                                <i class="fas fa-ban"></i> <span>Unblock</span>
                            </button>` : 
                            `<button class="profile-action-btn" data-action="block-user" data-user-id="${user.id}" style="background: var(--danger); color: white; padding: 8px 12px; font-size: 13px; display: flex; align-items: center; gap: 6px; white-space: nowrap;">
                                <i class="fas fa-ban"></i> <span>Block</span>
                            </button>`
                        }
                        <button class="profile-action-btn danger" data-action="report-user" data-user-id="${user.id}" style="background: #8B0000; color: white;">
                            <i class="fas fa-flag"></i>
                        </button>
                        <button class="follow-btn ${isFollowing ? 'following' : 'not-following'}" data-action="follow-user" data-user-id="${user.id}">
                            ${isFollowing ? 'Following' : 'Follow'}
                        </button>
                    ` : `
                        <button class="edit-profile-btn" data-action="edit-profile">Edit profile</button>
                    `}
                </div>
                <div class="profile-name-section">
                    <div class="profile-name">${user.displayName || user.name}${this.getBadgeHTML(user)}</div>
                    <div class="profile-username">@${user.username}</div>
                </div>
                ${user.bio ? `<div class="profile-bio">${user.bio}</div>` : ''}
                <div class="profile-meta">
                    ${user.website ? `<span class="profile-meta-item"><i class="fas fa-link"></i> <a href="${user.website}" target="_blank">${user.website}</a></span>` : ''}
                    <span class="profile-meta-item"><i class="far fa-calendar"></i> Joined ${joinDate}</span>
                </div>
                <div class="profile-stats">
                    <span class="profile-stat" data-action="show-following" data-user-id="${user.id}">
                        <span class="profile-stat-value">${user.following?.length || 0}</span>
                        <span class="profile-stat-label">Following</span>
                    </span>
                    <span class="profile-stat" data-action="show-followers" data-user-id="${user.id}">
                        <span class="profile-stat-value">${user.followers?.length || 0}</span>
                        <span class="profile-stat-label">Followers</span>
                    </span>
                </div>
            </div>
            <div class="profile-tabs">
                <div class="profile-tab ${this.profileTab === 'posts' ? 'active' : ''}" data-tab="posts">Posts</div>
                <div class="profile-tab ${this.profileTab === 'replies' ? 'active' : ''}" data-tab="replies">Replies</div>
                <div class="profile-tab ${this.profileTab === 'media' ? 'active' : ''}" data-tab="media">Media</div>
                <div class="profile-tab ${this.profileTab === 'likes' ? 'active' : ''}" data-tab="likes">Likes</div>
            </div>
            <div id="profileFeed"></div>
        `;

        document.querySelectorAll('.profile-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                this.profileTab = tab.dataset.tab;
                document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                this.renderProfileFeed(userId);
            });
        });

        this.renderProfileFeed(userId);
    }

    renderProfileFeed(userId) {
        const currentUser = this.db.getCurrentUser();
        const viewedUser = this.db.getAccount(userId);
        const isOwnProfile = currentUser && userId === currentUser.id;
        const userFollowsViewed = currentUser && currentUser.following?.includes(userId);
        const viewedFollowsUser = viewedUser && viewedUser.followers?.includes(currentUser?.id);
        const isMutualFollower = userFollowsViewed && viewedFollowsUser;
        
        // Check if profile is private and user is not the owner or mutual follower
        if (viewedUser?.isPrivate && !isOwnProfile && !isMutualFollower) {
            document.getElementById('profileFeed').innerHTML = `
                <div style="text-align: center; padding: 40px 20px;">
                    <div style="font-size: 48px; margin-bottom: 16px;">🔒</div>
                    <div style="font-size: 24px; font-weight: 700; margin-bottom: 8px; color: var(--text-primary);">These posts are protected.</div>
                    <div style="font-size: 15px; color: var(--text-secondary); line-height: 1.6; max-width: 400px; margin: 0 auto;">
                        Only confirmed followers have access to @${viewedUser.username}'s posts and complete profile. Tap the Follow button to send a follow request.
                    </div>
                </div>
            `;
            return;
        }
        
        let posts = [];
        switch (this.profileTab) {
            case 'posts':
                posts = this.db.getUserPosts(userId);
                break;
            case 'replies':
                posts = [];
                break;
            case 'media':
                posts = this.db.getUserPosts(userId).filter(p => p.image || p.video);
                break;
            case 'likes':
                posts = this.db.getPosts().filter(p => p.likes?.includes(userId));
                break;
        }
        this.renderFeed('profileFeed', posts);
    }


    renderSettings(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
            </div>
            <div class="header-center">
                <span class="header-title">Settings</span>
            </div>
            <div class="header-right"></div>
        `;

        mainContent.style.padding = '0';
        mainContent.innerHTML = `
            <div class="settings-layout">
                <div class="settings-content" id="settingsContentArea">
                    ${this.getSettingsSection('account')}
                    ${this.getSettingsSection('security')}
                    ${this.getSettingsSection('display')}
                    ${this.getSettingsSection('privacy')}
                    ${this.getSettingsSection('about')}
                </div>
            </div>
        `;

        this.attachSettingsListeners('all');
    }

    getSettingsSection(section) {
        const user = this.db.getCurrentUser();
        switch (section) {
            case 'account':
                return `
                    <div class="settings-section">
                        <div class="settings-section-title">Account</div>
                        <div class="settings-card">
                            <div class="settings-row" data-action="edit-profile">
                                <div class="settings-info">
                                    <div class="settings-label">Edit Profile</div>
                                    <div class="settings-value">${user.displayName || user.name}</div>
                                </div>
                                <i class="fas fa-chevron-right" style="color: var(--text-muted);"></i>
                            </div>
                            <div class="settings-row" style="color: var(--danger);" data-action="logout">
                                <div class="settings-info">
                                    <div class="settings-label" style="color: var(--danger);">Log out</div>
                                    <div class="settings-value" style="color: var(--danger);">Sign out of XVO</div>
                                </div>
                                <i class="fas fa-sign-out-alt"></i>
                            </div>
                        </div>
                    </div>
                `;
            case 'security':
                return `
                    <div class="settings-section">
                        <div class="settings-section-title">Security</div>
                        <div class="settings-card">
                            <div class="settings-row" data-action="change-password">
                                <div class="settings-info">
                                    <div class="settings-label">Change Password</div>
                                    <div class="settings-value">Update your password</div>
                                </div>
                                <i class="fas fa-chevron-right" style="color: var(--text-muted);"></i>
                            </div>
                        </div>
                    </div>
                `;
            case 'display':
                const theme = document.documentElement.getAttribute('data-theme') || 'light';
                return `
                    <div class="settings-section">
                        <div class="settings-section-title">Display</div>
                        <div class="settings-card">
                            <div class="settings-row" id="toggleThemeRow">
                                <div class="settings-info">
                                    <div class="settings-label">Dark Mode</div>
                                    <div class="settings-value">${theme === 'dark' ? 'On' : 'Off'}</div>
                                </div>
                                <div class="theme-toggle-switch ${theme === 'dark' ? 'active' : ''}"></div>
                            </div>
                        </div>
                    </div>
                `;
            case 'privacy':
                const deletionStatus = user.deletionRequested ? 'Pending Admin Approval' : 'Not Requested';
                return `
                    <div class="settings-section">
                        <div class="settings-section-title">Privacy</div>
                        <div class="settings-card">
                            <div class="settings-row" id="togglePrivateRow">
                                <div class="settings-info">
                                    <div class="settings-label">Private Account</div>
                                    <div class="settings-value">${user.isPrivate ? 'On' : 'Off'}</div>
                                </div>
                                <div class="theme-toggle-switch ${user.isPrivate ? 'active' : ''}"></div>
                            </div>
                            <div style="color: var(--text-secondary); font-size: 12px; padding: 12px; text-align: center; border-bottom: 1px solid var(--border-color);">
                                Only people you approve can see your posts
                            </div>
                            <div class="settings-row" ${!user.deletionRequested ? `data-action="request-account-deletion"` : ''} style="${user.deletionRequested ? 'pointer-events: none;' : 'cursor: pointer;'}">
                                <div class="settings-info">
                                    <div class="settings-label">Delete Account</div>
                                    <div class="settings-value" style="color: ${user.deletionRequested ? 'var(--warning)' : 'var(--danger)'};">${deletionStatus}</div>
                                </div>
                                ${!user.deletionRequested ? `<i class="fas fa-chevron-right" style="color: var(--text-muted);"></i>` : `<i class="fas fa-clock" style="color: var(--warning);"></i>`}
                            </div>
                        </div>
                        <div style="color: var(--text-secondary); font-size: 12px; padding: 12px; text-align: center;">
                            Deletion requests require admin approval. Your account will be marked as deleted but your ID will be retained.
                        </div>
                    </div>
                `;
            case 'about':
                return `
                    <div class="settings-section">
                        <div class="settings-section-title">About XVO</div>
                        <div class="settings-card">
                            <div style="padding: 24px; text-align: center; border-bottom: 1px solid var(--border-color);">
                                <div style="font-size: 32px; margin-bottom: 12px;">🚀</div>
                                <div style="font-weight: 700; font-size: 18px; margin-bottom: 4px;">XVO Social</div>
                                <div style="color: var(--text-secondary); font-size: 14px; margin-bottom: 12px;">Connect. Share. Grow.</div>
                                <div style="color: var(--text-muted); font-size: 12px;">Version 1.0.0 • December 2025</div>
                            </div>
                            <div style="padding: 24px;">
                                <div style="margin-bottom: 20px;">
                                    <div style="font-weight: 600; margin-bottom: 8px;">Features</div>
                                    <div style="color: var(--text-secondary); font-size: 13px; line-height: 1.6;">
                                        • Real-time posting and interactions<br>
                                        • Direct messaging<br>
                                        • Two-factor authentication<br>
                                        • Customizable profiles<br>
                                        • Polls and engagement<br>
                                        • Dark/Light mode
                                    </div>
                                </div>
                                <div style="margin-bottom: 20px;">
                                    <div style="font-weight: 600; margin-bottom: 8px;">Made by</div>
                                    <div style="color: var(--text-secondary); font-size: 13px;">XVO Development Team</div>
                                </div>
                                <div style="padding-top: 16px; border-top: 1px solid var(--border-color);">
                                    <div style="color: var(--text-muted); font-size: 12px; margin-bottom: 12px;">© 2025 XVO. All rights reserved.</div>
                                    <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                                        <span style="color: var(--xvo-blue); font-size: 12px; text-decoration: none; cursor: pointer;" data-action="tos">Terms of Use</span>
                                        <span style="color: var(--xvo-blue); font-size: 12px; text-decoration: none; cursor: pointer;" data-action="privacy">Privacy Policy</span>
                                        <span style="color: var(--xvo-blue); font-size: 12px; text-decoration: none; cursor: pointer;" data-action="support">Support</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            default:
                return `<div class="settings-section"><div class="settings-section-title">${section.charAt(0).toUpperCase() + section.slice(1)}</div><p style="color: var(--text-secondary);">Coming soon...</p></div>`;
        }
    }

    refreshSettingsPage() {
        const contentArea = document.getElementById('settingsContentArea');
        if (contentArea) {
            contentArea.innerHTML = `
                ${this.getSettingsSection('account')}
                ${this.getSettingsSection('security')}
                ${this.getSettingsSection('display')}
                ${this.getSettingsSection('privacy')}
                ${this.getSettingsSection('about')}
            `;
            this.attachSettingsListeners('all');
        }
    }

    attachSettingsListeners(section) {
        const contentArea = document.getElementById('settingsContentArea');
        if (contentArea) {
            contentArea.onclick = (e) => {
                const linkEl = e.target.closest('[data-action]');
                if (linkEl) {
                    const action = linkEl.dataset.action;
                    if (action === 'tos') this.navigate('tos');
                    if (action === 'privacy') this.navigate('privacy');
                    if (action === 'support') this.navigate('support');
                    return;
                }

                const row = e.target.closest('.settings-row');
                if (!row) return;
                
                const action = row.dataset.action;
                if (action === 'edit-profile') this.editProfile();
                if (action === 'change-password') this.showChangePasswordModal();
                if (action === 'account-type') this.showAccountTypeModal();
                if (action === 'edit-birthday') this.showBirthdayModal();
                if (action === 'identity-confirmation') this.showIdentityConfirmationModal();
                if (action === 'blocked-accounts') this.showBlockedAccountsModal();
                if (action === 'logout') {
                    if (confirm('Are you sure you want to log out?')) {
                        this.db.logout();
                        location.reload();
                    }
                }
            };
        }

        // Theme toggle
        const themeRow = document.getElementById('toggleThemeRow');
        if (themeRow) {
            themeRow.removeEventListener('click', this._themeToggleHandler);
            this._themeToggleHandler = () => {
                this.toggleTheme();
                const contentArea = document.getElementById('settingsContentArea');
                const currentHTML = contentArea.innerHTML;
                contentArea.innerHTML = currentHTML.replace(
                    this.getSettingsSection('display'),
                    this.getSettingsSection('display')
                );
                this.attachSettingsListeners('all');
            };
            themeRow.addEventListener('click', this._themeToggleHandler);
        }

        // Private account toggle
        const privateRow = document.getElementById('togglePrivateRow');
        if (privateRow) {
            privateRow.removeEventListener('click', this._privateToggleHandler);
            this._privateToggleHandler = () => {
                this.togglePrivateAccount();
            };
            privateRow.addEventListener('click', this._privateToggleHandler);
        }

        // Privacy toggles
        document.querySelectorAll('[data-toggle]').forEach(toggle => {
            toggle.removeEventListener('click', this._privacyToggleHandler);
            this._privacyToggleHandler = (e) => {
                e.stopPropagation();
                toggle.classList.toggle('active');
                if (toggle.dataset.toggle === 'activity-status') {
                    localStorage.setItem('xvo_activity_status', toggle.classList.contains('active'));
                }
            };
            toggle.addEventListener('click', this._privacyToggleHandler);
        });

        // Notification toggles
        document.querySelectorAll('[data-notif-category]').forEach(checkbox => {
            checkbox.removeEventListener('change', this._notifCheckboxHandler);
            this._notifCheckboxHandler = () => {
                const category = checkbox.dataset.notifCategory;
                localStorage.setItem(`xvo_notif_${category}`, checkbox.checked);
            };
            checkbox.addEventListener('change', this._notifCheckboxHandler);
        });
    }

    showViewModeModal() {
        const current = localStorage.getItem('xvo_view_mode') || 'comfortable';
        const options = ['compact', 'comfortable', 'immersive'];
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-container" style="max-width: 300px;">
                <div class="modal-header">
                    <span class="modal-title">View Mode</span>
                </div>
                <div class="modal-content" style="padding: 0;">
                    ${options.map(opt => `
                        <div style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); cursor: pointer; display: flex; justify-content: space-between; align-items: center;" data-option="${opt}">
                            <span style="font-weight: 500;">${opt.charAt(0).toUpperCase() + opt.slice(1)}</span>
                            ${current === opt ? '<i class="fas fa-check" style="color: var(--xvo-blue);"></i>' : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        modal.querySelectorAll('[data-option]').forEach(el => {
            el.addEventListener('click', () => {
                localStorage.setItem('xvo_view_mode', el.dataset.option);
                Toast.success(`View mode set to ${el.dataset.option}`);
                modal.remove();
                document.getElementById('settingsContentArea').innerHTML = this.getSettingsSection('display');
                this.attachSettingsListeners('display');
            });
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }

    showBirthdayModal() {
        const current = localStorage.getItem('xvo_birthday') || 'January 1, 2000';
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-container" style="max-width: 400px;">
                <div class="modal-header">
                    <span class="modal-title">Edit Birthday</span>
                </div>
                <div class="modal-content" style="padding: 20px;">
                    <input type="date" id="birthdayInput" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 6px; margin-bottom: 16px;">
                    <button class="post-button" style="width: 100%;" id="saveBirthdayBtn">Save Birthday</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        document.getElementById('saveBirthdayBtn').addEventListener('click', () => {
            const input = document.getElementById('birthdayInput').value;
            if (input) {
                const date = new Date(input);
                const formatted = date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
                localStorage.setItem('xvo_birthday', formatted);
                Toast.success('Birthday updated!');
                modal.remove();
                document.getElementById('settingsContentArea').innerHTML = this.getSettingsSection('personal');
                this.attachSettingsListeners('personal');
            }
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }

    showIdentityConfirmationModal() {
        const isVerified = localStorage.getItem('xvo_identity_verified') === 'true';
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-container" style="max-width: 400px;">
                <div class="modal-header">
                    <span class="modal-title">Identity Confirmation</span>
                </div>
                <div class="modal-content" style="padding: 20px;">
                    <p style="color: var(--text-secondary); margin-bottom: 20px;">Verify your identity to increase account security and unlock additional features.</p>
                    <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; margin-bottom: 16px;">
                        <input type="checkbox" id="identityCheckbox" ${isVerified ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                        <span>Verify identity with ID</span>
                    </label>
                    <button class="post-button" style="width: 100%;" id="saveIdentityBtn">Save</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        document.getElementById('saveIdentityBtn').addEventListener('click', () => {
            const checked = document.getElementById('identityCheckbox').checked;
            localStorage.setItem('xvo_identity_verified', checked ? 'true' : 'false');
            Toast.success(`Identity ${checked ? 'verified' : 'unverified'}!`);
            modal.remove();
            document.getElementById('settingsContentArea').innerHTML = this.getSettingsSection('personal');
            this.attachSettingsListeners('personal');
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
    }

    showBlockedAccountsModal() {
        const blockedUsers = JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]');
        const users = blockedUsers.map(userId => this.db.getAccount(userId)).filter(Boolean);
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'blockedModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('blockedModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Blocked (${blockedUsers.length})</span>
                </div>
                <div class="modal-body">
                    ${users.length === 0 ? '<p style="text-align: center; color: var(--text-secondary);">No blocked users</p>' : users.map(u => `
                        <div class="message-item">
                            <img src="${u.avatar}" class="message-avatar">
                            <div class="message-content">
                                <div class="message-name">${u.displayName || u.name}</div>
                                <div class="message-username">@${u.username}</div>
                            </div>
                            <button onclick="app.unblockUser(${u.id}); document.getElementById('blockedModal').remove(); app.refreshSettingsPage();" style="background: var(--danger); color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; margin-left: auto;">Unblock</button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    unblockUser(userId) {
        let blocked = JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]');
        blocked = blocked.filter(id => id !== userId);
        localStorage.setItem('xvo_blocked_users', JSON.stringify(blocked));
        Toast.success('User unblocked!');
    }

    showAccountTypeModal() {
        const current = localStorage.getItem('xvo_account_type') || 'private';
        const options = ['public', 'private'];
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'accountTypeModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('accountTypeModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Account Type</span>
                </div>
                <div class="modal-body" style="padding: 0;">
                    ${options.map(opt => `
                        <div onclick="app.setAccountType('${opt}'); document.getElementById('accountTypeModal').remove(); app.refreshSettingsPage();" style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: ${current === opt ? 'var(--bg-tertiary)' : 'transparent'}; transition: background 0.2s;">
                            <span style="font-weight: 500;">${opt.charAt(0).toUpperCase() + opt.slice(1)}</span>
                            ${current === opt ? '<i class="fas fa-check" style="color: var(--xvo-blue);"></i>' : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    setAccountType(type) {
        localStorage.setItem('xvo_account_type', type);
        Toast.success(`Account type changed to ${type}`);
    }

    async show2FASetup() {
        const user = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/2fa/setup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: user.id })
            });
            const data = await res.json();
            
            const modal = document.createElement('div');
            modal.className = 'modal active';
            modal.innerHTML = `
                <div class="modal-container" style="max-width: 400px;">
                    <div class="modal-header">
                        <button class="modal-close"><i class="fas fa-times"></i></button>
                        <span class="modal-title">Two-Factor Authentication</span>
                    </div>
                    <div class="modal-content" style="padding: 24px; text-align: center;">
                        <p style="margin-bottom: 20px;">Scan this QR code with your Google Authenticator app</p>
                        <img src="${data.qrCode}" style="width: 200px; height: 200px; margin-bottom: 20px;">
                        <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 20px;">Or enter code manually: <strong>${data.secret}</strong></p>
                        <input type="text" id="twoFactorCode" class="form-input" placeholder="Enter 6-digit code" maxlength="6" style="text-align: center; font-size: 24px; letter-spacing: 8px;">
                        <button class="submit-btn" id="verify2FABtn" style="margin-top: 20px;">Verify and Enable</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            modal.querySelector('.modal-close').onclick = () => modal.remove();
            
            document.getElementById('verify2FABtn').onclick = async () => {
                const token = document.getElementById('twoFactorCode').value;
                const verifyRes = await fetch(`${this.db.apiUrl}/api/2fa/verify`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId: user.id, token })
                });
                
                if (verifyRes.ok) {
                    Toast.success('2FA enabled successfully!');
                    user.twoFactorEnabled = true;
                    this.db.updateAccount(user);
                    modal.remove();
                    this.refreshSettingsPage();
                } else {
                    Toast.error('Invalid code. Please try again.');
                }
            };
        } catch (e) {
            Toast.error('Failed to initialize 2FA setup');
        }
    }

    renderBookmarks(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Bookmarks</span>
            </div>
        `;

        const bookmarks = this.db.getBookmarks();
        if (bookmarks.length === 0) {
            mainContent.innerHTML = `
                <div class="empty-state">
                    <i class="far fa-bookmark"></i>
                    <h3>Save posts for later</h3>
                    <p>Bookmark posts to easily find them again in the future.</p>
                </div>
            `;
        } else {
            mainContent.innerHTML = `<div id="bookmarksFeed"></div>`;
            this.renderFeed('bookmarksFeed', bookmarks);
        }
    }

    renderLists(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Lists</span>
            </div>
        `;

        mainContent.innerHTML = `
            <div class="empty-state">
                <i class="far fa-list-alt"></i>
                <h3>You haven't created any Lists</h3>
                <p>When you create a List, it'll show up here.</p>
            </div>
        `;
    }

    renderTopics(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Topics</span>
            </div>
        `;

        mainContent.innerHTML = `
            <div class="empty-state">
                <i class="far fa-comment-dots"></i>
                <h3>Topics you follow</h3>
                <p>You aren't following any Topics yet. When you do, they'll be listed here.</p>
            </div>
        `;
    }

    renderMoments(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Moments</span>
            </div>
        `;

        mainContent.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-bolt"></i>
                <h3>Create your first Moment</h3>
                <p>Moments are curated stories about what's happening around the world.</p>
            </div>
        `;
    }

    renderMentions(header, mainContent) {
        const user = this.db.getCurrentUser();
        header.innerHTML = `
            <div class="header-left">
                <img src="${user.avatar}" alt="Profile" class="header-avatar" id="headerAvatar">
                <span class="header-title">Mentions</span>
            </div>
        `;
        document.getElementById('headerAvatar').addEventListener('click', () => this.toggleSidebar());

        const allPosts = this.db.getPosts();
        const allComments = allPosts.flatMap(p => (p.comments || []).map(c => ({ ...c, postId: p.id })));
        
        const mentionedPosts = allPosts.filter(p => this.getMentionedUsers(p.text).some(u => u.id === user.id));
        const mentionedComments = allComments.filter(c => this.getMentionedUsers(c.text).some(u => u.id === user.id));
        
        const mentions = [
            ...mentionedPosts.map(p => ({ type: 'post', data: p, timestamp: p.timestamp })),
            ...mentionedComments.map(c => ({ type: 'comment', data: c, timestamp: c.timestamp }))
        ].sort((a, b) => b.timestamp - a.timestamp);

        if (mentions.length === 0) {
            mainContent.innerHTML = `
                <div class="empty-state">
                    <i class="far fa-at"></i>
                    <h3>No mentions yet</h3>
                    <p>When people mention you, you'll see it here.</p>
                </div>
            `;
            return;
        }

        mainContent.innerHTML = `
            <div class="feed">
                ${mentions.map(mention => {
                    if (mention.type === 'post') {
                        const post = mention.data;
                        const author = this.db.getAccount(post.userId);
                        if (!author) return '';
                        return `
                            <div class="post mention-item" data-post-id="${post.id}" style="border-left: 3px solid var(--xvo-blue); padding-left: 12px;">
                                <img src="${author.avatar}" class="post-avatar" data-action="view-profile" data-user-id="${author.id}">
                                <div class="post-content">
                                    <div class="post-header">
                                        <span class="post-name" data-action="view-profile" data-user-id="${author.id}">${author.displayName || author.name}</span>
                                        <span class="post-username">@${author.username}</span>
                                        <span class="post-dot">·</span>
                                        <span class="post-time">${this.formatTime(post.timestamp)}</span>
                                    </div>
                                    <div class="post-text">${this.formatTextWithMentions(this.linkify(post.text))}</div>
                                </div>
                            </div>
                        `;
                    } else {
                        const comment = mention.data;
                        const post = this.db.getPost(comment.postId);
                        const author = this.db.getAccount(comment.userId);
                        if (!author || !post) return '';
                        return `
                            <div class="post mention-item" style="border-left: 3px solid var(--xvo-blue); padding-left: 12px;">
                                <img src="${author.avatar}" class="post-avatar" data-action="view-profile" data-user-id="${author.id}">
                                <div class="post-content">
                                    <div class="post-header">
                                        <span class="post-name" data-action="view-profile" data-user-id="${author.id}">${author.displayName || author.name}</span>
                                        <span class="post-username">@${author.username}</span>
                                        <span class="post-dot">·</span>
                                        <span class="post-time">${this.formatTime(comment.timestamp)}</span>
                                    </div>
                                    <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 8px;">Replied to ${this.db.getAccount(post.userId)?.username || 'post'}</div>
                                    <div class="post-text">${this.formatTextWithMentions(comment.text)}</div>
                                </div>
                            </div>
                        `;
                    }
                }).join('')}
            </div>
        `;
    }

    renderHelp(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Help Center</span>
            </div>
        `;

        mainContent.innerHTML = `
            <div class="tos-content">
                <h2>XVO Help Center</h2>
                <h3>Getting Started</h3>
                <p>Welcome to XVO! Here's how to get started:</p>
                <ul>
                    <li>Create an account or sign in</li>
                    <li>Complete your profile with a photo and bio</li>
                    <li>Follow people you're interested in</li>
                    <li>Start posting and engaging with content</li>
                </ul>
                <h3>Features</h3>
                <ul>
                    <li><strong>Posts:</strong> Share your thoughts with up to 280 characters</li>
                    <li><strong>Likes:</strong> Show appreciation for posts you enjoy</li>
                    <li><strong>Reposts:</strong> Share posts with your followers</li>
                    <li><strong>Comments:</strong> Join the conversation on any post</li>
                    <li><strong>Messages:</strong> Send private messages to other users</li>
                    <li><strong>Bookmarks:</strong> Save posts for later</li>
                </ul>
                <h3>Contact Support</h3>
                <p>If you need additional help, please contact our support team.</p>
            </div>
        `;
    }

    renderTOS(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Terms of Service</span>
            </div>
        `;

        mainContent.innerHTML = `
            <div class="tos-content">
                <h2>XVO Terms of Service</h2>
                <p>Last updated: ${new Date().toLocaleDateString()}</p>
                
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using XVO, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by these terms, please do not use this service.</p>
                
                <h3>2. Description of Service</h3>
                <p>XVO is a social media platform that allows users to post short messages, follow other users, and engage with content through likes, reposts, and comments.</p>
                
                <h3>3. User Conduct</h3>
                <p>You agree to use XVO only for lawful purposes. You are prohibited from:</p>
                <ul>
                    <li>Posting content that is illegal, harmful, threatening, abusive, harassing, defamatory, or otherwise objectionable</li>
                    <li>Impersonating any person or entity</li>
                    <li>Uploading content that infringes any patent, trademark, trade secret, copyright, or other proprietary rights</li>
                    <li>Interfering with or disrupting the service or servers connected to the service</li>
                    <li>Using automated means to access the service without permission</li>
                </ul>
                
                <h3>4. Content Ownership</h3>
                <p>You retain ownership of any content you submit, post, or display on XVO. By posting content, you grant XVO a non-exclusive, royalty-free license to use, copy, reproduce, process, and display your content.</p>
                
                <h3>5. Privacy</h3>
                <p>Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and share information about you.</p>
                
                <h3>6. Account Termination</h3>
                <p>XVO reserves the right to suspend or terminate your account at any time, without prior notice, for conduct that we believe violates these Terms of Service or is harmful to other users, us, or third parties.</p>
                
                <h3>7. Disclaimer of Warranties</h3>
                <p>XVO is provided "as is" without warranty of any kind, express or implied. We do not guarantee that the service will be uninterrupted, timely, secure, or error-free.</p>
                
                <h3>8. Limitation of Liability</h3>
                <p>In no event shall XVO be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use the service.</p>
                
                <h3>9. Changes to Terms</h3>
                <p>We reserve the right to modify these terms at any time. We will notify users of any changes by posting the new Terms of Service on this page.</p>
                
                <h3>10. Contact</h3>
                <p>If you have any questions about these Terms of Service, please contact the XVO team.</p>
            </div>
        `;
    }

    async renderAdmin(header, mainContent) {
        const currentUser = this.db.getCurrentUser();
        if (!currentUser.isAdmin) {
            this.switchView('home');
            return;
        }

        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Admin Panel</span>
            </div>
        `;

        const currentTab = this.adminCurrentTab || 'overview';
        
        mainContent.innerHTML = `
            <div class="admin-layout" style="display: flex; flex-direction: column; min-height: calc(100vh - 53px); background: var(--bg-secondary);">
                <div class="admin-sidebar-nav" style="display: flex; overflow-x: auto; padding: 12px; background: var(--bg-primary); border-bottom: 1px solid var(--border-color); gap: 8px; sticky; top: 0; z-index: 10;">
                    <button class="admin-nav-btn ${currentTab === 'overview' ? 'active' : ''}" data-tab="overview" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'overview' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'overview' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">Overview</button>
                    <button class="admin-nav-btn ${currentTab === 'users' ? 'active' : ''}" data-tab="users" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'users' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'users' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">Users</button>
                    <button class="admin-nav-btn ${currentTab === 'reports' ? 'active' : ''}" data-tab="reports" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'reports' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'reports' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">Reports</button>
                    <button class="admin-nav-btn ${currentTab === 'content' ? 'active' : ''}" data-tab="content" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'content' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'content' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">Content</button>
                    <button class="admin-nav-btn ${currentTab === 'lookup' ? 'active' : ''}" data-tab="lookup" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'lookup' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'lookup' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">User Lookup</button>
                    <button class="admin-nav-btn ${currentTab === 'deletions' ? 'active' : ''}" data-tab="deletions" style="padding: 8px 16px; border-radius: 20px; border: none; background: ${currentTab === 'deletions' ? 'var(--xvo-blue)' : 'var(--bg-tertiary)'}; color: ${currentTab === 'deletions' ? 'white' : 'var(--text-primary)'}; font-weight: 600; cursor: pointer; white-space: nowrap;">Deletions</button>
                </div>
                <div class="admin-main-area" id="adminMainArea" style="padding: 16px; flex: 1;">
                    ${await this.getAdminTabContent(currentTab)}
                </div>
            </div>
        `;

        // Add event listeners for navigation
        document.querySelectorAll('.admin-nav-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const tab = btn.dataset.tab;
                this.adminCurrentTab = tab;
                this.renderAdmin(header, mainContent);
            });
        });
    }

    async getAdminTabContent(tab) {
        const currentUser = this.db.getCurrentUser();
        const allUsers = this.db.getAccounts();
        const isAlz = currentUser.username.toLowerCase() === 'alz';

        if (tab === 'overview') {
            let maintenanceMode = false;
            try {
                const res = await fetch(`${this.db.apiUrl}/api/site-status`);
                const status = await res.json();
                maintenanceMode = status.maintenanceMode || false;
            } catch (e) {}

            return `
                <div class="admin-section">
                    <h2 style="margin-bottom: 16px; font-size: 20px;">System Status</h2>
                    <div class="admin-card" style="padding: 20px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <div style="font-weight: 700;">Maintenance Mode</div>
                            <div style="font-size: 14px; color: var(--text-secondary);">${maintenanceMode ? 'System is currently locked' : 'System is live and running'}</div>
                        </div>
                        <button class="admin-btn ${maintenanceMode ? 'success' : 'danger'}" data-action="toggle-maintenance" style="padding: 8px 16px; border-radius: 8px; border: none; cursor: pointer; background: ${maintenanceMode ? 'var(--success)' : 'var(--danger)'}; color: white;">
                            ${maintenanceMode ? 'Disable' : 'Enable'}
                        </button>
                    </div>
                </div>
                <div class="admin-section" style="margin-top: 24px;">
                    <h2 style="margin-bottom: 16px; font-size: 20px;">Quick Stats</h2>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="admin-card" style="padding: 16px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color); text-align: center;">
                            <div style="font-size: 24px; font-weight: 800;">${allUsers.length}</div>
                            <div style="font-size: 12px; color: var(--text-secondary);">Total Users</div>
                        </div>
                        <div class="admin-card" style="padding: 16px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color); text-align: center;">
                            <div style="font-size: 24px; font-weight: 800;">${this.db.getPosts().length}</div>
                            <div style="font-size: 12px; color: var(--text-secondary);">Total Posts</div>
                        </div>
                    </div>
                </div>
            `;
        }

        if (tab === 'users') {
            return `
                <div class="admin-section">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                        <h2 style="font-size: 20px;">User Management</h2>
                    </div>
                    <div class="search-bar" style="margin-bottom: 16px;">
                        <input type="text" id="userSearchInput" placeholder="Search by name or username..." style="width: 100%; padding: 12px 16px; border-radius: 12px; border: 1px solid var(--border-color); background: var(--bg-primary); color: var(--text-primary);">
                    </div>
                    <div id="usersListContainer" style="display: flex; flex-direction: column; gap: 12px;">
                        ${allUsers.filter(u => u.id !== currentUser.id).map(u => `
                            <div class="admin-card user-list-item" data-username="${u.username.toLowerCase()}" data-displayname="${(u.displayName || u.name || '').toLowerCase()}" style="padding: 16px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color);">
                                <div style="display: flex; gap: 12px; align-items: center; margin-bottom: 12px;">
                                    <img src="${u.avatar}" style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover;">
                                    <div style="flex: 1;">
                                        <div style="font-weight: 700;">${u.displayName || u.name} ${u.verifiedID ? '<i class="fas fa-check-circle" style="color: var(--xvo-blue); font-size: 14px;"></i>' : ''}</div>
                                        <div style="font-size: 14px; color: var(--text-secondary);">@${u.username} ${u.isSuspended ? '<span style="color: var(--danger);">(Suspended)</span>' : ''}</div>
                                    </div>
                                </div>
                                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                    <button class="admin-btn secondary" data-action="view-profile" data-user-id="${u.id}" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-tertiary); font-size: 12px; cursor: pointer;">Profile</button>
                                    ${!u.verifiedID ? `<button class="admin-btn primary" data-action="verify-user" data-user-id="${u.id}" style="padding: 6px 12px; border-radius: 6px; border: none; background: var(--xvo-blue); color: white; font-size: 12px; cursor: pointer;">Verify</button>` : ''}
                                    ${u.isSuspended ? 
                                        `<button class="admin-btn success" data-action="unsuspend-user" data-user-id="${u.id}" style="padding: 6px 12px; border-radius: 6px; border: none; background: var(--success); color: white; font-size: 12px; cursor: pointer;">Unsuspend</button>` :
                                        `<button class="admin-btn danger" data-action="suspend-user" data-user-id="${u.id}" style="padding: 6px 12px; border-radius: 6px; border: none; background: var(--danger); color: white; font-size: 12px; cursor: pointer;">Suspend</button>`
                                    }
                                    <button class="admin-btn secondary" data-action="reset-user-password" data-user-id="${u.id}" style="padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-tertiary); font-size: 12px; cursor: pointer;">Reset Pass</button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        if (tab === 'reports') {
            let reports = [];
            try {
                const rRes = await fetch(`${this.db.apiUrl}/api/admin/reports?adminId=${currentUser.id}`);
                if (rRes.ok) reports = await rRes.json();
            } catch (e) {}

            const pending = reports.filter(r => !r.resolved);

            return `
                <div class="admin-section">
                    <h2 style="margin-bottom: 16px; font-size: 20px;">User Reports (${pending.length})</h2>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        ${pending.length > 0 ? pending.map(report => `
                            <div class="admin-card" style="padding: 16px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color);">
                                <div style="color: var(--danger); font-weight: 700; margin-bottom: 8px;"><i class="fas fa-flag"></i> ${report.reason}</div>
                                <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 12px;">Type: ${report.reportedType} | ID: ${report.reportedId}</div>
                                <button class="admin-btn primary" data-action="resolve-report" data-report-id="${report.id}" style="width: 100%; padding: 10px; border-radius: 8px; border: none; background: var(--xvo-blue); color: white; font-weight: 600; cursor: pointer;">Take Action</button>
                            </div>
                        `).join('') : '<div style="padding: 40px; text-align: center; color: var(--text-secondary); background: var(--bg-primary); border-radius: 12px; border: 1px dashed var(--border-color);">No pending reports</div>'}
                    </div>
                </div>
            `;
        }

        if (tab === 'deletions') {
            const deletionRequests = allUsers.filter(u => u.deletionRequested && !u.isDeleted);
            return `
                <div class="admin-section">
                    <h2 style="margin-bottom: 16px; font-size: 20px;">Account Deletion Requests (${deletionRequests.length})</h2>
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        ${deletionRequests.length > 0 ? deletionRequests.map(u => `
                            <div class="admin-card" style="padding: 16px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color);">
                                <div style="display: flex; gap: 12px; margin-bottom: 12px; align-items: center;">
                                    <img src="${u.avatar}" style="width: 48px; height: 48px; border-radius: 50%; object-fit: cover;">
                                    <div style="flex: 1;">
                                        <div style="font-weight: 700;">${u.displayName || u.name}</div>
                                        <div style="font-size: 14px; color: var(--text-secondary);">@${u.username}</div>
                                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">ID: ${u.id} • Requested: ${new Date(u.deletionRequestTime || Date.now()).toLocaleDateString()}</div>
                                    </div>
                                </div>
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <button class="admin-btn success" data-action="approve-deletion" data-user-id="${u.id}" style="padding: 8px 16px; border-radius: 6px; border: none; background: var(--success); color: white; font-size: 12px; cursor: pointer;">Approve</button>
                                    <button class="admin-btn danger" data-action="deny-deletion" data-user-id="${u.id}" style="padding: 8px 16px; border-radius: 6px; border: none; background: var(--danger); color: white; font-size: 12px; cursor: pointer;">Deny</button>
                                </div>
                            </div>
                        `).join('') : '<div style="padding: 40px; text-align: center; color: var(--text-secondary); background: var(--bg-primary); border-radius: 12px; border: 1px dashed var(--border-color);">No pending deletion requests</div>'}
                    </div>
                </div>
            `;
        }

        if (tab === 'lookup') {
            // Get IP logs data
            let ipLogs = [];
            try {
                const fs = require('fs');
                ipLogs = JSON.parse(fs.readFileSync('ip_logs.json', 'utf-8'));
            } catch (e) {}
            
            let html = `<div class="admin-section"><h2 style="margin-bottom: 16px;">All Users (${allUsers.length} total)</h2><div style="display: flex; flex-direction: column; gap: 12px;">`;
            
            const displayLimit = Math.min(50, allUsers.length);
            for (let i = 0; i < displayLimit; i++) {
                const user = allUsers[i];
                const posts = this.db.getPosts().filter(p => p.userId === user.id).length;
                const folCount = user.followers?.length || 0;
                const folowCount = user.following?.length || 0;
                const status = user.isSuspended ? 'SUSPENDED' : 'ACTIVE';
                const statusColor = user.isSuspended ? '#ef4444' : '#10b981';
                
                // Get last IP log for this user
                const userLogs = ipLogs.filter(log => log.userId === user.id);
                const lastLog = userLogs[userLogs.length - 1] || {};
                const lastSeen = lastLog.timestamp ? new Date(lastLog.timestamp).toLocaleDateString() : 'N/A';
                
                // Extract device and OS from userAgent
                let deviceModel = 'Unknown';
                let software = 'Unknown';
                const ua = lastLog.userAgent || '';
                if (ua.includes('Android')) {
                  deviceModel = ua.match(/Android \d+/)?.[0] || 'Android Device';
                  software = 'Android';
                } else if (ua.includes('iPhone') || ua.includes('iPad')) {
                  deviceModel = ua.includes('iPad') ? 'iPad' : 'iPhone';
                  software = 'iOS';
                } else if (ua.includes('Windows')) {
                  deviceModel = 'Windows PC';
                  software = 'Windows';
                } else if (ua.includes('Linux')) {
                  deviceModel = 'Linux Device';
                  software = 'Linux';
                } else if (ua.includes('Mac')) {
                  deviceModel = 'Mac';
                  software = 'macOS';
                }
                
                html += `<div style="background: var(--bg-card); padding: 16px; border-radius: 12px; border: 1px solid var(--border-color);">
                    <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                        <img src="${user.avatar}" style="width: 44px; height: 44px; border-radius: 50%;">
                        <div style="flex: 1;">
                            <div style="font-weight: 800;">${user.displayName || user.name}</div>
                            <div style="color: var(--text-secondary); font-size: 13px;">@${user.username}</div>
                        </div>
                        <span style="color: ${statusColor}; font-weight: 700; font-size: 11px;">${status}</span>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 8px; font-size: 10px; margin-bottom: 12px;">
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">IP</div><div style="font-family: monospace; font-size: 9px;">${lastLog.ip || 'N/A'}</div>
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">DEVICE</div>${deviceModel}
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">SOFTWARE</div>${software}
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">LAST SEEN</div>${lastSeen}
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 8px; font-size: 10px;">
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">FOLLOWERS</div>${folCount}
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">FOLLOWING</div>${folowCount}
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">POSTS</div>${posts}
                        </div>
                        <div style="background: var(--bg-secondary); padding: 8px; border-radius: 6px;">
                            <div style="color: var(--text-muted); font-size: 9px; font-weight: 700;">USER ID</div>${user.id}
                        </div>
                    </div>
                </div>`;
            }
            
            html += `</div>`;
            if (allUsers.length > 50) {
                const remaining = allUsers.length - 50;
                html += `<div style="margin-top: 20px; text-align: center; color: var(--text-secondary);">+${remaining} more users available</div>`;
            }
            html += `</div>`;
            
            return html;
        }
        if (tab === 'content') {
            let announcements = { announcement: null, ias: null };
            try {
                const annRes = await fetch(`${this.db.apiUrl}/api/announcements`);
                announcements = await annRes.json();
            } catch (e) {}

            return `
                <div class="admin-section">
                    <h2 style="margin-bottom: 16px; font-size: 20px;">Site Content</h2>
                    <div class="admin-card" style="padding: 20px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color); margin-bottom: 16px;">
                        <div style="font-weight: 700; margin-bottom: 12px;">Standard Announcement</div>
                        <input type="text" id="announcementInput" class="form-input" placeholder="Enter message..." value="${announcements.announcement ? announcements.announcement.text : ''}" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); margin-bottom: 12px;">
                        <div style="display: flex; gap: 8px;">
                            <button class="admin-btn primary" data-action="set-announcement" style="flex: 1; padding: 10px; border-radius: 8px; border: none; background: var(--xvo-blue); color: white; cursor: pointer;">Update</button>
                            <button class="admin-btn danger" data-action="clear-announcement" style="padding: 10px; border-radius: 8px; border: none; background: var(--danger); color: white; cursor: pointer;"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                    <div class="admin-card" style="padding: 20px; background: var(--bg-primary); border-radius: 12px; border: 1px solid var(--border-color); border-left: 4px solid var(--danger);">
                        <div style="font-weight: 700; color: var(--danger); margin-bottom: 12px;">IAS (Important Announcement)</div>
                        <input type="text" id="iasInput" class="form-input" placeholder="Enter emergency message..." style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-color); margin-bottom: 12px;">
                        <div style="display: flex; gap: 8px;">
                            <button class="admin-btn danger" data-action="send-ias" style="flex: 1; padding: 10px; border-radius: 8px; border: none; background: var(--danger); color: white; cursor: pointer;">Broadcast</button>
                            <button class="admin-btn secondary" data-action="clear-ias" style="padding: 10px; border-radius: 8px; border: none; background: var(--bg-tertiary); color: var(--text-primary); cursor: pointer;">Clear</button>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    async verifyUser(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.verifiedID = true;
            user.verificationRequested = false;
            await this.db.updateAccount(user);
            Toast.success('User verified!');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    async suspendUser(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.isSuspended = true;
            await this.db.updateAccount(user);
            Toast.success('User suspended');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    async unsuspendUser(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.isSuspended = false;
            await this.db.updateAccount(user);
            Toast.success('User unsuspended');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    async makeAdmin(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.isAdmin = true;
            await this.db.updateAccount(user);
            Toast.success('User is now an admin');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    async removeAdmin(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.isAdmin = false;
            await this.db.updateAccount(user);
            Toast.success('Admin rights removed');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    async adjustTrustScore(userId, increase = true) {
        const user = this.db.getAccount(userId);
        if (!user) return;
        
        if (user.isAdmin || user.username.toLowerCase() === 'alz') {
            Toast.error('Cannot adjust trust score for admins/owners');
            return;
        }
        
        const currentScore = user.trustScore || 20;
        const change = increase ? 10 : -10;
        const newScore = Math.max(0, Math.min(100, currentScore + change));
        
        user.trustScore = newScore;
        await this.db.updateAccount(user);
        Toast.success(`Trust score adjusted to ${newScore}`);
        
        this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
    }

    async toggleMaintenance() {
        const currentUser = this.db.getCurrentUser();
        try {
            const statusRes = await fetch(`${this.db.apiUrl}/api/site-status`);
            const status = await statusRes.json();
            const newMode = !status.maintenanceMode;
            
            const res = await fetch(`${this.db.apiUrl}/api/admin/maintenance`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, enabled: newMode })
            });
            
            if (res.ok) {
                Toast.success(newMode ? 'Maintenance mode enabled' : 'Maintenance mode disabled');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                const error = await res.json();
                Toast.error(error.error || 'Failed to toggle maintenance mode');
            }
        } catch (error) {
            Toast.error('Failed to toggle maintenance mode');
        }
    }

    async setAnnouncement() {
        const text = document.getElementById('announcementInput')?.value?.trim();
        if (!text) {
            Toast.error('Please enter announcement text');
            return;
        }
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/announcement`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, text })
            });
            if (res.ok) {
                Toast.success('Announcement set!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to set announcement');
            }
        } catch (error) {
            Toast.error('Failed to set announcement');
        }
    }

    async clearAnnouncement() {
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/announcement`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, text: null })
            });
            if (res.ok) {
                Toast.success('Announcement cleared!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to clear announcement');
            }
        } catch (error) {
            Toast.error('Failed to clear announcement');
        }
    }

    async sendIAS() {
        const text = document.getElementById('iasInput')?.value?.trim();
        if (!text) {
            Toast.error('Please enter IAS message');
            return;
        }
        if (!confirm('This will send a message to EVERYONE on the platform. Continue?')) return;
        
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/ias`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, text })
            });
            if (res.ok) {
                const result = await res.json();
                Toast.success(`IAS sent to ${result.sentTo} users!`);
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to send IAS');
            }
        } catch (error) {
            Toast.error('Failed to send IAS');
        }
    }

    async clearIAS() {
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/clear-ias`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id })
            });
            if (res.ok) {
                Toast.success('IAS banner cleared!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to clear IAS');
            }
        } catch (error) {
            Toast.error('Failed to clear IAS');
        }
    }

    async deleteAccount(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;
        if (!confirm(`Are you sure you want to DELETE the account @${user.username}? This cannot be undone!`)) return;
        
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/delete-account`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, userId })
            });
            if (res.ok) {
                Toast.success('Account deleted!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                const error = await res.json();
                Toast.error(error.error || 'Failed to delete account');
            }
        } catch (error) {
            Toast.error('Failed to delete account');
        }
    }

    async resetUserAvatar(userId) {
        if (!confirm('Reset this user\'s avatar and banner to default?')) return;
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/reset-avatar`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, userId })
            });
            if (res.ok) {
                Toast.success('Avatar and banner reset!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to reset avatar');
            }
        } catch (error) {
            Toast.error('Failed to reset avatar');
        }
    }

    async clearUserPosts(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;
        if (!confirm(`Delete ALL posts by @${user.username}?`)) return;
        
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/clear-user-posts`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, userId })
            });
            if (res.ok) {
                Toast.success('All posts deleted!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to clear posts');
            }
        } catch (error) {
            Toast.error('Failed to clear posts');
        }
    }

    showIssueBadgeModal(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'badgeModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('badgeModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Issue Badge to @${user.username}</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Select Badge</label>
                        <select class="form-input" id="badgeSelect">
                            <option value="blue">Blue Checkmark</option>
                            <option value="gold">Gold Checkmark</option>
                            <option value="gray">Gray Checkmark</option>
                            <option value="rainbow">Rainbow Badge</option>
                        </select>
                    </div>
                    <button class="submit-btn" id="issueBadgeBtn">Issue Badge</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        document.getElementById('issueBadgeBtn').addEventListener('click', async () => {
            const badge = document.getElementById('badgeSelect').value;
            const currentUser = this.db.getCurrentUser();
            try {
                const res = await fetch(`${this.db.apiUrl}/api/admin/issue-badge`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ adminId: currentUser.id, userId, badge })
                });
                if (res.ok) {
                    Toast.success('Badge issued!');
                    modal.remove();
                    this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
                } else {
                    Toast.error('Failed to issue badge');
                }
            } catch (error) {
                Toast.error('Failed to issue badge');
            }
        });
    }

    async removeBadge(userId) {
        if (!confirm('Remove this user\'s badge?')) return;
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/remove-badge`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, userId })
            });
            if (res.ok) {
                Toast.success('Badge removed!');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to remove badge');
            }
        } catch (error) {
            Toast.error('Failed to remove badge');
        }
    }

    showAdminSendMessageModal(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;

        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');
        
        body.innerHTML = `
            <div style="padding: 16px;">
                <h3 style="margin-bottom: 16px;">Send message to @${targetUser.username}</h3>
                <textarea class="form-textarea" id="adminMessageInput" placeholder="Type your message..." style="min-height: 100px; width: 100%;"></textarea>
                <button class="post-button" style="margin-top: 12px; width: 100%;" id="sendAdminMessageBtn">Send Message</button>
            </div>
        `;
        
        modal.classList.add('active');
        
        document.getElementById('sendAdminMessageBtn').addEventListener('click', async () => {
            const text = document.getElementById('adminMessageInput').value.trim();
            if (!text) {
                Toast.error('Please enter a message');
                return;
            }
            
            const currentUser = this.db.getCurrentUser();
            try {
                const res = await fetch(`${this.db.apiUrl}/api/admin/send-message`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ adminId: currentUser.id, userId, text })
                });
                
                if (res.ok) {
                    Toast.success('Message sent!');
                    modal.classList.remove('active');
                } else {
                    const error = await res.json();
                    Toast.error(error.error || 'Failed to send message');
                }
            } catch (error) {
                Toast.error('Failed to send message');
            }
        });
    }

    async showIPLogsModal(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;
        
        const currentUser = this.db.getCurrentUser();
        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');
        
        body.innerHTML = `<div style="padding: 16px; text-align: center;">Loading IP logs...</div>`;
        modal.classList.add('active');
        
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/ip-logs/${userId}?adminId=${currentUser.id}`);
            if (!res.ok) {
                const error = await res.json();
                body.innerHTML = `<div style="padding: 16px; color: var(--danger);">${error.error || 'Failed to load IP logs'}</div>`;
                return;
            }
            
            const logs = await res.json();
            
            body.innerHTML = `
                <div style="padding: 16px;">
                    <h3 style="margin-bottom: 16px;">IP Logs for @${targetUser.username}</h3>
                    ${logs.length === 0 ? '<p>No IP logs found for this user.</p>' : `
                        <div style="max-height: 400px; overflow-y: auto;">
                            ${logs.map(log => `
                                <div class="ip-log-item">
                                    <div><strong>IP:</strong> ${log.ip}</div>
                                    <div><strong>Time:</strong> ${new Date(log.timestamp).toLocaleString()}</div>
                                    <div style="font-size: 12px; color: var(--text-secondary); word-break: break-all;">${log.userAgent || 'Unknown'}</div>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>
            `;
        } catch (error) {
            body.innerHTML = `<div style="padding: 16px; color: var(--danger);">Failed to load IP logs</div>`;
        }
    }

    async toggleRainbow(userId) {
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/toggle-rainbow`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ adminId: currentUser.id, userId })
            });
            
            if (res.ok) {
                const data = await res.json();
                Toast.success(data.hasRainbowName ? 'Rainbow username enabled!' : 'Rainbow username disabled');
                const accounts = this.db.getAccounts();
                const idx = accounts.findIndex(a => a.id === userId);
                if (idx !== -1) {
                    accounts[idx].hasRainbowName = data.hasRainbowName;
                    localStorage.setItem('accounts', JSON.stringify(accounts));
                }
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                const error = await res.json();
                Toast.error(error.error || 'Failed to toggle rainbow');
            }
        } catch (error) {
            Toast.error('Failed to toggle rainbow');
        }
    }

    showResetPasswordModal(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;

        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');
        
        body.innerHTML = `
            <div style="padding: 16px;">
                <h3 style="margin-bottom: 16px;">Reset password for @${targetUser.username}</h3>
                <input type="password" class="form-input" id="newPasswordInput" placeholder="New password" style="width: 100%; margin-bottom: 12px;">
                <button class="post-button" style="width: 100%;" id="resetPasswordBtn">Reset Password</button>
            </div>
        `;
        
        modal.classList.add('active');
        
        document.getElementById('resetPasswordBtn').addEventListener('click', async () => {
            const newPassword = document.getElementById('newPasswordInput').value.trim();
            if (!newPassword || newPassword.length < 4) {
                Toast.error('Password must be at least 4 characters');
                return;
            }
            
            const currentUser = this.db.getCurrentUser();
            try {
                const res = await fetch(`${this.db.apiUrl}/api/admin/reset-password`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ adminId: currentUser.id, userId, newPassword })
                });
                
                if (res.ok) {
                    Toast.success('Password reset successfully!');
                    modal.classList.remove('active');
                } else {
                    const error = await res.json();
                    Toast.error(error.error || 'Failed to reset password');
                }
            } catch (error) {
                Toast.error('Failed to reset password');
            }
        });
    }

    showResetUsernameModal(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;

        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');
        
        body.innerHTML = `
            <div style="padding: 16px;">
                <h3 style="margin-bottom: 16px;">Reset username for @${targetUser.username}</h3>
                <input type="text" class="form-input" id="newUsernameInput" placeholder="New username" value="${targetUser.username}" style="width: 100%; margin-bottom: 12px;">
                <button class="post-button" style="width: 100%;" id="resetUsernameBtn">Reset Username</button>
            </div>
        `;
        
        modal.classList.add('active');
        
        document.getElementById('resetUsernameBtn').addEventListener('click', async () => {
            const newUsername = document.getElementById('newUsernameInput').value.trim();
            if (!newUsername || newUsername.length < 3) {
                Toast.error('Username must be at least 3 characters');
                return;
            }
            
            const currentUser = this.db.getCurrentUser();
            try {
                const res = await fetch(`${this.db.apiUrl}/api/admin/reset-username`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ adminId: currentUser.id, userId, newUsername })
                });
                
                if (res.ok) {
                    Toast.success('Username reset successfully!');
                    const accounts = this.db.getAccounts();
                    const idx = accounts.findIndex(a => a.id === userId);
                    if (idx !== -1) {
                        accounts[idx].username = newUsername;
                        localStorage.setItem('accounts', JSON.stringify(accounts));
                    }
                    modal.classList.remove('active');
                    this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
                } else {
                    const error = await res.json();
                    Toast.error(error.error || 'Failed to reset username');
                }
            } catch (error) {
                Toast.error('Failed to reset username');
            }
        });
    }

    showChangePasswordModal() {
        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');
        
        body.innerHTML = `
            <div style="padding: 16px;">
                <h3 style="margin-bottom: 16px;">Change Password</h3>
                <input type="password" class="form-input" id="currentPasswordInput" placeholder="Current password" style="width: 100%; margin-bottom: 12px;">
                <input type="password" class="form-input" id="newPasswordInput" placeholder="New password" style="width: 100%; margin-bottom: 12px;">
                <input type="password" class="form-input" id="confirmPasswordInput" placeholder="Confirm new password" style="width: 100%; margin-bottom: 12px;">
                <button class="post-button" style="width: 100%;" id="changePasswordBtn">Change Password</button>
            </div>
        `;
        
        modal.classList.add('active');
        
        document.getElementById('changePasswordBtn').addEventListener('click', async () => {
            const currentPassword = document.getElementById('currentPasswordInput').value;
            const newPassword = document.getElementById('newPasswordInput').value;
            const confirmPassword = document.getElementById('confirmPasswordInput').value;
            
            if (!currentPassword || !newPassword || !confirmPassword) {
                Toast.error('Please fill all fields');
                return;
            }
            
            if (newPassword.length < 4) {
                Toast.error('New password must be at least 4 characters');
                return;
            }
            
            if (newPassword !== confirmPassword) {
                Toast.error('Passwords do not match');
                return;
            }
            
            const currentUser = this.db.getCurrentUser();
            try {
                const res = await fetch(`${this.db.apiUrl}/api/change-password`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId: currentUser.id, currentPassword, newPassword })
                });
                
                if (res.ok) {
                    Toast.success('Password changed successfully!');
                    modal.classList.remove('active');
                } else {
                    const error = await res.json();
                    Toast.error(error.error || 'Failed to change password');
                }
            } catch (error) {
                Toast.error('Failed to change password');
            }
        });
    }

    goBack() {
        this.stopMessagePolling();
        this.currentConversationUserId = null;
        window.history.back();
    }

    sharePost(postId) {
        const url = `${window.location.origin}/posts/${postId}`;
        navigator.clipboard.writeText(url).then(() => {
            Toast.success('Post link copied to clipboard!');
        }).catch(() => {
            prompt('Copy this link:', url);
        });
    }

    shareProfile(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;
        const url = `${window.location.origin}/users/@${user.username}`;
        navigator.clipboard.writeText(url).then(() => {
            Toast.success('Profile link copied to clipboard!');
        }).catch(() => {
            prompt('Copy this link:', url);
        });
    }

    showComposeModal() {
        const user = this.db.getCurrentUser();
        document.getElementById('composeModalAvatar').src = user.avatar;
        document.getElementById('composeModalTextarea').value = '';
        document.getElementById('composeModalMediaPreview').innerHTML = '';
        document.getElementById('composeModal').classList.add('active');
        this.pendingMedia = null;
        this.pendingMediaType = null;
    }

    hideComposeModal() {
        document.getElementById('composeModal').classList.remove('active');
    }


    showCommentsModal(postId) {
        const post = this.db.getPost(postId);
        if (!post) return;

        const user = this.db.getCurrentUser();
        const postAuthor = this.db.getAccount(post.userId);
        const modal = document.getElementById('commentsModal');
        const body = document.getElementById('commentsModalBody');

        // Generate poll HTML if exists
        let pollHTML = '';
        if (post.poll) {
            const totalVotes = post.poll.options.reduce((acc, opt) => acc + ((opt.votes && Array.isArray(opt.votes)) ? opt.votes.length : 0), 0);
            const hasVoted = post.poll.options.some(opt => opt.votes && Array.isArray(opt.votes) && opt.votes.includes(user.id));
            const isPollOwner = post.userId === user.id;
            
            pollHTML = `
                <div class="poll-display" data-post-id="${post.id}" style="margin: 12px 0;">
                    ${post.poll.options.map((opt, index) => {
                        const voteCount = (opt.votes && Array.isArray(opt.votes)) ? opt.votes.length : 0;
                        const percent = totalVotes === 0 ? 0 : Math.round((voteCount / totalVotes) * 100);
                        return `
                            <div class="poll-option" data-action="vote-poll" data-post-id="${post.id}" data-option-index="${index}" style="cursor: ${hasVoted ? 'default' : 'pointer'};">
                                <div class="poll-bar" style="width: ${percent}%"></div>
                                <div class="poll-option-text">
                                    <span>${opt.text}</span>
                                    <span>${percent}%</span>
                                </div>
                            </div>
                        `;
                    }).join('')}
                    <div class="poll-votes-count">${totalVotes} ${totalVotes === 1 ? 'vote' : 'votes'}</div>
                </div>
            `;
        }

        body.innerHTML = `
            <!-- Original Post Display -->
            <div style="padding: 12px 0; border-bottom: 1px solid var(--border-color);">
                <div style="padding: 0 12px;">
                    <div style="display: flex; gap: 12px;">
                        <img src="${postAuthor.avatar}" class="comment-avatar" style="width: 48px; height: 48px;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 4px; margin-bottom: 4px;">
                                <span style="font-weight: 700; color: var(--text-primary);">${postAuthor.displayName || postAuthor.name}${this.getBadgeHTML(postAuthor)}</span>
                                <span style="color: var(--text-secondary);">@${postAuthor.username}</span>
                            </div>
                            <div style="color: var(--text-primary); margin-bottom: 8px; word-break: break-word;">${this.formatTextWithMentions(this.linkify(post.text))}</div>
                            ${pollHTML}
                            ${post.image ? `<div style="margin-top: 8px; margin-bottom: 8px;"><img src="${post.image}" style="max-width: 100%; border-radius: 12px; max-height: 300px;"></div>` : ''}
                            ${post.video ? `<div style="margin-top: 8px; margin-bottom: 8px;"><video src="${post.video}" controls style="max-width: 100%; border-radius: 12px; max-height: 300px;"></video></div>` : ''}
                            <div style="font-size: 13px; color: var(--text-secondary); margin-top: 8px;">${this.formatTime(post.timestamp)}</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Reply Input -->
            <div style="padding: 12px 0; border-bottom: 1px solid var(--border-color);">
                <div style="display: flex; gap: 12px; padding: 0 12px; position: relative;">
                    <img src="${user.avatar}" class="comment-avatar" style="width: 48px; height: 48px;">
                    <div style="flex: 1; position: relative;">
                        <textarea class="form-textarea" placeholder="Post your reply" id="commentInput" style="min-height: 60px;"></textarea>
                        <div id="mentionSuggestions" style="display: none; position: absolute; background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 8px; top: 100%; left: 0; right: 0; max-height: 200px; overflow-y: auto; z-index: 1000;"></div>
                        <button class="post-button" style="margin-top: 8px;" data-action="add-comment" data-post-id="${postId}">Reply</button>
                    </div>
                </div>
            </div>

            <!-- Comments List -->
            <div id="commentsList">
                ${(post.comments || []).map(c => {
                    const author = this.db.getAccount(c.userId);
                    if (!author) return '';
                    const isOwn = c.userId === user.id;
                    const isLiked = (c.likes || []).includes(user.id);
                    const isRetweeted = (c.retweets || []).includes(user.id);
                    return `
                        <div class="comment-item">
                            <img src="${author.avatar}" class="comment-avatar">
                            <div class="comment-content">
                                <div class="comment-header">
                                    <span class="comment-name">${author.displayName || author.name}</span>
                                    <span class="comment-username">@${author.username}</span>
                                    <span class="comment-time">· ${this.formatTime(c.timestamp)}</span>
                                    <span style="margin-left: auto; display: flex; gap: 8px;">
                                        ${!isOwn ? `<span style="cursor: pointer; color: var(--danger);" data-action="report-comment" data-post-id="${postId}" data-comment-id="${c.id}" title="Report"><i class="fas fa-flag"></i></span>` : ''}
                                        ${isOwn ? `<span style="cursor: pointer; color: var(--text-secondary);" data-action="delete-comment" data-post-id="${postId}" data-comment-id="${c.id}" title="Delete"><i class="fas fa-trash"></i></span>` : ''}
                                    </span>
                                </div>
                                <div class="comment-text">${this.formatTextWithMentions(c.text)}</div>
                                <div style="display: flex; gap: 16px; margin-top: 8px; font-size: 12px; color: var(--text-secondary);">
                                    <span>Views: ${(c.views || []).length}</span>
                                    <span style="cursor: pointer; ${isLiked ? 'color: var(--danger)' : ''}" data-action="like-comment" data-post-id="${postId}" data-comment-id="${c.id}"><i class="fas fa-heart"></i> ${(c.likes || []).length}</span>
                                    <span style="cursor: pointer; ${isRetweeted ? 'color: var(--retweet-color)' : ''}" data-action="repost-comment" data-post-id="${postId}" data-comment-id="${c.id}"><i class="fas fa-retweet"></i> ${(c.retweets || []).length}</span>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;

        modal.classList.add('active');
        
        // Setup mention autocomplete
        setTimeout(() => {
            const commentInput = document.getElementById('commentInput');
            if (commentInput) {
                commentInput.addEventListener('input', (e) => this.handleMentionInput(e));
            }
        }, 0);
    }

    handleMentionInput(e) {
        const text = e.target.value;
        const lastAtIndex = text.lastIndexOf('@');
        
        if (lastAtIndex === -1 || (lastAtIndex > 0 && text[lastAtIndex - 1] !== ' ' && text[lastAtIndex - 1] !== '\n')) {
            document.getElementById('mentionSuggestions').style.display = 'none';
            return;
        }

        const query = text.substring(lastAtIndex + 1).trim().toLowerCase();
        const allUsers = this.db.getAccounts().filter(u => u.id !== this.db.getCurrentUser().id);
        
        let suggestions = [];
        if (query.length === 0) {
            const recentMentions = JSON.parse(localStorage.getItem('recentMentions') || '[]');
            suggestions = recentMentions.map(id => this.db.getAccount(id)).filter(u => u);
        } else {
            suggestions = allUsers.filter(u => 
                u.username.toLowerCase().startsWith(query) || 
                (u.displayName || u.name).toLowerCase().startsWith(query)
            );
        }

        const suggestionsDiv = document.getElementById('mentionSuggestions');
        if (suggestions.length === 0) {
            suggestionsDiv.style.display = 'none';
            return;
        }

        suggestionsDiv.innerHTML = suggestions.slice(0, 5).map(u => `
            <div style="padding: 8px 12px; cursor: pointer; display: flex; gap: 8px; align-items: center; border-bottom: 1px solid var(--border-color);" 
                 onclick="app.insertMention('${u.username}')">
                <img src="${u.avatar}" style="width: 32px; height: 32px; border-radius: 50%;">
                <div>
                    <div style="font-weight: 600;">${u.displayName || u.name}</div>
                    <div style="font-size: 12px; color: var(--text-secondary);">@${u.username}</div>
                </div>
            </div>
        `).join('');
        suggestionsDiv.style.display = 'block';
    }

    insertMention(username) {
        const commentInput = document.getElementById('commentInput');
        if (!commentInput) return;

        const text = commentInput.value;
        const lastAtIndex = text.lastIndexOf('@');
        const beforeMention = text.substring(0, lastAtIndex);
        commentInput.value = beforeMention + '@' + username + ' ';
        
        document.getElementById('mentionSuggestions').style.display = 'none';
        
        // Track recent mention
        const user = this.db.getAccounts().find(u => u.username === username);
        if (user) {
            let recentMentions = JSON.parse(localStorage.getItem('recentMentions') || '[]');
            recentMentions = recentMentions.filter(id => id !== user.id);
            recentMentions.unshift(user.id);
            localStorage.setItem('recentMentions', JSON.stringify(recentMentions.slice(0, 10)));
        }
        
        commentInput.focus();
    }

    hideCommentsModal() {
        document.getElementById('commentsModal').classList.remove('active');
    }

    async addComment(postId) {
        const input = document.getElementById('commentInput');
        const text = input.value.trim();
        if (!text) return;

        const user = this.db.getCurrentUser();
        try {
            await this.db.addComment(postId, user.id, text, this.replyingToCommentId);
            
            // Track mentions and notify mentioned users
            const mentionedUsers = this.getMentionedUsers(text);
            mentionedUsers.forEach(mentionedUser => {
                if (mentionedUser.id !== user.id) {
                    this.addNotification(mentionedUser.id, {
                        type: 'mention',
                        userId: user.id,
                        postId: postId,
                        text: `${user.displayName || user.name} mentioned you in a reply`
                    });
                }
            });
            
            Toast.success('Reply posted!');
            this.replyingToCommentId = null;
            this.showCommentsModal(postId);
            this.renderFeed('homeFeed');
        } catch (error) {
            Toast.error('Failed to post reply');
        }
    }

    async deleteComment(postId, commentId) {
        try {
            await this.db.deleteComment(postId, commentId);
            Toast.success('Reply deleted');
            this.showCommentsModal(postId);
            this.renderFeed('homeFeed');
        } catch (error) {
            Toast.error('Failed to delete reply');
        }
    }

    toggleCommentLike(postId, commentId) {
        const post = this.db.getPost(postId);
        if (!post) return;
        const comment = post.comments?.find(c => c.id === commentId);
        if (!comment) return;
        
        const user = this.db.getCurrentUser();
        if (!comment.likes) comment.likes = [];
        
        const index = comment.likes.indexOf(user.id);
        if (index === -1) {
            comment.likes.push(user.id);
        } else {
            comment.likes.splice(index, 1);
        }
        
        this.db.updatePost(post);
        this.showCommentsModal(postId);
    }

    toggleCommentRepost(postId, commentId) {
        const post = this.db.getPost(postId);
        if (!post) return;
        const comment = post.comments?.find(c => c.id === commentId);
        if (!comment) return;
        
        const user = this.db.getCurrentUser();
        if (!comment.retweets) comment.retweets = [];
        
        const index = comment.retweets.indexOf(user.id);
        if (index === -1) {
            comment.retweets.push(user.id);
        } else {
            comment.retweets.splice(index, 1);
        }
        
        this.db.updatePost(post);
        this.showCommentsModal(postId);
    }

    replyToComment(postId, commentId) {
        const post = this.db.getPost(postId);
        if (!post) return;
        const comment = post.comments?.find(c => c.id === commentId);
        if (!comment) return;

        const author = this.db.getAccount(comment.userId);
        if (!author) return;

        const user = this.db.getCurrentUser();
        const commentInput = document.getElementById('commentInput');
        if (commentInput) {
            commentInput.value = `@${author.username} `;
            commentInput.focus();
            this.replyingToCommentId = commentId;
        }
    }

    async handleMediaUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const result = await this.db.uploadImage(file);
            this.pendingMedia = result.url;
            this.pendingMediaType = file.type.startsWith('video') ? 'video' : 'image';

            const previewContainer = document.getElementById('composeModalMediaPreview') || document.getElementById('homeMediaPreview');
            if (previewContainer) {
                if (this.pendingMediaType === 'video') {
                    previewContainer.innerHTML = `
                        <video src="${result.url}" controls style="max-width: 100%; border-radius: 16px;"></video>
                        <button class="composer-media-remove" onclick="app.removeMedia()"><i class="fas fa-times"></i></button>
                    `;
                } else {
                    previewContainer.innerHTML = `
                        <img src="${result.url}" alt="Upload" style="max-width: 100%; border-radius: 16px;">
                        <button class="composer-media-remove" onclick="app.removeMedia()"><i class="fas fa-times"></i></button>
                    `;
                }
            }
        } catch (error) {
            Toast.error('Failed to upload media');
        }

        e.target.value = '';
    }

    removeMedia() {
        this.pendingMedia = null;
        this.pendingMediaType = null;
        const modalPreview = document.getElementById('composeModalMediaPreview');
        const homePreview = document.getElementById('homeMediaPreview');
        if (modalPreview) modalPreview.innerHTML = '';
        if (homePreview) homePreview.innerHTML = '';
    }

    async handleAvatarUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const result = await this.db.uploadImage(file);
            const user = this.db.getCurrentUser();
            user.avatar = result.url;
            await this.db.updateAccount(user);
            this.updateUserUI();
            this.viewProfile(user.id);
            Toast.success('Profile picture updated!');
        } catch (error) {
            Toast.error('Failed to upload image');
        }
        e.target.value = '';
    }

    async handleBannerUpload(e) {
        const file = e.target.files[0];
        if (!file) return;

        try {
            const result = await this.db.uploadImage(file);
            const user = this.db.getCurrentUser();
            user.banner = result.url;
            await this.db.updateAccount(user);
            this.viewProfile(user.id);
            Toast.success('Banner updated!');
        } catch (error) {
            Toast.error('Failed to upload image');
        }
        e.target.value = '';
    }

    createPostFromModal() {
        const textarea = document.getElementById('composeModalTextarea');
        const text = textarea.value.trim();
        const pollComposer = document.getElementById('pollComposer');
        const pollInputs = document.querySelectorAll('.poll-option-input');
        
        let poll = null;
        if (pollComposer && !pollComposer.classList.contains('hidden')) {
            const options = Array.from(pollInputs)
                .map(input => input.value.trim())
                .filter(val => val !== '');
            
            if (options.length < 2) {
                Toast.error('Poll needs at least 2 options');
                return;
            }
            
            poll = {
                options: options.map(opt => ({ text: opt, votes: [] }))
            };
        }

        if (!text && !this.pendingMedia && !poll) return;

        const user = this.db.getCurrentUser();
        const post = {
            userId: user.id,
            text,
            timestamp: Date.now(),
            likes: [],
            retweets: [],
            comments: [],
            poll: poll
        };

        if (this.pendingMedia) {
            if (this.pendingMediaType === 'video') {
                post.video = this.pendingMedia;
            } else {
                post.image = this.pendingMedia;
            }
        }

        this.db.addPost(post);
        textarea.value = '';
        this.pendingMedia = null;
        this.pendingMediaType = null;
        const preview = document.getElementById('composeModalMediaPreview');
        if (preview) preview.innerHTML = '';
        if (pollComposer) pollComposer.classList.add('hidden');
        pollInputs.forEach(input => input.value = '');

        this.hideComposeModal();
        Toast.success('Posted!');
        this.renderFeed('homeFeed');
    }

    createPostFromHome() {
        const textarea = document.getElementById('homeComposer');
        const text = textarea.value.trim();
        const pollComposer = document.getElementById('pollComposer');
        const pollInputs = document.querySelectorAll('.poll-option-input');
        
        let poll = null;
        if (pollComposer && !pollComposer.classList.contains('hidden')) {
            const options = Array.from(pollInputs)
                .map(input => input.value.trim())
                .filter(val => val !== '');
            
            if (options.length < 2) {
                Toast.error('Poll needs at least 2 options');
                return;
            }
            
            poll = {
                options: options.map(opt => ({ text: opt, votes: [] }))
            };
        }

        if (!text && !this.pendingMedia && !poll) return;

        const user = this.db.getCurrentUser();
        const post = {
            userId: user.id,
            text,
            timestamp: Date.now(),
            likes: [],
            retweets: [],
            comments: [],
            poll: poll
        };

        if (this.pendingMedia) {
            if (this.pendingMediaType === 'video') {
                post.video = this.pendingMedia;
            } else {
                post.image = this.pendingMedia;
            }
        }

        this.db.addPost(post);
        textarea.value = '';
        this.pendingMedia = null;
        this.pendingMediaType = null;
        const preview = document.getElementById('homeMediaPreview');
        if (preview) preview.innerHTML = '';
        if (pollComposer) pollComposer.classList.add('hidden');
        pollInputs.forEach(input => input.value = '');
        
        this.renderFeed('homeFeed');
        Toast.success('Posted!');
    }

    toggleLike(postId) {
        const post = this.db.getPost(postId);
        if (!post) return;

        const user = this.db.getCurrentUser();
        if (!post.likes) post.likes = [];

        const index = post.likes.indexOf(user.id);
        const isLiking = index === -1;
        
        if (isLiking) {
            post.likes.push(user.id);
            Toast.success('Liked!');
            if (post.userId !== user.id) {
                this.db.addNotification({
                    userId: post.userId,
                    actorId: user.id,
                    type: 'like',
                    postId: post.id,
                    postText: post.text.substring(0, 50)
                });
            }
        } else {
            post.likes.splice(index, 1);
            Toast.success('Unliked');
        }

        this.db.updatePost(post);
        this.refreshCurrentView();
    }

    toggleRetweet(postId) {
        const post = this.db.getPost(postId);
        if (!post) return;

        const user = this.db.getCurrentUser();
        if (!post.retweets) post.retweets = [];

        const index = post.retweets.indexOf(user.id);
        if (index === -1) {
            post.retweets.push(user.id);
            if (post.userId !== user.id) {
                this.db.addNotification({
                    userId: post.userId,
                    actorId: user.id,
                    type: 'retweet',
                    postId: post.id,
                    postText: post.text.substring(0, 50)
                });
            }
            Toast.success('Reposted!');
        } else {
            post.retweets.splice(index, 1);
        }

        this.db.updatePost(post);
        this.refreshCurrentView();
    }

    toggleBookmark(postId) {
        if (this.db.isBookmarked(postId)) {
            this.db.removeBookmark(postId);
            Toast.success('Removed from bookmarks');
        } else {
            this.db.addBookmark(postId);
            Toast.success('Added to bookmarks');
        }
        this.refreshCurrentView();
    }

    async toggleFollow(userId) {
        const currentUser = this.db.getCurrentUser();
        const targetUser = this.db.getAccount(userId);
        if (!targetUser || userId === currentUser.id) {
            Toast.error('Cannot follow yourself');
            return;
        }

        if (!currentUser.following) currentUser.following = [];
        if (!targetUser.followers) targetUser.followers = [];

        const index = currentUser.following.indexOf(userId);
        if (index === -1) {
            currentUser.following.push(userId);
            targetUser.followers.push(currentUser.id);
            this.db.addNotification({
                userId: userId,
                actorId: currentUser.id,
                type: 'follow'
            });
            Toast.success(`Following @${targetUser.username}`);
        } else {
            currentUser.following.splice(index, 1);
            const followerIndex = targetUser.followers.indexOf(currentUser.id);
            if (followerIndex !== -1) targetUser.followers.splice(followerIndex, 1);
            Toast.success(`Unfollowed @${targetUser.username}`);
        }

        await this.db.updateAccount(currentUser);
        await this.db.updateAccount(targetUser);
        this.updateUserUI();
        this.viewProfile(userId);
    }

    blockUser(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;

        let blocked = JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]');
        if (!blocked.includes(userId)) {
            blocked.push(userId);
            localStorage.setItem('xvo_blocked_users', JSON.stringify(blocked));
            Toast.success(`Blocked @${targetUser.username}`);
            this.viewProfile(userId);
        }
    }

    unblockUser(userId) {
        const targetUser = this.db.getAccount(userId);
        if (!targetUser) return;

        let blocked = JSON.parse(localStorage.getItem('xvo_blocked_users') || '[]');
        blocked = blocked.filter(id => id !== userId);
        localStorage.setItem('xvo_blocked_users', JSON.stringify(blocked));
        Toast.success(`Unblocked @${targetUser.username}`);
        this.viewProfile(userId);
    }

    deletePost(postId) {
        if (confirm('Delete this post?')) {
            this.db.deletePost(postId);
            Toast.success('Post deleted');
            this.refreshCurrentView();
        }
    }

    requestAccountDeletion() {
        if (confirm('Are you sure? You will request account deletion. An admin must approve it.\n\nYour account ID will be retained, but your username will become "AccountDeleted".')) {
            const user = this.db.getCurrentUser();
            user.deletionRequested = true;
            user.deletionRequestTime = Date.now();
            this.db.updateAccount(user);
            Toast.success('Deletion request sent. Awaiting admin approval.');
            this.renderSettings(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    approveAccountDeletion(userId) {
        if (confirm('Permanently delete this account? This cannot be undone.')) {
            const user = this.db.getAccount(userId);
            if (user) {
                user.isDeleted = true;
                user.username = 'AccountDeleted';
                user.deletionRequested = false;
                user.displayName = 'Deleted Account';
                user.bio = '';
                user.avatar = 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png';
                this.db.updateAccount(user);
                Toast.success('Account deletion approved');
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            }
        }
    }

    denyAccountDeletion(userId) {
        const user = this.db.getAccount(userId);
        if (user) {
            user.deletionRequested = false;
            this.db.updateAccount(user);
            Toast.success('Deletion request denied');
            this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
        }
    }

    togglePrivateAccount() {
        const user = this.db.getCurrentUser();
        user.isPrivate = !user.isPrivate;
        this.db.updateAccount(user);
        Toast.success(`Account is now ${user.isPrivate ? 'private' : 'public'}`);
        this.refreshSettingsPage();
    }

    refreshCurrentView() {
        const currentUser = this.db.getCurrentUser();
        // Force refresh from server to get latest poll states
        const userId = currentUser ? currentUser.id : 0;
        fetch(`${this.db.apiUrl}/api/posts?userId=${userId}`)
            .then(res => res.json())
            .then(posts => {
                localStorage.setItem('xvo_posts', JSON.stringify(posts));
                if (this.currentView === 'home') {
                    this.renderFeed('homeFeed');
                } else if (this.viewingUserId) {
                    this.renderProfileFeed(this.viewingUserId);
                }
            })
            .catch(err => {
                console.error('Refresh error:', err);
                if (this.currentView === 'home') {
                    this.renderFeed('homeFeed');
                } else if (this.viewingUserId) {
                    this.renderProfileFeed(this.viewingUserId);
                }
            });
    }

    showEditProfileModal() {
        const user = this.db.getCurrentUser();
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'editProfileModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('editProfileModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Edit profile</span>
                    <button class="post-button" style="margin-left: auto;" onclick="app.saveProfile()">Save</button>
                </div>
                <div class="modal-body">
                    <div style="height: 100px; background: var(--bg-tertiary); border-radius: 8px; margin-bottom: 60px; position: relative; cursor: pointer;" data-action="upload-banner" ${user.banner ? `style="background-image: url(${user.banner}); background-size: cover;"` : ''}>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: var(--text-secondary);"><i class="fas fa-camera"></i></div>
                    </div>
                    <div style="position: relative; margin-top: -80px; margin-left: 16px; margin-bottom: 16px;">
                        <img src="${user.avatar}" style="width: 80px; height: 80px; border-radius: 50%; border: 4px solid var(--bg-primary); cursor: pointer;" data-action="upload-avatar">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Name</label>
                        <input type="text" class="form-input" id="editName" value="${user.displayName || user.name}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bio</label>
                        <textarea class="form-textarea" id="editBio">${user.bio || ''}</textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Website</label>
                        <input type="text" class="form-input" id="editWebsite" value="${user.website || ''}">
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    async saveProfile() {
        const user = this.db.getCurrentUser();
        user.displayName = document.getElementById('editName').value.trim() || user.name;
        user.bio = document.getElementById('editBio').value.trim();
        user.website = document.getElementById('editWebsite').value.trim();

        await this.db.updateAccount(user);
        document.getElementById('editProfileModal').remove();
        Toast.success('Profile updated!');
        this.updateUserUI();
        this.viewProfile(user.id);
    }

    showFollowingModal(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;

        const following = (user.following || []).map(id => this.db.getAccount(id)).filter(Boolean);

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'followingModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('followingModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Following</span>
                </div>
                <div class="modal-body">
                    ${following.length === 0 ? '<p style="text-align: center; color: var(--text-secondary);">Not following anyone yet</p>' : following.map(u => `
                        <div class="message-item" style="cursor: pointer;" onclick="document.getElementById('followingModal').remove(); app.viewProfile(${u.id})">
                            <img src="${u.avatar}" class="message-avatar">
                            <div class="message-content">
                                <div class="message-name">${u.displayName || u.name}${this.getBadgeHTML(u)}</div>
                                <div class="message-username">@${u.username}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    showFollowersModal(userId) {
        const user = this.db.getAccount(userId);
        if (!user) return;

        const followers = (user.followers || []).map(id => this.db.getAccount(id)).filter(Boolean);

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'followersModal';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('followersModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Followers</span>
                </div>
                <div class="modal-body">
                    ${followers.length === 0 ? '<p style="text-align: center; color: var(--text-secondary);">No followers yet</p>' : followers.map(u => `
                        <div class="message-item" style="cursor: pointer;" onclick="document.getElementById('followersModal').remove(); app.viewProfile(${u.id})">
                            <img src="${u.avatar}" class="message-avatar">
                            <div class="message-content">
                                <div class="message-name">${u.displayName || u.name}${this.getBadgeHTML(u)}</div>
                                <div class="message-username">@${u.username}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    showReportModal(id, type, extra = {}) {
        let title = 'Report User';
        let identifyText = '';
        let contentHTML = '';
        
        if (type === 'user') {
            const user = this.db.getAccount(id);
            if (!user) return;
            identifyText = `@${user.username}`;
        } else if (type === 'post') {
            const post = this.db.getPost(id);
            if (!post) return;
            const author = this.db.getAccount(post.userId);
            identifyText = `Post by ${author ? author.displayName || author.name : 'Unknown'}`;
            title = 'Report Post';
            contentHTML = `
                <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 12px; margin-bottom: 16px; background: var(--bg-secondary);">
                    <div style="font-weight: 600; margin-bottom: 8px;">Post Content:</div>
                    <div style="white-space: pre-wrap; word-wrap: break-word; margin-bottom: 8px;">${this.linkify(post.text)}</div>
                    ${post.image ? `<img src="${post.image}" style="max-width: 100%; border-radius: 8px; margin-bottom: 8px;">` : ''}
                    ${post.video ? `<video src="${post.video}" controls style="max-width: 100%; border-radius: 8px; margin-bottom: 8px;"></video>` : ''}
                </div>
            `;
        } else if (type === 'comment') {
            const post = this.db.getPost(extra.postId);
            if (!post) return;
            const comment = post.comments?.find(c => c.id === id);
            if (!comment) return;
            const commentAuthor = this.db.getAccount(comment.userId);
            identifyText = `Reply by @${commentAuthor?.username}`;
            title = 'Report Reply';
            contentHTML = `
                <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 12px; margin-bottom: 16px; background: var(--bg-secondary);">
                    <div style="font-weight: 600; margin-bottom: 8px;">Reply Content:</div>
                    <div style="white-space: pre-wrap; word-wrap: break-word;">${this.linkify(comment.text)}</div>
                </div>
            `;
        }

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'reportModal';
        modal.innerHTML = `
            <div class="modal" style="max-width: 500px; max-height: 80vh; overflow-y: auto;">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('reportModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">${title}</span>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 16px;">
                        <div style="font-weight: bold; margin-bottom: 12px;">${identifyText}</div>
                        ${contentHTML}
                        <label class="form-label">Reason</label>
                        <select id="reportReason" class="form-input" style="width: 100%; padding: 8px;">
                            <option value="">Select a reason</option>
                            <option value="Spam">Spam</option>
                            <option value="Abuse/Harassment">Abuse or Harassment</option>
                            <option value="Inappropriate Content">Inappropriate Content</option>
                            <option value="Scam">Scam</option>
                            <option value="Impersonation">Impersonation</option>
                            <option value="Other">Other</option>
                        </select>
                        <textarea id="reportDetails" class="form-textarea" placeholder="Additional details..." style="margin-top: 12px; width: 100%; min-height: 60px;"></textarea>
                        <button class="submit-btn" style="margin-top: 12px; width: 100%;" data-action="submit-report">Submit Report</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        
        const submitBtn = modal.querySelector('[data-action="submit-report"]');
        submitBtn.addEventListener('click', () => this.submitReport(id, type, extra));
    }

    async submitReport(id, type, extra = {}) {
        const reason = document.getElementById('reportReason').value;
        const details = document.getElementById('reportDetails').value;
        
        if (!reason) {
            Toast.error('Please select a reason');
            return;
        }
        
        const turnstileToken = null;

        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/report`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: currentUser.id,
                    reportedId: id,
                    reportedType: type,
                    reason: reason + (details ? ': ' + details : ''),
                    turnstileToken
                })
            });
            
            if (res.ok) {
                Toast.success('Report submitted successfully');
                document.getElementById('reportModal').remove();
            } else {
                Toast.error('Failed to submit report');
            }
        } catch (error) {
            Toast.error('Network error');
        }
    }

    showReportActionModal(reportId) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'reportActionModal';
        modal.innerHTML = `
            <div class="modal" style="max-width: 400px;">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('reportActionModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Report Actions</span>
                </div>
                <div class="modal-body">
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        <button class="admin-btn danger" style="width: 100%;" data-action="take-action" data-report-id="${reportId}" data-action-type="ban">
                            <i class="fas fa-ban"></i> Ban User
                        </button>
                        <button class="admin-btn secondary" style="width: 100%;" data-action="take-action" data-report-id="${reportId}" data-action-type="suspend-reporter">
                            <i class="fas fa-pause"></i> Suspend Reporter
                        </button>
                        <button class="admin-btn warning" style="width: 100%; background: #f59e0b; color: white;" data-action="take-action" data-report-id="${reportId}" data-action-type="false-report">
                            <i class="fas fa-times-circle"></i> False Report
                        </button>
                        <button class="admin-btn success" style="width: 100%;" data-action="take-action" data-report-id="${reportId}" data-action-type="resolve">
                            <i class="fas fa-check"></i> Resolve
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const actionBtns = modal.querySelectorAll('[data-action="take-action"]');
        actionBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const actionType = btn.dataset.actionType;
                document.getElementById('reportActionModal').remove();
                if (actionType === 'suspend-reporter') {
                    this.showSuspendModal(reportId);
                } else {
                    this.executeReportAction(reportId, actionType);
                }
            });
        });
    }

    showSuspendModal(reportId) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'suspendModal';
        modal.innerHTML = `
            <div class="modal" style="max-width: 400px;">
                <div class="modal-header">
                    <button class="modal-close" onclick="document.getElementById('suspendModal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                    <span class="modal-title">Suspend Reporter</span>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 16px;">
                        <label class="form-label">Duration</label>
                        <select id="suspendDuration" class="form-input" style="width: 100%; padding: 8px; margin-bottom: 12px;">
                            <option value="">Select duration</option>
                            <option value="1h">1 Hour</option>
                            <option value="1d">1 Day</option>
                            <option value="2d">2 Days</option>
                            <option value="3d">3 Days</option>
                            <option value="1w">1 Week</option>
                            <option value="1m">1 Month</option>
                            <option value="custom">Custom</option>
                        </select>
                        <div id="customDurationDiv" style="display: none; gap: 8px; margin-top: 12px;">
                            <input type="number" id="customValue" class="form-input" placeholder="Value" style="width: 60%; padding: 8px;">
                            <select id="customUnit" class="form-input" style="width: 40%; padding: 8px;">
                                <option value="hours">Hours</option>
                                <option value="days">Days</option>
                                <option value="weeks">Weeks</option>
                                <option value="months">Months</option>
                                <option value="years">Years</option>
                            </select>
                        </div>
                        <textarea id="suspendReason" class="form-textarea" placeholder="Reason for suspension..." style="margin-top: 12px; width: 100%; min-height: 60px;"></textarea>
                        <button class="submit-btn" style="margin-top: 12px; width: 100%;" data-action="execute-suspend" data-report-id="${reportId}">Suspend</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        const durationSelect = modal.querySelector('#suspendDuration');
        const customDiv = modal.querySelector('#customDurationDiv');
        durationSelect.addEventListener('change', () => {
            customDiv.style.display = durationSelect.value === 'custom' ? 'flex' : 'none';
        });

        const suspendBtn = modal.querySelector('[data-action="execute-suspend"]');
        suspendBtn.addEventListener('click', () => this.executeSuspend(reportId));
    }

    async executeSuspend(reportId) {
        const duration = document.getElementById('suspendDuration').value;
        const customValue = document.getElementById('customValue').value;
        const customUnit = document.getElementById('customUnit').value;
        const reason = document.getElementById('suspendReason').value;

        let durationString = duration;
        if (duration === 'custom') {
            if (!customValue) {
                Toast.error('Please enter a value for custom duration');
                return;
            }
            durationString = `${customValue}${customUnit[0]}`;
        }

        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/report-action`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    adminId: currentUser.id,
                    reportId,
                    actionType: 'suspend-reporter',
                    duration: durationString,
                    reason
                })
            });

            if (res.ok) {
                Toast.success('Reporter suspended successfully');
                document.getElementById('suspendModal').remove();
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to suspend reporter');
            }
        } catch (error) {
            Toast.error('Network error');
        }
    }

    async executeReportAction(reportId, actionType) {
        const currentUser = this.db.getCurrentUser();
        try {
            const res = await fetch(`${this.db.apiUrl}/api/admin/report-action`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    adminId: currentUser.id,
                    reportId,
                    actionType
                })
            });

            if (res.ok) {
                Toast.success(`Report ${actionType === 'resolve' ? 'resolved' : 'actioned'}`);
                this.renderAdmin(document.getElementById('header'), document.getElementById('mainContent'));
            } else {
                Toast.error('Failed to process action');
            }
        } catch (error) {
            Toast.error('Network error');
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;
        
        const turnstileToken = window.turnstile ? window.turnstile.getResponse('loginTurnstile') : null;
        if (!turnstileToken) {
            Toast.error('Please complete the CAPTCHA');
            return;
        }

        try {
            const response = await fetch(`${this.db.apiUrl}/api/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, turnstileToken })
            });

            const data = await response.json();
            if (response.ok) {
                if (data.requires2FA) {
                    this.show2FALoginModal(data.userId);
                } else {
                    this.db.saveCurrentUser(data);
                    this.startApp();
                    Toast.success('Login successful!');
                }
            } else if (response.status === 201 && data.suspended) {
                Toast.error(data.error);
                this.db.logout();
            } else {
                Toast.error(data.error || 'Login failed');
            }
        } catch (error) {
            Toast.error('Network error during login');
        }
    }

    show2FALoginModal(userId) {
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-container" style="max-width: 400px;">
                <div class="modal-header">
                    <button class="modal-close"><i class="fas fa-times"></i></button>
                    <span class="modal-title">Two-Factor Authentication</span>
                </div>
                <div class="modal-content" style="padding: 24px; text-align: center;">
                    <p style="margin-bottom: 20px;">Enter the 6-digit code from your Google Authenticator app</p>
                    <input type="text" id="login2FACode" class="form-input" placeholder="000000" maxlength="6" style="text-align: center; font-size: 24px; letter-spacing: 8px;">
                    <button class="submit-btn" id="verifyLogin2FABtn" style="margin-top: 20px;">Verify</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        modal.querySelector('.modal-close').onclick = () => modal.remove();

        document.getElementById('verifyLogin2FABtn').onclick = async () => {
            const token = document.getElementById('login2FACode').value;
            try {
                const response = await fetch(`${this.db.apiUrl}/api/2fa/login-verify`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId, token })
                });
                const data = await response.json();
                if (response.ok) {
                    this.db.saveCurrentUser(data);
                    modal.remove();
                    this.startApp();
                    Toast.success('Login successful!');
                } else {
                    Toast.error(data.error || 'Invalid 2FA code');
                }
            } catch (e) {
                Toast.error('Verification failed');
            }
        };
    }

    async handleSignup(e) {
        e.preventDefault();
        const name = document.getElementById('signupName').value.trim();
        const email = document.getElementById('signupEmail').value.trim();
        const dob = document.getElementById('signupDOB').value;
        const username = document.getElementById('signupUsername').value.trim();
        const password = document.getElementById('signupPassword').value;
        
        const turnstileToken = window.turnstile ? window.turnstile.getResponse('signupTurnstile') : null;
        if (!turnstileToken) {
            Toast.error('Please complete the CAPTCHA');
            return;
        }

        if (!name || !email || !dob || !username || !password) {
            Toast.error('Please fill all fields');
            return;
        }

        if (username.length < 3) {
            Toast.error('Username must be at least 3 characters');
            return;
        }

        if (password.length < 4) {
            Toast.error('Password must be at least 4 characters');
            return;
        }

        try {
            const account = await this.db.createAccount(name, email, dob, username, password, turnstileToken);
            this.db.saveCurrentUser(account);
            Toast.success('Account created! Welcome to XVO!');
            this.startApp();
        } catch (error) {
            Toast.error(error.message);
        }
    }

    logout() {
        this.db.logout();
        this.closeSidebar();
        location.reload();
    }

    getBadgeHTML(user) {
        let html = '';
        if (user.hasRainbowName) {
            return '';
        }
        if (user.verifiedID) {
            html += '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/1200px-Twitter_Verified_Badge.svg.png" class="verified-badge" alt="Verified">';
        }
        return html;
    }

    getNameHTML(user) {
        const name = user.displayName || user.name;
        if (user.hasRainbowName) {
            return `<span class="rainbow-text">${name}</span>`;
        }
        return name;
    }

    formatTime(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (seconds < 60) return 'now';
        if (minutes < 60) return `${minutes}m`;
        if (hours < 24) return `${hours}h`;
        if (days < 7) return `${days}d`;
        
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }

    linkify(text) {
        if (!text) return '';
        
        text = text.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
        text = text.replace(/#(\w+)/g, '<span class="hashtag" data-action="search-trend" data-term="#$1">#$1</span>');
        text = text.replace(/@(\w+)/g, '<span class="mention">@$1</span>');
        
        return text;
    }

    renderTOS(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Terms of Use</span>
            </div>
        `;
        mainContent.innerHTML = `
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="margin-bottom: 16px;">Terms of Use</h2>
                <div style="color: var(--text-secondary); line-height: 1.8;">
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">1. Acceptance of Terms</h3>
                    <p>By using XVO, you agree to these Terms of Use. If you do not agree, you may not use the service.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">2. User Conduct</h3>
                    <p>You agree not to engage in any conduct that:</p>
                    <ul style="margin-left: 20px;">
                        <li>Violates any law or regulation</li>
                        <li>Infringes on intellectual property rights</li>
                        <li>Harasses, abuses, or threatens other users</li>
                        <li>Spreads spam, malware, or harmful content</li>
                        <li>Impersonates another person or entity</li>
                    </ul>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">3. Content Ownership</h3>
                    <p>You retain ownership of content you post. By posting on XVO, you grant us a license to use, display, and distribute your content.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">4. Limitation of Liability</h3>
                    <p>XVO is provided "as is" without warranties. We are not liable for any damages arising from your use of the service.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">5. Account Termination</h3>
                    <p>We reserve the right to suspend or terminate accounts that violate these terms.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">6. Contact</h3>
                    <p>For legal inquiries regarding DMCA or other violations: <strong>Legal@xvo.social</strong></p>
                    
                    <p style="margin-top: 30px; font-size: 12px; color: var(--text-muted);">Last Updated: December 2025</p>
                </div>
            </div>
        `;
    }

    renderPrivacyPolicy(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Privacy Policy</span>
            </div>
        `;
        mainContent.innerHTML = `
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="margin-bottom: 16px;">Privacy Policy</h2>
                <div style="color: var(--text-secondary); line-height: 1.8;">
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">1. Information We Collect</h3>
                    <p>We collect information you provide directly, including name, email, username, and profile information. We also collect usage data automatically.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">2. How We Use Your Information</h3>
                    <p>We use your information to:</p>
                    <ul style="margin-left: 20px;">
                        <li>Provide and improve the XVO service</li>
                        <li>Send service updates and announcements</li>
                        <li>Respond to your inquiries</li>
                        <li>Detect and prevent fraud</li>
                        <li>Personalize your experience</li>
                    </ul>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">3. Data Security</h3>
                    <p>We implement security measures to protect your data. However, no system is completely secure.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">4. Third-Party Services</h3>
                    <p>We may share data with trusted third parties for service improvement. We do not sell your personal data.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">5. Your Rights</h3>
                    <p>You have the right to access, update, or delete your personal information. Contact us to exercise these rights.</p>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">6. Contact</h3>
                    <p>For privacy concerns: <strong>Legal@xvo.social</strong></p>
                    
                    <p style="margin-top: 30px; font-size: 12px; color: var(--text-muted);">Last Updated: December 2025</p>
                </div>
            </div>
        `;
    }

    renderSupport(header, mainContent) {
        header.innerHTML = `
            <div class="header-left">
                <button class="header-back" data-action="back"><i class="fas fa-arrow-left"></i></button>
                <span class="header-title">Support</span>
            </div>
        `;
        mainContent.innerHTML = `
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <h2 style="margin-bottom: 16px;">XVO Support</h2>
                <div style="color: var(--text-secondary); line-height: 1.8;">
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">How Can We Help?</h3>
                    <p>At XVO, we're here to support you. Whether you need help resetting your password, reporting an issue, or have other concerns, we're ready to assist.</p>
                    
                    <div style="background: var(--bg-secondary); padding: 20px; border-radius: 12px; margin-top: 20px; margin-bottom: 20px;">
                        <h3 style="margin-bottom: 12px;">Contact Us</h3>
                        <p style="margin-bottom: 16px;"><strong>Support Email:</strong></p>
                        <p style="font-size: 14px; word-break: break-all; background: var(--bg-primary); padding: 12px; border-radius: 8px; margin-bottom: 20px;">
                            <a href="mailto:xvo.support@xvo.social" style="color: var(--xvo-blue); text-decoration: none;">xvo.support@xvo.social</a>
                        </p>
                        <p style="font-size: 13px; color: var(--text-muted);">Send us an email for any support issues including password resets, account appeals, bans, or technical problems.</p>
                    </div>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">Common Issues</h3>
                    <div style="background: var(--bg-secondary); padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                        <p style="margin-bottom: 8px; font-weight: 600;">Forgot Password?</p>
                        <p>Email our support team at xvo.support@xvo.social with your username and we'll help you reset it.</p>
                    </div>
                    <div style="background: var(--bg-secondary); padding: 16px; border-radius: 8px; margin-bottom: 16px;">
                        <p style="margin-bottom: 8px; font-weight: 600;">Account Suspended?</p>
                        <p>If your account was suspended, you can appeal by contacting xvo.support@xvo.social. Please explain your situation.</p>
                    </div>
                    <div style="background: var(--bg-secondary); padding: 16px; border-radius: 8px;">
                        <p style="margin-bottom: 8px; font-weight: 600;">Report a Bug?</p>
                        <p>Found something broken? Email support@xvo.social with details and steps to reproduce the issue.</p>
                    </div>
                    
                    <h3 style="margin-top: 20px; margin-bottom: 12px;">Legal Issues</h3>
                    <p>For DMCA notices and legal matters, contact: <strong>Legal@xvo.social</strong></p>
                    
                    <p style="margin-top: 30px; font-size: 12px; color: var(--text-muted);">We typically respond to support inquiries within 24-48 hours.</p>
                </div>
            </div>
        `;
    }
}

// Initialize app
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new App();
});
