const express = require('express');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const multer = require('multer');
const bcrypt = require('bcrypt');
const fs = require('fs');
const CryptoJS = require('crypto-js');

const app = express();
const PORT = 5000;
const UPLOADS_DIR = path.join(__dirname, 'uploads');

const ENCRYPTION_KEY = process.env.MESSAGE_ENCRYPTION_KEY || 'xvo-secret-encryption-key-2024';
const IP_LOG_FILE = path.join(__dirname, 'ip_logs.json');

// Turnstile verification helper
async function verifyTurnstile(token) {
    if (!token) {
        console.warn('Turnstile: No token provided');
        return false;
    }
    
    if (!process.env.TURNSTILE_SECRET_KEY) {
        console.error('Turnstile: SECRET_KEY not configured');
        return false;
    }
    
    try {
        console.log('Turnstile: Verifying token with Cloudflare...');
        const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                secret: process.env.TURNSTILE_SECRET_KEY,
                response: token
            })
        });
        const data = await response.json();
        console.log('Turnstile response:', JSON.stringify(data));
        
        if (!data.success) {
            console.warn('Turnstile verification failed:', data);
        }
        
        return data.success;
    } catch (error) {
        console.error('Turnstile verification error:', error.message);
        return false;
    }
}

function logUserIP(userId, req, event = 'login') {
    try {
        const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
                   req.headers['x-real-ip'] || 
                   req.ip ||
                   req.connection?.remoteAddress || 
                   req.socket?.remoteAddress ||
                   'unknown';
        
        const port = req.connection?.remotePort || req.socket?.remotePort || 0;
        const userAgent = req.headers['user-agent'] || 'unknown';
        
        console.log(`Logging IP for user ${userId}: ${ip}`);
        
        let logs = [];
        if (fs.existsSync(IP_LOG_FILE)) {
            const fileContent = fs.readFileSync(IP_LOG_FILE, 'utf8');
            logs = fileContent ? JSON.parse(fileContent) : [];
        }
        
        logs.push({
            userId,
            event,
            ip_address: ip,
            source_port: port,
            timestamp_utc: new Date().toISOString(),
            unix_ms: Date.now(),
            userAgent
        });
        
        if (logs.length > 10000) {
            logs = logs.slice(-10000);
        }
        
        fs.writeFileSync(IP_LOG_FILE, JSON.stringify(logs, null, 2));
    } catch (error) {
        console.log('IP logging error:', error.message);
    }
}

function encryptMessage(text) {
    return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
}

function decryptMessage(text) {
    try {
        const bytes = CryptoJS.AES.decrypt(text, ENCRYPTION_KEY);
        const decrypted = bytes.toString(CryptoJS.enc.Utf8);
        return decrypted || text;
    } catch (error) {
        return text;
    }
}

async function extractLinkMetadata(url) {
    try {
        const response = await fetch(url, { 
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 5000 
        });
        if (!response.ok) return null;
        
        const html = await response.text();
        const titleMatch = html.match(/<meta\s+property=["']og:title["']\s+content=["']([^"']+)["']/i) || 
                          html.match(/<title[^>]*>([^<]+)<\/title>/i);
        const descMatch = html.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)["']/i) ||
                         html.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i);
        const imageMatch = html.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i);
        
        if (!titleMatch) return null;
        
        return {
            title: titleMatch[1]?.substring(0, 200) || null,
            description: descMatch?.[1]?.substring(0, 300) || null,
            image: imageMatch?.[1] || null,
            url: url
        };
    } catch (error) {
        console.log('Metadata extraction error:', error.message);
        return null;
    }
}

function extractUrls(text) {
    const urlRegex = /(https?:\/\/[^\s]+)/gi;
    const matches = text.match(urlRegex);
    return matches || [];
}

function calculateTrustScore(account) {
    return 100; // Trust score system removed
}

function shouldShowPost(post, viewingUserId, accounts, currentTime) {
    // Hide posts from suspended users
    const postAuthor = accounts.find(a => a.id === post.userId);
    if (postAuthor && postAuthor.isSuspended) {
        return false;
    }
    return true;
}

const postCooldowns = new Map();
const COOLDOWN_MS = 60000;

const typingIndicators = new Map();

// JSON file paths
const ACCOUNTS_FILE = path.join(__dirname, 'accounts.json');
const POSTS_FILE = path.join(__dirname, 'posts.json');
const MESSAGES_FILE = path.join(__dirname, 'messages.json');

// Helper functions for JSON storage
function readJSON(filepath) {
    try {
        const data = fs.readFileSync(filepath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

function writeJSON(filepath, data) {
    fs.writeFileSync(filepath, JSON.stringify(data, null, 2), 'utf8');
}

// Initialize JSON files if they don't exist
if (!fs.existsSync(ACCOUNTS_FILE)) {
    writeJSON(ACCOUNTS_FILE, []);
}
if (!fs.existsSync(POSTS_FILE)) {
    writeJSON(POSTS_FILE, []);
}
if (!fs.existsSync(MESSAGES_FILE)) {
    writeJSON(MESSAGES_FILE, []);
}

console.log('✓ Using JSON file storage');

// Create uploads directory if it doesn't exist
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR);
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, UPLOADS_DIR);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: {
        fileSize: 500 * 1024 * 1024
    },
    fileFilter: function (req, file, cb) {
        const allowedImageTypes = /jpeg|jpg|png|gif|webp/;
        const allowedVideoTypes = /mp4|webm|mov|avi|mkv/;
        const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
        const mimeType = file.mimetype;
        
        const isImage = allowedImageTypes.test(ext) || mimeType.startsWith('image/');
        const isVideo = allowedVideoTypes.test(ext) || mimeType.startsWith('video/');
        const isGif = ext === 'gif' || mimeType === 'image/gif';
        
        if (isImage || isVideo || isGif) {
            return cb(null, true);
        } else {
            cb(new Error('Only image, video, and GIF files are allowed'));
        }
    }
});

app.use(cors({
    origin: '*',
    credentials: true
}));
app.use(bodyParser.json());

app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});

// Serve static files from root directory
app.use(express.static(__dirname, {
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
}));

app.use('/uploads', express.static(UPLOADS_DIR));

// ========== ACCOUNTS API ==========

app.get('/api/accounts', (req, res) => {
    try {
        const accounts = readJSON(ACCOUNTS_FILE);
        const sanitizedAccounts = accounts.map(acc => ({
            ...acc,
            password: 'hashed'
        }));
        res.json(sanitizedAccounts);
    } catch (error) {
        console.error('Error fetching accounts:', error);
        res.status(500).json({ error: 'Failed to fetch accounts' });
    }
});

// ========== BLOCKING SYSTEM ==========

app.post('/api/block-user', (req, res) => {
    try {
        const { userId, blockUserId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        if (!user.blockedUsers) user.blockedUsers = [];
        if (!user.blockedUsers.includes(blockUserId)) {
            user.blockedUsers.push(blockUserId);
        }
        
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true, blockedUsers: user.blockedUsers });
    } catch (error) {
        res.status(500).json({ error: 'Failed to block user' });
    }
});

app.post('/api/unblock-user', (req, res) => {
    try {
        const { userId, unblockUserId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        if (!user.blockedUsers) user.blockedUsers = [];
        user.blockedUsers = user.blockedUsers.filter(id => id !== unblockUserId);
        
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true, blockedUsers: user.blockedUsers });
    } catch (error) {
        res.status(500).json({ error: 'Failed to unblock user' });
    }
});

app.get('/api/blocked-users/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === userId);
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        res.json({ blockedUsers: user.blockedUsers || [] });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch blocked users' });
    }
});

// ========== BLACKLIST ==========
const BLACKLIST_FILE = path.join(__dirname, 'blacklist.json');
if (!fs.existsSync(BLACKLIST_FILE)) {
    writeJSON(BLACKLIST_FILE, { ips: [], userIds: [] });
}

function isBlacklisted(req, userId = null) {
    const blacklist = readJSON(BLACKLIST_FILE);
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
               req.headers['x-real-ip'] || 
               req.ip ||
               req.connection?.remoteAddress || 
               req.socket?.remoteAddress ||
               'unknown';
    
    if (blacklist.ips.includes(ip)) return true;
    if (userId && blacklist.userIds.includes(userId)) return true;
    return false;
}

app.post('/api/admin/blacklist-ip', (req, res) => {
    try {
        const { adminId, ip, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        const blacklist = readJSON(BLACKLIST_FILE);
        if (ip && !blacklist.ips.includes(ip)) blacklist.ips.push(ip);
        if (userId && !blacklist.userIds.includes(userId)) blacklist.userIds.push(userId);
        
        writeJSON(BLACKLIST_FILE, blacklist);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to blacklist' });
    }
});

// Calculate total likes for an account
function calculateTotalLikes(account, posts) {
    return posts
        .filter(p => p.userId === account.id)
        .reduce((sum, p) => sum + (p.likes?.length || 0), 0);
}

app.post('/api/accounts', async (req, res) => {
    try {
        if (isBlacklisted(req)) {
            return res.status(403).json({ error: 'Your device or network is blacklisted' });
        }
        
        // Allow signup without CAPTCHA for testing (will require valid token in production)
        if (req.body.turnstileToken) {
            const turnstileValid = await verifyTurnstile(req.body.turnstileToken);
            if (!turnstileValid) {
                console.warn('CAPTCHA verification failed, but allowing signup for testing');
            }
        }
        
        const announcements = readJSON(path.join(__dirname, 'announcements.json'));
        if (announcements.maintenance) {
            return res.status(503).json({ error: 'Error 3: Maintenance Mode' });
        }

        const accounts = readJSON(ACCOUNTS_FILE);
        const newAccount = req.body;
        
        // Check if username exists
        if (accounts.find(acc => acc.username === newAccount.username)) {
            return res.status(400).json({ error: 'This Username already exists' });
        }
        
        const hashedPassword = await bcrypt.hash(newAccount.password, 10);
        
        const account = {
            id: accounts.length > 0 ? Math.max(...accounts.map(a => a.id)) + 1 : 1,
            name: newAccount.name,
            email: newAccount.email,
            dob: newAccount.dob,
            username: newAccount.username,
            password: hashedPassword,
            displayName: newAccount.name,
            bio: '',
            avatar: newAccount.avatar || 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png',
            followers: [],
            following: [],
            privacySettings: { allowFollowRequests: true, allowDirectMessages: true, showActivity: true, showLastOnline: true },
            verifiedID: false,
            badge: null,
            badgeIssuedBy: null,
            isAdmin: false,
            isSuspended: false,
            joinDate: Date.now(),
            lastOnline: Date.now(),
            trustScore: 100,
            totalLikes: 0
        };
        
        accounts.push(account);
        writeJSON(ACCOUNTS_FILE, accounts);
        
        const sanitizedAccount = { ...account, password: 'hashed' };
        res.json(sanitizedAccount);
    } catch (error) {
        console.error('Error creating account:', error);
        res.status(500).json({ error: 'Failed to create an account' });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { username, password, turnstileToken } = req.body;
        
        // Allow login without CAPTCHA for testing (will require valid token in production)
        if (turnstileToken) {
            const turnstileValid = await verifyTurnstile(turnstileToken);
            if (!turnstileValid) {
                console.warn('CAPTCHA verification failed, but allowing login for testing');
            }
        }
        
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const account = accounts.find(acc => acc.username === username);
        if (!account) {
            return res.status(401).json({ error: 'Invalid username or password' });
        }

        if (isBlacklisted(req, account.id)) {
            return res.status(403).json({ error: 'Your account, device, or network is blacklisted' });
        }
        
        const isPasswordValid = await bcrypt.compare(password, account.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid username or password' });
        }

        if (account.isSuspended) {
            return res.status(201).json({ error: 'Error 201: Account Suspended', suspended: true });
        }

        if (account.twoFactorEnabled) {
            return res.json({ requires2FA: true, userId: account.id });
        }
        
        logUserIP(account.id, req);
        
        const sanitizedAccount = { ...account, password: 'hashed' };
        res.json(sanitizedAccount);
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

app.put('/api/accounts/:id', async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const updates = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const accountIndex = accounts.findIndex(acc => acc.id === id);
        if (accountIndex === -1) {
            return res.status(404).json({ error: 'Account not found' });
        }
        
        // Hash password if it's being updated
        if (updates.password && updates.password !== 'hashed') {
            updates.password = await bcrypt.hash(updates.password, 10);
        } else if (updates.password === 'hashed') {
            delete updates.password;
        }
        
        // Update lastOnline timestamp only if not explicitly provided
        if (!updates.lastOnline) {
            updates.lastOnline = Date.now();
        }
        
        // Check if user is being suspended
        const wasSuspended = accounts[accountIndex].isSuspended;
        const isNowSuspended = updates.isSuspended === true;
        
        // Merge updates with existing account
        accounts[accountIndex] = { ...accounts[accountIndex], ...updates };
        
        // If user is being suspended, hide all their posts
        if (!wasSuspended && isNowSuspended) {
            console.log(`User ${id} suspended - hiding their posts`);
            // Posts stay in JSON but are filtered out by shouldShowPost function
        }
        
        // Write to JSON file
        writeJSON(ACCOUNTS_FILE, accounts);
        
        console.log(`Account ${id} updated successfully:`, {
            displayName: accounts[accountIndex].displayName,
            bio: accounts[accountIndex].bio?.substring(0, 50),
            followers: accounts[accountIndex].followers?.length,
            lastOnline: new Date(accounts[accountIndex].lastOnline).toISOString(),
            isSuspended: accounts[accountIndex].isSuspended
        });
        
        const sanitizedAccount = { ...accounts[accountIndex], password: 'hashed' };
        res.json(sanitizedAccount);
    } catch (error) {
        console.error('Error updating account:', error);
        res.status(500).json({ error: 'Failed to update account' });
    }
});

// ========== POSTS API ==========

app.get('/api/posts', (req, res) => {
    try {
        const posts = readJSON(POSTS_FILE);
        const accounts = readJSON(ACCOUNTS_FILE);
        const viewingUserId = parseInt(req.query.userId) || 0;
        const currentTime = Date.now();
        
        // Filter posts based on trust score and visibility
        const visiblePosts = posts.filter(post => 
            shouldShowPost(post, viewingUserId, accounts, currentTime)
        );
        
        visiblePosts.sort((a, b) => b.timestamp - a.timestamp);
        res.json(visiblePosts);
    } catch (error) {
        console.error('Error fetching posts:', error);
        res.status(500).json({ error: 'Failed to fetch posts' });
    }
});

app.post('/api/posts', async (req, res) => {
    try {
        const posts = readJSON(POSTS_FILE);
        const accounts = readJSON(ACCOUNTS_FILE);
        const newPost = req.body;
        const userId = newPost.userId;
        
        const user = accounts.find(a => a.id === userId);
        if (user && user.isSuspended) {
            return res.status(403).json({ error: 'Your account is suspended. You cannot post.' });
        }
        
        const lastPostTime = postCooldowns.get(userId);
        const now = Date.now();
        
        if (lastPostTime && (now - lastPostTime) < COOLDOWN_MS) {
            const remainingTime = Math.ceil((COOLDOWN_MS - (now - lastPostTime)) / 1000);
            return res.status(429).json({ 
                error: `Please wait ${remainingTime} seconds before posting again`,
                remainingTime: remainingTime
            });
        }
        
        // Extract link metadata
        let linkPreview = null;
        const urls = extractUrls(newPost.text);
        if (urls.length > 0) {
            linkPreview = await extractLinkMetadata(urls[0]);
        }
        
        // Calculate author's trust score
        const authorTrustScore = calculateTrustScore(user);
        
        // All posts are approved immediately
        let moderationStatus = 'approved';
        let visibilityDelay = 0;
        
        const post = {
            id: posts.length > 0 ? Math.max(...posts.map(p => parseInt(p.id))) + 1 : 1,
            userId: newPost.userId,
            text: newPost.text,
            timestamp: newPost.timestamp,
            likes: newPost.likes || [],
            retweets: newPost.retweets || [],
            comments: newPost.comments || [],
            image: newPost.image || null,
            video: newPost.video || null,
            poll: newPost.poll || null,
            linkPreview: linkPreview || null,
            views: [],
            trustScore: 100,
            moderationStatus: moderationStatus,
            visibilityDelay: visibilityDelay,
            scheduledShowTime: newPost.timestamp
        };
        
        posts.push(post);
        writeJSON(POSTS_FILE, posts);
        
        postCooldowns.set(userId, now);
        
        res.json(post);
    } catch (error) {
        console.error('Error creating post:', error);
        res.status(500).json({ error: 'Failed to create post' });
    }
});

app.put('/api/posts/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const updates = req.body;
        const posts = readJSON(POSTS_FILE);
        
        const postIndex = posts.findIndex(post => post.id === id);
        if (postIndex === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }
        
        posts[postIndex] = { ...posts[postIndex], ...updates };
        writeJSON(POSTS_FILE, posts);
        
        res.json(posts[postIndex]);
    } catch (error) {
        console.error('Error updating post:', error);
        res.status(500).json({ error: 'Failed to update post' });
    }
});

app.delete('/api/posts/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        let posts = readJSON(POSTS_FILE);
        
        posts = posts.filter(post => post.id !== id);
        writeJSON(POSTS_FILE, posts);
        
        res.json({ success: true });
    } catch (error) {
        console.error('Error deleting post:', error);
        res.status(500).json({ error: 'Failed to delete post' });
    }
});

// ========== COMMENTS API ==========

app.post('/api/posts/:id/comments', async (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const { userId, text, replyToCommentId, turnstileToken } = req.body;
        
        const turnstileValid = await verifyTurnstile(turnstileToken);
        if (!turnstileValid) {
            return res.status(400).json({ error: 'CAPTCHA verification failed' });
        }
        
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === userId);
        if (user && user.isSuspended) {
            return res.status(403).json({ error: 'Your account is suspended. You cannot comment.' });
        }
        
        const posts = readJSON(POSTS_FILE);
        
        const post = posts.find(p => p.id === postId);
        if (!post) {
            return res.status(404).json({ error: 'Post not found' });
        }
        
        if (!post.comments) {
            post.comments = [];
        }
        
        const comment = {
            id: post.comments.length > 0 ? Math.max(...post.comments.map(c => c.id)) + 1 : 1,
            userId: userId,
            text: text,
            timestamp: Date.now(),
            views: [],
            likes: [],
            retweets: [],
            replyTo: replyToCommentId || null,
            replies: []
        };
        
        post.comments.push(comment);
        writeJSON(POSTS_FILE, posts);
        
        res.json(comment);
    } catch (error) {
        console.error('Error adding comment:', error);
        res.status(500).json({ error: 'Failed to add comment' });
    }
});

app.delete('/api/posts/:postId/comments/:commentId', (req, res) => {
    try {
        const postId = parseInt(req.params.postId);
        const commentId = parseInt(req.params.commentId);
        const posts = readJSON(POSTS_FILE);
        
        const post = posts.find(p => p.id === postId);
        if (!post) {
            return res.status(404).json({ error: 'Post not found' });
        }
        
        post.comments = post.comments.filter(c => c.id !== commentId);
        writeJSON(POSTS_FILE, posts);
        
        res.json({ success: true });
    } catch (error) {
        console.error('Error deleting comment:', error);
        res.status(500).json({ error: 'Failed to delete comment' });
    }
});

app.get('/api/admin/user-lookup/:userId', (req, res) => {
    try {
        const adminId = parseInt(req.query.adminId);
        const targetId = parseInt(req.params.userId);
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        
        if (!admin || !admin.isAdmin) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        const user = accounts.find(u => u.id === targetId);
        if (!user) return res.status(404).json({ error: 'User not found' });
        
        let logs = [];
        if (fs.existsSync(IP_LOG_FILE)) {
            logs = JSON.parse(fs.readFileSync(IP_LOG_FILE, 'utf8'));
        }
        
        const userLogs = logs.filter(l => l.userId === targetId).sort((a, b) => b.unix_ms - a.unix_ms);
        const lastLog = userLogs[0] || {
            ip_address: 'Unknown',
            unix_ms: 0,
            userAgent: 'Unknown'
        };
        
        // Basic User-Agent parsing
        const ua = lastLog.userAgent;
        let model = 'Unknown Device';
        let software = 'Unknown Software';
        
        if (ua.includes('iPhone')) {
            model = 'iPhone';
            software = ua.match(/OS (\d+_\d+)/)?.[0].replace('_', '.') || 'iOS';
        } else if (ua.includes('Android')) {
            const match = ua.match(/\(([^;]+); ([^;]+); ([^\)]+)\)/);
            model = match?.[3] || 'Android Device';
            software = match?.[2] || 'Android';
        } else if (ua.includes('Windows')) {
            model = 'PC';
            software = 'Windows';
        } else if (ua.includes('Macintosh')) {
            model = 'Mac';
            software = 'macOS';
        }
        
        res.json({
            user: {
                id: user.id,
                username: user.username,
                displayName: user.displayName,
                avatar: user.avatar,
                lastOnline: user.lastOnline
            },
            lastLog,
            device: { model, software },
            location: {
                region: 'Global',
                localTime: new Date().toLocaleTimeString() // In a real app we'd use GeoIP here
            },
            isOnline: (Date.now() - user.lastOnline) < 300000
        });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/posts/:id/vote', (req, res) => {
    try {
        const postId = parseInt(req.params.id);
        const { userId, optionIndex } = req.body;
        const posts = readJSON(POSTS_FILE);
        
        console.log(`Voting request: PostID=${postId}, UserID=${userId}, OptionIndex=${optionIndex}`);
        
        // Find post by ID, handling both number and string types in JSON
        const post = posts.find(p => parseInt(p.id) === postId);
        if (!post || !post.poll) {
            console.log(`Poll not found for post ID: ${postId}. Available IDs: ${posts.map(p => p.id).join(', ')}`);
            return res.status(404).json({ error: 'Poll not found' });
        }
        
        // Initialize options and votes if needed (defensive)
        if (!post.poll.options) {
            post.poll.options = [];
        }

        post.poll.options.forEach(opt => {
            if (!opt.votes || !Array.isArray(opt.votes)) {
                opt.votes = [];
            }
        });
        
        // Check if user already voted
        const voterId = parseInt(userId);
        const hasVoted = post.poll.options.some(opt => opt.votes && opt.votes.some(v => parseInt(v) === voterId));
        if (hasVoted) {
            return res.status(400).json({ error: 'You already voted' });
        }
        
        // Add vote
        if (optionIndex >= 0 && optionIndex < post.poll.options.length) {
            post.poll.options[optionIndex].votes.push(voterId);
            writeJSON(POSTS_FILE, posts);
            console.log(`Vote saved for post ${postId}`);
            res.json(post);
        } else {
            return res.status(400).json({ error: 'Invalid option index' });
        }
    } catch (error) {
        console.error('Error voting:', error);
        res.status(500).json({ error: 'Failed to vote' });
    }
});


app.post('/api/2fa/setup', (req, res) => {
    try {
        const { userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === parseInt(userId));
        if (!user) return res.status(404).json({ error: 'User not found' });

        const secret = speakeasy.generateSecret({ name: `XVO (${user.username})` });
        user.tempTwoFactorSecret = secret.base32;
        writeJSON(ACCOUNTS_FILE, accounts);

        qrcode.toDataURL(secret.otpauth_url, (err, data_url) => {
            if (err) return res.status(500).json({ error: 'Failed to generate QR code' });
            res.json({ qrCode: data_url, secret: secret.base32 });
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/2fa/verify', (req, res) => {
    try {
        const { userId, token } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === parseInt(userId));
        if (!user) return res.status(404).json({ error: 'User not found' });

        const secret = user.twoFactorSecret || user.tempTwoFactorSecret;
        if (!secret) return res.status(400).json({ error: '2FA not set up' });

        const verified = speakeasy.totp.verify({
            secret: secret,
            encoding: 'base32',
            token: token
        });

        if (verified) {
            user.twoFactorEnabled = true;
            user.twoFactorSecret = secret;
            delete user.tempTwoFactorSecret;
            writeJSON(ACCOUNTS_FILE, accounts);
            res.json({ success: true });
        } else {
            res.status(400).json({ error: 'Invalid token' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/2fa/disable', (req, res) => {
    try {
        const { userId, token } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === parseInt(userId));
        if (!user || !user.twoFactorEnabled) return res.status(400).json({ error: '2FA not enabled' });

        const verified = speakeasy.totp.verify({
            secret: user.twoFactorSecret,
            encoding: 'base32',
            token: token
        });

        if (verified) {
            user.twoFactorEnabled = false;
            delete user.twoFactorSecret;
            writeJSON(ACCOUNTS_FILE, accounts);
            res.json({ success: true });
        } else {
            res.status(400).json({ error: 'Invalid token' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/2fa/login-verify', (req, res) => {
    try {
        const { userId, token } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const user = accounts.find(a => a.id === parseInt(userId));
        if (!user || !user.twoFactorEnabled) return res.status(400).json({ error: '2FA not enabled' });

        const verified = speakeasy.totp.verify({
            secret: user.twoFactorSecret,
            encoding: 'base32',
            token: token
        });

        if (verified) {
            logUserIP(user.id, req);
            res.json({
                id: user.id,
                username: user.username,
                name: user.name,
                displayName: user.displayName,
                avatar: user.avatar,
                bio: user.bio,
                banner: user.banner,
                isAdmin: user.isAdmin,
                verifiedID: user.verifiedID,
                followers: user.followers || [],
                following: user.following || [],
                badges: user.badges || [],
                joinDate: user.joinDate,
                twoFactorEnabled: user.twoFactorEnabled
            });
        } else {
            res.status(400).json({ error: 'Invalid 2FA token' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/upload', upload.single('image'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
    }
    const protocol = req.protocol;
    const host = req.get('host');
    const imageUrl = `${protocol}://${host}/uploads/${req.file.filename}`;
    
    res.json({ 
        success: true, 
        url: imageUrl,
        filename: req.file.filename,
        size: req.file.size
    });
});

// ========== MESSAGES API ==========

app.get('/api/messages/:userId', (req, res) => {
    try {
        const requestedUserId = parseInt(req.params.userId);
        const authUserId = parseInt(req.headers['x-user-id']);
        
        if (!authUserId || authUserId !== requestedUserId) {
            return res.status(403).json({ error: 'Unauthorized: You can only view your own messages' });
        }
        
        const messages = readJSON(MESSAGES_FILE);
        
        const userMessages = messages.filter(m => 
            m.senderId === requestedUserId || m.receiverId === requestedUserId
        );
        
        const conversationMap = new Map();
        userMessages.forEach(msg => {
            const otherUserId = msg.senderId === requestedUserId ? msg.receiverId : msg.senderId;
            if (!conversationMap.has(otherUserId) || msg.timestamp > conversationMap.get(otherUserId).timestamp) {
                conversationMap.set(otherUserId, { ...msg, text: decryptMessage(msg.text) });
            }
        });
        
        const conversations = Array.from(conversationMap.values())
            .sort((a, b) => b.timestamp - a.timestamp);
        
        res.json(conversations);
    } catch (error) {
        console.error('Error fetching conversations:', error);
        res.status(500).json({ error: 'Failed to fetch conversations' });
    }
});

app.get('/api/messages/:userId/:otherUserId', (req, res) => {
    try {
        const userId = parseInt(req.params.userId);
        const otherUserId = parseInt(req.params.otherUserId);
        const authUserId = parseInt(req.headers['x-user-id']);
        
        if (!authUserId || authUserId !== userId) {
            return res.status(403).json({ error: 'Unauthorized: You can only view your own conversations' });
        }
        
        const messages = readJSON(MESSAGES_FILE);
        
        const conversation = messages.filter(m =>
            (m.senderId === userId && m.receiverId === otherUserId) ||
            (m.senderId === otherUserId && m.receiverId === userId)
        ).map(m => ({ ...m, text: decryptMessage(m.text) }))
        .sort((a, b) => a.timestamp - b.timestamp);
        
        res.json(conversation);
    } catch (error) {
        console.error('Error fetching messages:', error);
        res.status(500).json({ error: 'Failed to fetch messages' });
    }
});

app.post('/api/messages', (req, res) => {
    try {
        const messages = readJSON(MESSAGES_FILE);
        const accounts = readJSON(ACCOUNTS_FILE);
        const { senderId, receiverId, text } = req.body;
        const authUserId = parseInt(req.headers['x-user-id']);
        
        if (!authUserId || authUserId !== senderId) {
            return res.status(403).json({ error: 'Unauthorized: You can only send messages as yourself' });
        }
        
        const sender = accounts.find(a => a.id === senderId);
        if (sender && sender.isSuspended) {
            return res.status(403).json({ error: 'Your account is suspended. You cannot send messages.' });
        }
        
        const encryptedText = encryptMessage(text);
        
        const message = {
            id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
            senderId,
            receiverId,
            text: encryptedText,
            timestamp: Date.now(),
            formattedTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            formattedDate: new Date().toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }),
            read: false
        };
        
        messages.push(message);
        writeJSON(MESSAGES_FILE, messages);
        
        typingIndicators.delete(`${senderId}-${receiverId}`);
        
        res.json({ ...message, text: text });
    } catch (error) {
        console.error('Error sending message:', error);
        res.status(500).json({ error: 'Failed to send message' });
    }
});

app.post('/api/typing', (req, res) => {
    try {
        const { senderId, receiverId, isTyping } = req.body;
        const key = `${senderId}-${receiverId}`;
        
        if (isTyping) {
            typingIndicators.set(key, Date.now());
        } else {
            typingIndicators.delete(key);
        }
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update typing status' });
    }
});

app.get('/api/typing/:userId/:otherUserId', (req, res) => {
    try {
        const userId = parseInt(req.params.userId);
        const otherUserId = parseInt(req.params.otherUserId);
        const key = `${otherUserId}-${userId}`;
        
        const lastTyping = typingIndicators.get(key);
        const isTyping = lastTyping && (Date.now() - lastTyping) < 5000;
        
        res.json({ isTyping: !!isTyping });
    } catch (error) {
        res.status(500).json({ error: 'Failed to get typing status' });
    }
});

app.post('/api/admin/reset-password', async (req, res) => {
    try {
        const { adminId, userId, newPassword } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized: Admin only' });
        }
        
        const userIndex = accounts.findIndex(a => a.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        accounts[userIndex].password = hashedPassword;
        writeJSON(ACCOUNTS_FILE, accounts);
        
        res.json({ success: true, message: 'Password reset successfully' });
    } catch (error) {
        console.error('Error resetting password:', error);
        res.status(500).json({ error: 'Failed to reset password' });
    }
});

app.post('/api/admin/reset-username', async (req, res) => {
    try {
        const { adminId, userId, newUsername } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized: Admin only' });
        }
        
        if (accounts.find(a => a.username.toLowerCase() === newUsername.toLowerCase() && a.id !== userId)) {
            return res.status(400).json({ error: 'Username already exists' });
        }
        
        const userIndex = accounts.findIndex(a => a.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        accounts[userIndex].username = newUsername;
        writeJSON(ACCOUNTS_FILE, accounts);
        
        res.json({ success: true, message: 'Username reset successfully' });
    } catch (error) {
        console.error('Error resetting username:', error);
        res.status(500).json({ error: 'Failed to reset username' });
    }
});

app.post('/api/admin/toggle-rainbow', async (req, res) => {
    try {
        const { adminId, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || admin.username.toLowerCase() !== 'alz') {
            return res.status(403).json({ error: 'Unauthorized: Only Alz can toggle rainbow usernames' });
        }
        
        const userIndex = accounts.findIndex(a => a.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }
        
        accounts[userIndex].hasRainbowName = !accounts[userIndex].hasRainbowName;
        writeJSON(ACCOUNTS_FILE, accounts);
        
        res.json({ success: true, hasRainbowName: accounts[userIndex].hasRainbowName });
    } catch (error) {
        console.error('Error toggling rainbow:', error);
        res.status(500).json({ error: 'Failed to toggle rainbow username' });
    }
});

app.get('/api/admin/ip-logs/:userId', (req, res) => {
    try {
        const adminId = parseInt(req.query.adminId);
        const userId = parseInt(req.params.userId);
        const accounts = readJSON(ACCOUNTS_FILE);
        
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || admin.username.toLowerCase() !== 'alz') {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        let logs = [];
        if (fs.existsSync(IP_LOG_FILE)) {
            logs = JSON.parse(fs.readFileSync(IP_LOG_FILE, 'utf8'));
        }
        
        const userLogs = logs.filter(l => l.userId === userId).slice(-20);
        res.json(userLogs);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch IP logs' });
    }
});

app.delete('/api/messages/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const authUserId = parseInt(req.headers['x-user-id']);
        
        if (!authUserId) {
            return res.status(403).json({ error: 'Unauthorized: Authentication required' });
        }
        
        const messages = readJSON(MESSAGES_FILE);
        const message = messages.find(m => m.id === id);
        
        if (!message) {
            return res.status(404).json({ error: 'Message not found' });
        }
        
        if (message.senderId !== authUserId && message.receiverId !== authUserId) {
            return res.status(403).json({ error: 'Unauthorized: You can only delete your own messages' });
        }
        
        const filteredMessages = messages.filter(m => m.id !== id);
        writeJSON(MESSAGES_FILE, filteredMessages);
        
        res.json({ success: true });
    } catch (error) {
        console.error('Error deleting message:', error);
        res.status(500).json({ error: 'Failed to delete message' });
    }
});

// Site settings storage
const SITE_SETTINGS_FILE = path.join(__dirname, 'site_settings.json');
function getSiteSettings() {
    try {
        if (fs.existsSync(SITE_SETTINGS_FILE)) {
            return JSON.parse(fs.readFileSync(SITE_SETTINGS_FILE, 'utf8'));
        }
    } catch (e) {}
    return { maintenanceMode: false };
}
function saveSiteSettings(settings) {
    fs.writeFileSync(SITE_SETTINGS_FILE, JSON.stringify(settings, null, 2));
}

// Maintenance mode check endpoint
app.get('/api/site-status', (req, res) => {
    const settings = getSiteSettings();
    res.json(settings);
});

// Toggle maintenance mode
app.post('/api/admin/maintenance', (req, res) => {
    try {
        const { adminId, enabled } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized: Admin only' });
        }
        const settings = getSiteSettings();
        settings.maintenanceMode = enabled;
        saveSiteSettings(settings);
        res.json({ success: true, maintenanceMode: enabled });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update maintenance mode' });
    }
});

// Admin send message to user
app.post('/api/admin/send-message', (req, res) => {
    try {
        const { adminId, userId, text } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized: Admin only' });
        }
        const messages = readJSON(MESSAGES_FILE);
        const encryptedText = encryptMessage(text);
        const message = {
            id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
            senderId: adminId,
            receiverId: userId,
            text: encryptedText,
            timestamp: Date.now(),
            read: false
        };
        messages.push(message);
        writeJSON(MESSAGES_FILE, messages);
        res.json({ success: true, message: { ...message, text } });
    } catch (error) {
        res.status(500).json({ error: 'Failed to send message' });
    }
});

// User change own password
app.post('/api/change-password', async (req, res) => {
    try {
        const { userId, currentPassword, newPassword } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const userIndex = accounts.findIndex(a => a.id === userId);
        if (userIndex === -1) {
            return res.status(404).json({ error: 'User not found' });
        }
        const isValid = await bcrypt.compare(currentPassword, accounts[userIndex].password);
        if (!isValid) {
            return res.status(401).json({ error: 'Current password is incorrect' });
        }
        accounts[userIndex].password = await bcrypt.hash(newPassword, 10);
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to change password' });
    }
});

// Get all IP logs for admin
app.get('/api/admin/all-ip-logs', (req, res) => {
    try {
        const adminId = parseInt(req.query.adminId);
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        let logs = [];
        if (fs.existsSync(IP_LOG_FILE)) {
            logs = JSON.parse(fs.readFileSync(IP_LOG_FILE, 'utf8'));
        }
        res.json(logs.slice(-100));
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch IP logs' });
    }
});

// ========== ANNOUNCEMENTS ==========
const ANNOUNCEMENTS_FILE = path.join(__dirname, 'announcements.json');
if (!fs.existsSync(ANNOUNCEMENTS_FILE)) {
    writeJSON(ANNOUNCEMENTS_FILE, { announcement: null, ias: null });
}

app.get('/api/announcements', (req, res) => {
    try {
        const data = readJSON(ANNOUNCEMENTS_FILE);
        res.json(data);
    } catch (error) {
        res.json({ announcement: null, ias: null });
    }
});

app.post('/api/admin/announcement', (req, res) => {
    try {
        const { adminId, text } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const data = readJSON(ANNOUNCEMENTS_FILE);
        data.announcement = text ? { text, timestamp: Date.now(), adminId } : null;
        writeJSON(ANNOUNCEMENTS_FILE, data);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to set announcement' });
    }
});

app.post('/api/admin/ias', (req, res) => {
    try {
        const { adminId, text } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        const messages = readJSON(MESSAGES_FILE);
        const allUsers = accounts.map(a => a.id);
        
        allUsers.forEach(userId => {
            const encryptedText = CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
            messages.push({
                id: messages.length > 0 ? Math.max(...messages.map(m => m.id)) + 1 : 1,
                senderId: adminId,
                receiverId: userId,
                text: encryptedText,
                timestamp: Date.now(),
                isIAS: true
            });
        });
        
        writeJSON(MESSAGES_FILE, messages);
        
        const data = readJSON(ANNOUNCEMENTS_FILE);
        data.ias = { text, timestamp: Date.now(), adminId };
        writeJSON(ANNOUNCEMENTS_FILE, data);
        
        res.json({ success: true, sentTo: allUsers.length });
    } catch (error) {
        res.status(500).json({ error: 'Failed to send IAS' });
    }
});

app.post('/api/admin/clear-ias', (req, res) => {
    try {
        const { adminId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const data = readJSON(ANNOUNCEMENTS_FILE);
        data.ias = null;
        writeJSON(ANNOUNCEMENTS_FILE, data);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to clear IAS' });
    }
});

// ========== MORE ADMIN COMMANDS ==========
app.post('/api/admin/delete-post', (req, res) => {
    try {
        const { adminId, postId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const posts = readJSON(POSTS_FILE);
        const index = posts.findIndex(p => p.id === postId);
        if (index === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }
        posts.splice(index, 1);
        writeJSON(POSTS_FILE, posts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete post' });
    }
});

app.post('/api/admin/delete-account', (req, res) => {
    try {
        const { adminId, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || admin.username.toLowerCase() !== 'alz') {
            return res.status(403).json({ error: 'Only super admin can delete accounts' });
        }
        const index = accounts.findIndex(a => a.id === userId);
        if (index === -1) {
            return res.status(404).json({ error: 'Account not found' });
        }
        accounts.splice(index, 1);
        writeJSON(ACCOUNTS_FILE, accounts);
        
        let posts = readJSON(POSTS_FILE);
        posts = posts.filter(p => p.userId !== userId);
        writeJSON(POSTS_FILE, posts);
        
        let messages = readJSON(MESSAGES_FILE);
        messages = messages.filter(m => m.senderId !== userId && m.receiverId !== userId);
        writeJSON(MESSAGES_FILE, messages);
        
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete account' });
    }
});

app.post('/api/admin/reset-avatar', async (req, res) => {
    try {
        const { adminId, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const user = accounts.find(a => a.id === userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        user.avatar = 'https://abs.twimg.com/sticky/default_profile_images/default_profile_400x400.png';
        user.banner = '';
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to reset avatar' });
    }
});

app.post('/api/admin/clear-user-posts', (req, res) => {
    try {
        const { adminId, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        let posts = readJSON(POSTS_FILE);
        posts = posts.filter(p => p.userId !== userId);
        writeJSON(POSTS_FILE, posts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to clear posts' });
    }
});

app.post('/api/admin/issue-badge', (req, res) => {
    try {
        const { adminId, userId, badge } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const user = accounts.find(a => a.id === userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        user.badge = badge;
        user.badgeIssuedBy = admin.username;
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to issue badge' });
    }
});

app.post('/api/admin/remove-badge', (req, res) => {
    try {
        const { adminId, userId } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        const user = accounts.find(a => a.id === userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        user.badge = null;
        user.badgeIssuedBy = null;
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to remove badge' });
    }
});

// Reports system
const REPORTS_FILE = path.join(__dirname, 'reports.json');
if (!fs.existsSync(REPORTS_FILE)) {
    writeJSON(REPORTS_FILE, []);
}

app.post('/api/report', async (req, res) => {
    try {
        const { userId, reportedId, reportedType, reason, turnstileToken } = req.body;
        
        const turnstileValid = await verifyTurnstile(turnstileToken);
        if (!turnstileValid) {
            return res.status(400).json({ error: 'CAPTCHA verification failed' });
        }
        
        const reports = readJSON(REPORTS_FILE);
        
        const report = {
            id: reports.length > 0 ? Math.max(...reports.map(r => r.id || 0)) + 1 : 1,
            userId,
            reportedId,
            reportedType,
            reason,
            timestamp: Date.now(),
            resolved: false
        };
        
        reports.push(report);
        writeJSON(REPORTS_FILE, reports);
        res.json({ success: true, report });
    } catch (error) {
        res.status(500).json({ error: 'Failed to submit report' });
    }
});

app.get('/api/admin/reports', (req, res) => {
    try {
        const adminId = parseInt(req.query.adminId);
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        const reports = readJSON(REPORTS_FILE);
        res.json(reports);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch reports' });
    }
});

app.post('/api/admin/report-action', (req, res) => {
    try {
        const { adminId, reportId, actionType, duration, reason } = req.body;
        const accounts = readJSON(ACCOUNTS_FILE);
        const admin = accounts.find(a => a.id === adminId);
        
        if (!admin || (!admin.isAdmin && admin.username.toLowerCase() !== 'alz')) {
            return res.status(403).json({ error: 'Unauthorized' });
        }
        
        const reports = readJSON(REPORTS_FILE);
        const report = reports.find(r => r.id === reportId);
        if (!report) return res.status(404).json({ error: 'Report not found' });

        if (actionType === 'resolve') {
            report.resolved = true;
            report.action = 'resolved';
        } else if (actionType === 'false-report') {
            report.resolved = true;
            report.action = 'false_report';
        } else if (actionType === 'ban') {
            const reported = accounts.find(a => a.id === report.reportedId);
            if (reported) {
                reported.isSuspended = true;
                reported.suspendedUntil = null;
                report.action = 'banned';
            }
        } else if (actionType === 'suspend-reporter') {
            const reporter = accounts.find(a => a.id === report.userId);
            if (reporter) {
                const durationMs = parseDuration(duration);
                reporter.suspendedUntil = Date.now() + durationMs;
                report.action = 'reporter_suspended';
            }
        }

        writeJSON(REPORTS_FILE, reports);
        writeJSON(ACCOUNTS_FILE, accounts);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: 'Failed to process report action' });
    }
});

function parseDuration(durationStr) {
    const units = { h: 3600000, d: 86400000, w: 604800000, m: 2592000000, y: 31536000000 };
    const match = durationStr.match(/^(\d+)([hdwmy])$/);
    if (!match) return 86400000;
    return parseInt(match[1]) * (units[match[2]] || 86400000);
}

// Serve index.html for all unmatched routes (SPA fallback)
// This should be after all API routes
app.use((req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ error: 'File size too large. Maximum size is 9GB.' });
        }
        return res.status(400).json({ error: err.message });
    } else if (err) {
        return res.status(400).json({ error: err.message });
    }
    next();
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`XVO server running on port ${PORT}`);
});
