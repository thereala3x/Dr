# XVO - Modern Social Media Platform

## Overview
XVO is a modern, full-featured social media platform built with HTML, CSS, and JavaScript. It aims to provide a robust and engaging user experience with a custom-branded UI, secure authentication, a hierarchical badge system, administrative controls, rich privacy features, and innovative social interaction functionalities. The platform seeks to offer a comprehensive social networking solution with a strong focus on user control and a sleek, intuitive design.

## User Preferences
I prefer clear, concise explanations and direct answers. I value iterative development and expect to be consulted before any major architectural changes or significant feature removals. Please ensure that proposed changes are well-justified and consider the impact on existing functionalities. I prefer the agent to focus on completing tasks efficiently and to ask clarifying questions if instructions are unclear, rather than making assumptions. Do not make changes to the `replit.md` file itself.

## System Architecture

### Tech Stack
- **Backend**: Node.js with Express.js on port 5000
- **Frontend**: Vanilla HTML/CSS/JavaScript served by Express
- **Storage**: JSON file-based storage (accounts.json, posts.json, messages.json)
- **Authentication**: bcrypt for password hashing

### Running the Application
- **Workflow**: "XVO Server" - runs `npm start` which executes `node server.js`
- **Port**: 5000 (frontend and API served together)
- **Host**: 0.0.0.0 (accessible externally)

### Key Files
- `server.js` - Main Express server with all API endpoints
- `index.html` - Frontend HTML
- `script.js` - Frontend JavaScript
- `accounts.json` - User account data
- `posts.json` - Posts and comments data
- `messages.json` - Direct messages (encrypted with AES)
- `uploads/` - User uploaded images and videos

### UI/UX Decisions
The platform features a modern, Twitter-inspired design with a sleek black and dark gray color scheme, utilizing Font Awesome icons for a professional look. It's built with a mobile-first approach, featuring a bottom navigation bar for intuitive mobile interaction and full responsiveness across devices. Smooth transitions and hover effects enhance the user experience. Toast notifications provide non-intrusive feedback for all actions.

### Technical Implementations
XVO is built using HTML5 for structure, CSS3 for styling (including custom properties and flexbox), and vanilla JavaScript for all client-side functionality. The backend is powered by Node.js with Express, handling persistent data storage and API endpoints. User authentication uses bcrypt for secure password hashing (10 rounds). Data persistence is a hybrid model, combining `localStorage` for client-side caching with a Node.js backend for server-side storage and synchronization.

### Feature Specifications
Key features include:
- **Secure Authentication**: User registration, login, and session persistence with bcrypt-hashed passwords.
- **User Profiles**: Customizable profiles with display names, usernames, profile pictures (URL/upload), bios, and statistics.
- **Post Features**: Create posts with mood/status updates, image/video uploads (up to 500MB), location tagging, hashtag support, liking, retweeting, and post deletion.
- **Anonymous Thoughts Board**: A private space for anonymous posting, ensuring no user tracking.
- **Memory Lane**: Notifies users of historical posts from the same date in previous years.
- **Privacy & Trust**: Granular privacy settings (who can follow, message, see activity), activity transparency, and an optional Verified ID system with a blue checkmark.
- **Discovery & Engagement**: Search functionality for users and posts, clickable hashtags, trending topics, and real-time notifications for interactions.
- **Settings & Customization**: Comprehensive user settings for profile details, passwords, and privacy.
- **Messaging**: End-to-end style encrypted direct messages (AES via crypto-js), real-time typing indicators, and message refresh.
- **Hierarchical Badge System**: A three-tier badge system (Black, Grey, Gold) assignable by "Alz" for visual distinction.
- **Admin Panel**: For "Alz" and designated admins, offering user suspension, badge management, password/username/avatar resets, and IP logging on user login.
- **Post Cooldown**: Server-side enforced 1-minute cooldown between user posts.
- **Rainbow Usernames**: Special animated rainbow effect for select usernames, controlled by "Alz."
- **Profile Banners**: Customizable banner images for user profiles.
- **Profile Tabs**: Enhanced profile layout with dedicated tabs for "Posts" and "Reposts."
- **Share Button**: Dynamic URL sharing for posts.
- **Clickable Following/Followers**: Modals to view and navigate followers and following lists.
- **Suspended Account UI**: Clear visual indicators and restricted functionality for suspended users.
- **Account Deletion with Admin Approval**: Users can request account deletion in Settings > Privacy. Admins review deletion requests in Admin Panel > Deletions tab. Upon approval, account becomes "AccountDeleted" with username changed, but user ID is retained. Deleted accounts are filtered from search results.
- **Private Accounts**: Toggle in Settings > Privacy to make account private. Private account posts don't appear on the feed unless the user is a follower. Non-followers viewing a private profile see "These posts are protected" message with lock icon. Only approved followers can see posts.

### System Design Choices
The system relies on JSON files (`accounts.json`, `posts.json`, `messages.json`) for backend data storage, accessed via REST API endpoints. This setup simplifies data management for a vanilla JS application. Client-side `localStorage` acts as a cache, synchronizing with the backend. The API endpoints cover CRUD operations for accounts and posts, along with specific functionalities for login, image uploads, messaging, and admin controls. Security considerations include bcrypt for passwords and the use of cache control headers.

## External Dependencies
- **Font Awesome 6**: For professional icons across the UI.
- **Node.js**: Backend JavaScript runtime environment.
- **Express**: Web framework for Node.js, used to build the REST API.
- **bcrypt**: Library for secure password hashing.
- **Multer**: Node.js middleware for handling `multipart/form-data`, primarily for file uploads (images/videos).
- **crypto-js**: JavaScript library for AES encryption of direct messages.
- **cors**: CORS middleware for Express
- **body-parser**: Request body parsing middleware